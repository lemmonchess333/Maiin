"""Equipment-only draft: common bearing centre, continuous crank and fixed rear support."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import numpy as np,json,math
H=Path(__file__).resolve().parent;R=H.parent/'Maiin-burpees';O=H/'candidate-v3/bike';O.mkdir(parents=True,exist_ok=True)
A=Image.open(R/'public/form-frames/bike/1.webp').convert('RGBA');B=Image.open(R/'public/form-frames/bike/3.webp').convert('RGBA');assert A.size==B.size==(929,1432)
a=np.array(A);b=np.array(B);C=(498,1105);OLD=(507,1091);PEDAL=(454,972);W,Hh=A.size
mask=Image.new('L',A.size,0);d=ImageDraw.Draw(mask);d.ellipse((OLD[0]-59,OLD[1]-59,OLD[0]+59,OLD[1]+59),fill=255);d.ellipse((C[0]-48,C[1]-48,C[0]+48,C[1]+48),fill=255);d.polygon([(436,973),(468,965),(536,1082),(532,1120),(486,1128),(455,1040)],fill=255);d.polygon([(470,981),(487,981),(548,1047),(540,1074),(485,1019)],fill=255)
ma=np.array(mask)>0;ma[:981]=False;yy,xx=np.indices(ma.shape);result=b.copy()
# Fit only the plain neutral casing surrounding the removed gear. Bright
# diagonal frame rails and the old gear/shadow are excluded from samples.
blocked=np.array(mask.filter(ImageFilter.MaxFilter(25)))>0;rgb=b[:,:,:3].astype(float);mx=rgb.max(2);mn=rgb.min(2);sample=(xx>=430)&(xx<625)&(yy>=990)&(yy<1175)&~blocked&(mx>24)&(mx<94)&(mx-mn<12)
X=(xx-500)/100;Y=(yy-1090)/100;design=np.stack([np.ones_like(X),X,Y,X*X,X*Y,Y*Y],2);coef=np.linalg.lstsq(design[sample],rgb[sample],rcond=None)[0]
for _ in range(3):
 residual=np.max(np.abs(design[sample]@coef-rgb[sample]),axis=1);keep=residual<np.percentile(residual,85);coef=np.linalg.lstsq(design[sample][keep],rgb[sample][keep],rcond=None)[0]
plane=np.clip(design@coef,18,98);coverage=np.array(mask.filter(ImageFilter.GaussianBlur(1.0)))/255;coverage[:981]=0;domain=coverage>0;result[domain,:3]=np.rint(rgb*(1-coverage[:,:,None])+plane*coverage[:,:,None])[domain].astype(np.uint8);ma=domain
clean=Image.fromarray(result)
# A shaded neutral bearing matching the source reference's modest projected
# 66x74disc and fixedcentre. No source athlete pixels enter this equipment.
template=np.zeros_like(a);rx,ry=33,37;ss=4;local=np.zeros((99*ss,91*ss,4),np.uint8)
for ly in range(99*ss):
 for lx in range(91*ss):
  dx,dy=(lx+.5)/ss-45,(ly+.5)/ss-49;recess=(dx/44)**2+(dy/48)**2;radius=(dx/rx)**2+(dy/ry)**2
  if recess<=1:local[ly,lx]=[29,30,30,255]
  if radius<=1:
   value=int(np.clip(165-28*radius-19*dy/ry,92,190));local[ly,lx]=[value,value+2,value+3,255]
   if radius>.89:local[ly,lx]=[190 if dy<0 else 89,192 if dy<0 else 91,193 if dy<0 else 92,255]
local=Image.fromarray(local).resize((91,99),Image.Resampling.LANCZOS);template[C[1]-49:C[1]+50,C[0]-45:C[0]+46]=np.array(local)
hub=Image.fromarray(template);clean.alpha_composite(hub)
# A shaded solid metal crank, behind the unchanged native pedal attachment.
scale=4;layer=Image.new('RGBA',(W*scale,Hh*scale));d=ImageDraw.Draw(layer);p=np.array(PEDAL,float);c=np.array(C,float);axis=p-c;axis/=np.linalg.norm(axis);n=np.array([-axis[1],axis[0]])
def polygon(width,colour,shift=0):
 pts=[c+n*(width/2+shift),p+n*(width/2+shift),p+n*(-width/2+shift),c+n*(-width/2+shift)];d.polygon([(round(x*scale),round(y*scale))for x,y in pts],fill=colour)
polygon(32,(57,60,61,255));polygon(27,(161,164,165,255));polygon(20,(141,145,147,255),1.0)
for point,radius in [(C,19),(PEDAL,13)]:
 x,y=point;d.ellipse(((x-radius)*scale,(y-radius)*scale,(x+radius)*scale,(y+radius)*scale),fill=(145,148,149,255),outline=(63,65,66,255),width=2*scale)
crank=layer.resize(A.size,Image.Resampling.LANCZOS);clean.alpha_composite(crank)
# The exact original pedal/strap and all source foot pixels remain foreground.
foreground=Image.new('RGBA',A.size);foreground.paste(B.crop((390,925,487,981)),(390,925));clean.alpha_composite(foreground)
# Same native socket cap fixes the visible axis without moving any human pixel.
cap=np.zeros_like(a);cm=(xx-C[0])**2+(yy-C[1])**2<=13**2;cap[cm]=a[cm];clean.alpha_composite(Image.fromarray(cap))
rear=(846,1303,929,1432);clean.paste(A.crop(rear),(rear[0],rear[1]));final=np.array(clean);final[:981]=b[:981];clean=Image.fromarray(final);changed=np.any(final!=b,2);allowed=ma|(np.array(crank)[:,:,3]>0)|cm|(template[:,:,3]>0);allowed[rear[1]:rear[3],rear[0]:rear[2]]=True;assert not np.any(changed&~allowed)
assert np.array_equal(final[:925],b[:925]);assert np.array_equal(final[925:960],b[925:960]);assert np.array_equal(final[860:960,360:650],b[860:960,360:650])
clean.convert('RGB').save(O/'opposed-equipment-clean.png');hub.save(O/'fixed-grey-hub-template.png');crank.save(O/'opposed-crank-layer.png');Image.fromarray((changed*255).astype(np.uint8)).save(O/'equipment-edit-mask.png');mask.save(O/'old-equipment-removal-mask.png');Image.fromarray(cap).save(O/'native-fixed-socket-cap.png')
sheet=Image.new('RGB',(1400,720),'#18181b');d=ImageDraw.Draw(sheet)
for i,(name,im)in enumerate([('Original reference',A),('Original opposed',B),('Corrected opposed',clean)]):
 thumb=im.convert('RGB');thumb.thumbnail((450,670));sheet.paste(thumb,(i*465+(450-thumb.width)//2,35));d.text((i*465+10,10),name,fill='white')
sheet.save(O/'whole-scene-before-after.png');clean.crop((390,950,600,1165)).resize((630,645),Image.Resampling.NEAREST).save(O/'corrected-bearing-detail.png');(O/'pixel-proof.json').write_text(json.dumps({'scope':'Equipment-only illustrative2D correction; original athlete, foot/strap, hands, colours, framing and cues preserved. Not recovered3D hardware calibration.','referenceBearingCentre':C,'opposedNewBearingCentre':C,'originalOpposedCentre':OLD,'originalNearPedalAttachment':PEDAL,'newVisibleCentreDelta':[0,0],'rearSupportCopiedExactlyFromReference':list(rear),'changedPixels':int(changed.sum()),'outsideEquipmentMasksExact':True,'allOriginalUpperBodyAndFootForegroundExact':True,'anatomicalTransforms':[],'nativeHubSource':'Equipment-only procedural grey bearing at the fixed reference centre, with the exact native reference socket cap retained. No anatomy source pixels are transformed.','crankLayer':'Equipment-only4xantialias; human pixels never resampled.'},indent=2)+'\n',encoding='utf-8');print(json.dumps({'changedPixels':int(changed.sum()),'centre':C,'newImageRequests':0}))
