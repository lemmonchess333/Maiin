from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
H=Path(__file__).resolve().parent;R=H.parent/'Maiin-burpees'
plans={'bike':[(0,1260,220,1432),(740,1250,929,1432)],'dips':[(60,895,155,976),(405,950,510,1034)]};rows=[]
for eid,boxes in plans.items():
 folder=H/'staged'/eid;folder.mkdir(parents=True,exist_ok=True);master=Image.open(R/f'public/form-frames/{eid}/1.webp').convert('RGB');allowed=np.zeros((master.height,master.width),bool)
 for x0,y0,x1,y1 in boxes:allowed[y0:y1,x0:x1]=True
 for n in range(1,7):
  old=Image.open(R/f'public/form-frames/{eid}/{n}.webp').convert('RGB');new=old.copy()
  for box in boxes:new.paste(master.crop(box),(box[0],box[1]))
  diff=np.any(np.asarray(new)!=np.asarray(old),axis=2);assert not np.any(diff&~allowed);new.save(folder/f'{n}.png')
  rows.append({'id':eid,'frame':n,'fixedEquipmentOnlyRegions':boxes,'changedPixels':int(diff.sum()),'outsideFixedBasePodsChangedPixels':int((diff&~allowed).sum()),'sourceScale':1,'anatomicalTransforms':[],'sourceMaster':'original frame1 native base pods','outputSha256':hashlib.sha256((folder/f'{n}.png').read_bytes()).hexdigest()})
  if n in [1,3,4]:
   proof=new.copy();draw=ImageDraw.Draw(proof)
   for box in boxes:draw.rectangle(box,outline='red',width=2)
   proof.save(H/f'{eid}-{n}-fixed-pod-regions.png')
(H/'fixed-base-pod-proof.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps([{k:r[k]for k in ['id','frame','changedPixels','outsideFixedBasePodsChangedPixels']}for r in rows],indent=2))
