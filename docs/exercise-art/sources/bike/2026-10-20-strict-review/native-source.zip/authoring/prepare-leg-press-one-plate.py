from pathlib import Path
from PIL import Image
from io import BytesIO
import importlib.util,zipfile,xml.etree.ElementTree as ET,json,hashlib
import numpy as np
H=Path(__file__).resolve().parent;R=H.parent/'Maiin-burpees';O=H/'leg-press-one-plate';O.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('legpress_equipment',H/'leg-press-equipment-one-plate.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
results={};proof=[]
for pose in ['A','B']:
 path=R/f'docs/exercise-art/sources/leg-press/2026-10-16/draft/{pose}-native.ora'
 with zipfile.ZipFile(path)as z:
  nodes=list(ET.fromstring(z.read('stack.xml')).find('stack'))
  layers=[(n.attrib['name'],Image.open(BytesIO(z.read(n.attrib['src']))).convert('RGBA'))for n in reversed(nodes)]
 old=Image.new('RGBA',layers[0][1].size)
 for name,image in layers:old=Image.alpha_composite(old,image)
 expected=Image.open(R/f'docs/exercise-art/sources/leg-press/2026-10-16/draft/{pose}-native.png').convert('RGBA');assert np.array_equal(np.array(old),np.array(expected))
 equipment,geometry=mod.render(pose);newgear=Image.new('RGBA',old.size);newgear.paste(equipment.crop((144,0,1344,1024)),(32,16))
 result=Image.new('RGBA',old.size);foreground=np.zeros((old.height,old.width),bool)
 for name,image in layers:
  if name=='Custom apparatus':current=newgear
  else:current=image
  if name in ['Native connected moving-region composite','Approved palette using original source tone']:foreground|=np.array(image)[:,:,3]==255
  result=Image.alpha_composite(result,current)
 delta=np.any(np.array(old)!=np.array(result),axis=2);assert not np.any(delta&foreground)
 result.save(O/f'{pose}.png');newgear.save(O/f'{pose}-equipment.png');results[pose]=result.convert('RGB')
 proof.append({'pose':pose,'inputOra':str(path),'inputOraSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'geometry':geometry,'changedPixels':int(delta.sum()),'allNonEquipmentLayersByteExact':True,'visibleAthleteAndPaletteChangedPixels':int((delta&foreground).sum())})
stage=H/'staged/leg-press';stage.mkdir(parents=True,exist_ok=True)
for i,pose in enumerate(['B','B','A','A','B','B'],1):results[pose].save(stage/f'{i}.png')
(O/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
