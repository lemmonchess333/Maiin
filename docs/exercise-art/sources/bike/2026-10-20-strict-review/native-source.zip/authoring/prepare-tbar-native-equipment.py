"""Equipment-only native renderer adapted from the reviewed skull-crusher gear."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import numpy as np,math,json
H=Path(__file__).resolve().parent;R=H.parent/'Maiin-burpees';O=H/'tbar-native-equipment';O.mkdir(exist_ok=True)
facts=[]
for n,x0,window,plate_x,end_x in [(1,686,(620,715),731,892),(2,664,(430,520),710,875)]:
 original=Image.open(R/f'docs/exercise-art/sources/t-bar-row/2026-10-15/draft/{n}-framed.png').convert('RGB');a=np.asarray(original).astype(int);w,h=original.size
 # Measure the exposed actual steel tube immediately before the old load.
 samples=[];heights=[]
 for x in range(x0-50,x0-4):
  col=a[window[0]:window[1],x];mask=(col.max(1)>35)&(np.ptp(col,axis=1)<25)
  edges=np.flatnonzero(np.diff(np.r_[False,mask,False]));runs=[(u,v)for u,v in zip(edges[::2],edges[1::2])if v-u>=5]
  if not runs:continue
  top,bottom=runs[-1];samples.append((x,window[0]+(top+bottom-1)/2));heights.append(bottom-top)
 slope,intercept=np.polyfit(*np.array(samples).T,1);theta=math.atan(slope);u=np.array([math.cos(theta),math.sin(theta)]);v=np.array([-u[1],u[0]])
 center=np.array([plate_x,slope*plate_x+intercept])+u*15;shaft_r=float(np.median(heights)/2*math.cos(theta));shaft_r=min(10,max(7,shaft_r))
 s=4;origin=np.floor(center-[110,145]).astype(int);wh=(330,290);im=Image.new('RGBA',(wh[0]*s,wh[1]*s));d=ImageDraw.Draw(im)
 def pt(p):return tuple((np.asarray(p)-origin)*s)
 def line(a,b,color,width):d.line([pt(a),pt(b)],fill=(int(color),)*3+(255,),width=round(width*s))
 def ellipse(c,rx,ry,base=70,rim=False,metal=False):
  delta=rx+ry+3;lo=np.floor(c-delta).astype(int);hi=np.ceil(c+delta).astype(int);yy,xx=np.mgrid[lo[1]*s:hi[1]*s,lo[0]*s:hi[0]*s]
  q=np.stack([xx/s-c[0],yy/s-c[1]],axis=-1);x=q@u/rx;y=q@v/ry;r=np.sqrt(x*x+y*y);alpha=(r<=1).astype('uint8')*255
  val=base+8*(-.5*x-.85*y)+4*(1-r*r)
  if rim:
   band=np.clip((r-.87)/.13,0,1);edge=69+59*np.clip(-.65*x-.75*y,0,1)-17*np.clip(.65*x+.75*y,0,1);val=val*(1-band)+edge*band
  if metal:val=base+55*np.exp(-((y+.3)/.2)**2)-45*np.clip(y,0,1)
  b=np.empty((*r.shape,4),np.uint8);b[:,:,:3]=np.rint(np.clip(val,0,255))[:,:,None];b[:,:,3]=alpha
  im.alpha_composite(Image.fromarray(b),((lo[0]-origin[0])*s,(lo[1]-origin[1])*s))
 def cylinder(a,b,r):
  line(a,b,55,r*2)
  for f,col,width in [(.05,104,1.6),(-.2,167,1.1),(-.45,214,.65),(.48,68,.7)]:line(a+v*r*f,b+v*r*f,col,r*width)
 start=center-u*95;end=np.array([end_x,slope*end_x+intercept]);cylinder(start,end,shaft_r)
 # Identical modest cast plate radii and depth in both source poses.
 rx,ry,depth=43.,103.,10.
 ellipse(center+u*depth,rx,ry,49,True);ellipse(center+u*5,rx,ry,55,True);ellipse(center,rx,ry,67,True);ellipse(center,rx*.84,ry*.84,62)
 ellipse(center,rx*.23,ry*.17,125,False,True);ellipse(center,rx*.12,ry*.09,44)
 cylinder(start,center,shaft_r);collar=center+u*(rx+depth+5);ellipse(collar,4,shaft_r+4,126,False,True);cylinder(collar,end,shaft_r);ellipse(end,2.5,shaft_r,101,False,True)
 gear=Image.new('RGBA',original.size);gear.alpha_composite(im.resize(wh,Image.Resampling.LANCZOS),tuple(origin))
 # The old two-disc region contains equipment/background only; keep the whole athlete.
 box=(x0,500 if n==1 else 300,918,790 if n==1 else 580);clean=original.copy();ImageDraw.Draw(clean).rectangle((box[0],box[1],box[2]-1,box[3]-1),fill='black')
 # Keep the replacement entirely inside the inspected equipment-only region.
 ga=np.array(gear);region=np.zeros((h,w),bool);region[box[1]:box[3],box[0]:box[2]]=True;ga[~region,3]=0;gear=Image.fromarray(ga)
 result=Image.alpha_composite(clean.convert('RGBA'),gear).convert('RGB')
 # Pass the unmodified native closed hands/handle end in front of the new load.
 body_mask=((a.min(2)>150)&(np.ptp(a,axis=2)<45))|((a[:,:,2]>a[:,:,0]+15)&(a[:,:,2]>a[:,:,1]+8))
 body_mask[:,x0:]=False;body_mask[:500 if n==1 else 300]=False
 mask=Image.fromarray(body_mask.astype('uint8')*255).filter(ImageFilter.MaxFilter(3));result.paste(original,(0,0),mask)
 # Preserve the actual original left-of-region scene, replacing only the
 # short tube where the renderer crosses the seam; all visible body stays exact.
 new=np.array(result);diff=np.any(new!=a,axis=2);visible_body=(np.asarray(mask)>0);assert not np.any(diff&visible_body);assert not np.any(diff&~region)
 result.save(O/f'{n}.png');gear.save(O/f'{n}-equipment.png');mask.save(O/f'{n}-native-foreground-mask.png')
 facts.append({'pose':n,'observedNativeShaftAxis':[float(slope),float(intercept)],'shaftRadius':shaft_r,'plateRadii':[rx,ry],'plateDepth':depth,'plateCentre':center.tolist(),'angle':theta,'changedPixels':int(diff.sum()),'athleteForegroundChangedPixels':int((diff&visible_body).sum()),'method':'established native skull-crusher neutral-metal renderer, one cast plate, source-measured native tube axis; no body transformations'})
(O/'proof.json').write_text(json.dumps(facts,indent=2)+'\n');print(json.dumps(facts,indent=2))
