from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib
H=Path(__file__).resolve().parent;R=H.parent/'Maiin-burpees';O=H/'staged/rowing-machine';O.mkdir(parents=True,exist_ok=True)
master=Image.open(R/'public/form-frames/rowing-machine/1.webp').convert('RGB');boxes=[(0,510,220,830),(1160,650,1416,830)];rows=[]
allowed=np.zeros((830,1416),bool)
for x0,y0,x1,y1 in boxes:allowed[y0:y1,x0:x1]=True
for n in range(1,7):
 original=Image.open(R/f'public/form-frames/rowing-machine/{n}.webp').convert('RGB');candidate=original.copy()
 for b in boxes:candidate.paste(master.crop(b),(b[0],b[1]))
 changed=np.any(np.asarray(candidate)!=np.asarray(original),axis=2);assert not np.any(changed&~allowed)
 output=O/f'{n}.png';candidate.save(output)
 rows.append({'frame':n,'fixedApparatusRegions':boxes,'changedPixels':int(changed.sum()),'outsideApparatusChangedPixels':int((changed&~allowed).sum()),'allAthleteHandsFeetSeatChainAndPaletteOutsideRegionsExact':True,'outputSha256':hashlib.sha256(output.read_bytes()).hexdigest()})
(H/'rower-fixed-support-proof.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
