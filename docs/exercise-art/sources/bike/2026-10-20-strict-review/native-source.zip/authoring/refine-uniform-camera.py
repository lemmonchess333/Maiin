from pathlib import Path
from PIL import Image
import numpy as np,json
H=Path(__file__).resolve().parent;R=H.parent/'Maiin-burpees'
ns={'__file__':str(H/'measure-native-features.py')}
exec((H/'measure-native-features.py').read_text().split("staged='--staged'")[0],ns)
match=ns['match'];snap=ns['snap'];config=ns['config']
eid='overhead-extension';original=Image.open(R/f'public/form-frames/{eid}/3.webp').convert('RGB');ref=np.array(Image.open(R/f'public/form-frames/{eid}/1.webp').convert('RGB'));h,w=ref.shape[:2]
points=[snap(ref,(x*w,y*h))for x,y in config[eid]];target=np.array([p[:2]for p in points],float)
records=json.loads((H/'whole-source-registration.json').read_bytes());base=next(r for r in records if r['id']==eid and r['frame']==3)
tests=[];best=None;best_image=None
for ds in [-.0015,-.001,-.0005,0,.0005,.001,.0015]:
 for dx in [-.75,0,.75]:
  for dy in [-.75,0,.75]:
   scale=base['uniformWholeSourceScale']+ds;tx=base['wholeSourceTranslation'][0]+dx;ty=base['wholeSourceTranslation'][1]+dy
   im=original.transform(original.size,Image.Transform.AFFINE,(1/scale,0,-tx/scale,0,1/scale,-ty/scale),Image.Resampling.BICUBIC);a=np.array(im)
   observed=[match(a,ref,p,radius=4)for p in points];q=np.array([[p['x'],p['y']]for p in observed],float)
   anchor=float(np.abs(q[[1,3]]-target[[1,3]]).max());dimensions=[abs(np.linalg.norm(q[i]-q[j])/np.linalg.norm(target[i]-target[j])-1)for i,j in [(0,1),(2,3)]]
   dimensions=[float(v)for v in dimensions];mse=float(((q-target)**2).sum());error=float(np.mean([p['meanAbsoluteRGBError']for p in observed]));feasible=bool(anchor<=1 and max(dimensions)<=.01)
   metric=(not feasible,mse,error,abs(ds)+abs(dx)*.001+abs(dy)*.001)
   report={'scale':scale,'translation':[tx,ty],'anchorDrift':anchor,'dimensionDrifts':dimensions,'mse':mse,'meanTemplateError':error,'feasible':feasible,'observed':observed};tests.append(report)
   if best is None or metric<best[0]:best=(metric,report);best_image=im
(H/'uniform-camera-refinement.json').write_text(json.dumps({'id':eid,'scope':'finite refinement of one common uniform camera transform, with no anatomical part transforms','trials':tests,'selected':best[1]},indent=2)+'\n')
if best[1]['feasible']:
 for n in [3,4]:best_image.save(H/'staged'/eid/f'{n}.png')
print(json.dumps(best[1],indent=2))
