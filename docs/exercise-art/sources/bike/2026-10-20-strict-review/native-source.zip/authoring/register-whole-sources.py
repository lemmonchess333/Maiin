"""One uniform scale/translation per whole source; no per-part fitting."""
from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib
H=Path(__file__).resolve().parent;R=H.parent/'Maiin-burpees'
data=json.loads((H/'native-feature-measurements-initial.json').read_bytes());rows=[]
for row in data:
 eid=row['id']
 if eid not in ['overhead-extension','barbell-row']:continue
 folder=H/'staged'/eid;folder.mkdir(parents=True,exist_ok=True)
 target=np.array([[p['x'],p['y']]for p in row['samples'][0]['features']],float)
 for sample in row['samples']:
  pts=np.array([[p['x'],p['y']]for p in sample['features']],float);a=pts-pts.mean(0);b=target-target.mean(0)
  scale=float((a*b).sum()/(a*a).sum());shift=target.mean(0)-scale*pts.mean(0)
  assert .95<scale<1.05
  original=Image.open(R/'public'/sample['path']).convert('RGB')
  if abs(scale-1)<1e-12 and np.abs(shift).max()<1e-12:result=original.copy()
  else:result=original.transform(original.size,Image.Transform.AFFINE,(1/scale,0,-shift[0]/scale,0,1/scale,-shift[1]/scale),Image.Resampling.BICUBIC)
  output=folder/f'{sample["frame"]}.png';result.save(output)
  rows.append({'id':eid,'frame':sample['frame'],'input':sample['path'],'inputSha256':sample['sha256'],'uniformWholeSourceScale':scale,'wholeSourceTranslation':shift.tolist(),'output':str(output),'outputSha256':hashlib.sha256(output.read_bytes()).hexdigest(),'dimensions':result.size,'projectedFeatureResidual':(pts*scale+shift-target).tolist(),'anatomicalPartTransforms':[],'reviewDisposition':'candidate; native and mobile checks required'})
(H/'whole-source-registration.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps([{k:r[k]for k in ['id','frame','uniformWholeSourceScale','wholeSourceTranslation']}for r in rows],indent=2))
