Preserve the original two front floor pods at unchanged coordinates. All athlete, hanging feet, grips and bars outside those equipment regions remain exact.

Run reproduce.py --output <new-folder> to reopen frozen native layers and reproduce the exact delivered pixels and lossless WebP files. Authoring snapshots retain historical workspace paths; the portable entry point uses only this package. The uniform-camera-refinement.json final matrix supersedes the initial least-squares overhead-extension matrix. No new anatomy, clothing, head/shoe grafts or individual limb scaling.
