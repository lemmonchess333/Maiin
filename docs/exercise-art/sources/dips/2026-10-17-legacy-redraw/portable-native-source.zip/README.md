# Bodyweight chest dip redraw source package

Source-only candidate for replacement of legacy `dips`. Repository, original weighted chest dip, browser and Git state remain untouched.

Publication candidates are `candidate/frames/1.webp` through `6.webp`, each **880×1088**, lossless. Three genuine native top/mid/bottom poses are reused **A,B,B,C,B,A**. Proposed physical progress is **0,.5,.5,1,.5,0**. The catalogue's forward chest lean and original six phase meanings remain; an early nominal.22 geometry is not falsely claimed. Proposed solid key: Pectoralis major primary; Triceps and Anterior deltoids secondary. Remove the obsolete hatch/lower-chest/serratus key during root integration.

Built-in imagegen reauthored the hidden lower-abdomen, neutral pelvis and thigh surfaces after removing the belt, chain and suspended plate from each exact current approved weighted-chest-dip pose. Canonical FA56 and the exact local pose were attached each time; the accepted unweighted top was also attached to midpoint/bottom. Only documented native occlusion windows feed each composite; all other original pixels, heads, upper-limb chains, closed grips, trainers and station remain. No anatomical warps, fitted limbs, mirrors, resizing, head/shoe inserts or pelvis grafts.

Bottom generation shifted the entire scene up32px. Three independent stationary equipment regions agree on a whole-image(0,+32) integer correction before window selection. See `bottom-whole-frame-registration-diagnostic.json`; this is honest framing registration, not inverse preview zoom or anatomical alignment.

All six use one unscaled native crop `(352,0,1168,1024)` and32px canvas padding. Full1536×1024 source images, registered outputs, native four-layer ORAs and framed five-layer ORAs remain archived. Exact prompts/source hashes/provenance are in `provenance.json`. `reproduce.py --output ABSOLUTE_PATH` independently rebuilds the candidate. `candidate/technical-validation.json` confirms six exact OpenRaster recomposites and six lossless frame comparisons. `candidate/review/native-six-playback.webp` is a1200ms/frame playback preview, not a claim of observed browser/mobile acceptance.

Root owns final source judgment, native/mobile light-dark playback and pause review, normal card generation, integration, project checks, CI and merge. All11 strict checks in `source-review.json` remain null. This package is not registered, certified or published.
