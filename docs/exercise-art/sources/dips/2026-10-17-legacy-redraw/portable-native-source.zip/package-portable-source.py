from pathlib import Path
import hashlib,json,zipfile
from PIL import Image
import numpy as np

ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
selected=[]
for folder in ['originals','candidate']:
 selected.extend(p for p in (ROOT/folder).rglob('*') if p.is_file())
for name in ['README.md','reproduce.py','package-portable-source.py','provenance.json','source-review.json','candidate-manifest.json','independent-reproduction-proof.json','bottom-whole-frame-registration-diagnostic.json','top-belt-chain-removal-prompt.txt','mid-belt-chain-removal-prompt.txt','bottom-belt-chain-removal-prompt.txt']:
 selected.append(ROOT/name)
selected=sorted(set(selected))
memberHashes={p.relative_to(ROOT).as_posix():sha(p) for p in selected}
archive=ROOT/'portable-native-source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for path in selected:z.write(path,path.relative_to(ROOT).as_posix())
 z.writestr('portable-native-source-files.json',json.dumps({'membersSha256':memberHashes},indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(memberHashes)+1
 for name,expected in memberHashes.items():
  data=z.read(name);assert hashlib.sha256(data).hexdigest()==expected,name
  assert data==(ROOT/name).read_bytes(),name
 archivedManifest=json.loads(z.read('portable-native-source-files.json'))
 assert archivedManifest['membersSha256']==memberHashes
proof={'archive':str(archive),'archiveSha256':sha(archive),'archiveBytes':archive.stat().st_size,'memberCountIncludingManifest':len(memberHashes)+1,'sourceFileMembers':len(memberHashes),'everyMemberReadBack':True,'everySourceMemberSha256Exact':True,'everySourceMemberByteExact':True,'archivedManifestReadBackExact':True,'memberHashes':memberHashes,'excludes':['duplicate independent-reproduction output directory','integration-item.json to avoid circular archive hash','repository files and review manifests']}
(ROOT/'portable-native-source-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n')

order=['A','B','B','C','B','A'];ts=[0,.5,.5,1,.5,0]
labels=['Top','Lower','Control','Bottom','Press','Finish']
cues=['Straight arms; keep shoulders down.','Bend elbows; maintain a slight forward lean.','Lower smoothly with both hands fixed.','Stop around upper arms parallel to floor.','Push through the bars; keep chest inclined.','Straighten arms without shrugging your shoulders.']
frames=[]
for i,(pose,t,label,cue) in enumerate(zip(order,ts,labels,cues),1):
 assert len(cue.split())<=7,(i,cue)
 webp=ROOT/f'candidate/frames/{i}.webp'; png=ROOT/f'candidate/{pose}-framed.png';native=ROOT/f'candidate/{pose}-finished.png'
 assert np.array_equal(np.asarray(Image.open(webp).convert('RGB')),np.asarray(Image.open(png).convert('RGB')))
 frames.append({'index':i,'sourcePose':pose,'t':t,'label':label,'cue':cue,'sourceWebp':str(webp),'sourceWebpSha256':sha(webp),'sourcePNG':str(png),'sourcePNGSha256':sha(png),'sourcePNGDimensions':[880,1088],'sourceCrop':[0,0,880,1088],'deliveredDimensions':[880,1088],'nativeSourcePNG':str(native),'nativeSourcePNGSha256':sha(native),'nativeSourcePNGDimensions':[1536,1024],'nativeCrop':[352,0,1168,1024],'nativePadding':[32,32]})
review=json.loads((ROOT/'source-review.json').read_text());provenance=json.loads((ROOT/'provenance.json').read_text())
item={'exerciseId':'dips','id':'dips','name':'Dips','version':'anatomy-v3-2026-10-17-native-bodyweight-chest-dip-redraw-v1','width':880,'height':1088,'primary':['Pectorals'],'secondary':['Triceps','Anterior deltoids'],'secondaryFill':'solid','key':{'primary':['Pectorals'],'secondary':['Triceps','Anterior deltoids'],'secondaryFill':'solid'},'sourcePoseOrder':order,'positionCoordinates':ts,'physicalPoses':3,'playback':'loop','cardFrame':4,'referenceFrame':4,'reference':'form-frames/dips/4.webp','cardSelectionNote':'Bottom frame4 clearly identifies the chest-dip movement. There is no existing dips CARD_FRAMES override to preserve; deliberately use frame4 as reference/card source.','frames':frames,'beats':[{'t':f['t'],'label':f['label'],'cue':f['cue']} for f in frames],'setup':['Support yourself on parallel bars with hands fixed and feet clear.','Keep a slight forward torso lean and your shoulders controlled.','Bend elbows to lower smoothly, then press back up without shrugging.'],'advice':{'tip':'Keep both grips fixed and hold the chest incline throughout the return.','commonMistakes':['Shrugging the shoulders while supporting the body.','Changing to an upright triceps-dip posture.','Dropping into the bottom instead of controlling the descent.']},'findings':review['findings'],'provenance':provenance,'sourcePackage':str(ROOT),'sourceArchive':str(archive),'sourceArchiveSha256':proof['archiveSha256'],'sourceArchiveProof':str(ROOT/'portable-native-source-archive-proof.json'),'nativeReview':str(ROOT/'source-review.json'),'reproductionProof':str(ROOT/'independent-reproduction-proof.json'),'sourceReviewStatus':'root accepted three native final poses for actual staged playback','strictCertified':False,'integratedMobileReviewComplete':False,'normalCardExportComplete':False,'registered':False,'completionCredit':False}
(ROOT/'integration-item.json').write_text(json.dumps(item,indent=2)+'\n')
print(json.dumps({'archiveSha256':proof['archiveSha256'],'archiveBytes':proof['archiveBytes'],'members':proof['memberCountIncludingManifest'],'readbackExact':True,'integrationItem':str(ROOT/'integration-item.json'),'referenceFrame':4,'cueWordCounts':[len(c.split()) for c in cues],'framesBoundExactly':6},indent=2))
