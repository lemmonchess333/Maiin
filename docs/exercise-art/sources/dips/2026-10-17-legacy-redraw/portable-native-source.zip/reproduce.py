"""Native unweighted chest-dip source authoring. Pillow+NumPy; no anatomy fitting."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import argparse,hashlib,io,json,zipfile,xml.etree.ElementTree as ET
import numpy as np
HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=HERE/'candidate')
OUT=parser.parse_args().output.resolve();OUT.mkdir(parents=True,exist_ok=True)
for d in ['frames','layers','review']:(OUT/d).mkdir(exist_ok=True)
SIZE=(1536,1024)
CROP=(352,0,1168,1024);FRAMED_SIZE=(880,1088)
PRIMARY=np.array([123,114,233],dtype=float);SECONDARY=np.array([149,144,224],dtype=float)
polygons={
 'A':[(675,250),(835,250),(835,415),(797,430),(797,600),(675,600)],
 'B':[(675,290),(835,290),(835,438),(799,470),(799,638),(675,638)],
 'C':[(675,350),(845,350),(845,470),(800,510),(800,685),(675,685)],
}
sourceNames={
 'A':('1-weighted-source-native.png','1-unweighted-top-generated-native.png'),
 'B':('2-weighted-source-native.png','2-unweighted-mid-generated-native.png'),
 'C':('3-weighted-source-native.png','3-unweighted-bottom-generated-native.png'),
}
pecBoxes={'A':(633,144,765,225),'B':(628,216,773,293),'C':(629,260,775,340)}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def png(im):
 b=io.BytesIO();im.save(b,format='PNG');return b.getvalue()
def rect(box):
 m=Image.new('L',SIZE);ImageDraw.Draw(m).rectangle(box,fill=255);return np.asarray(m)>0
proof={};finished={}
for i,k in enumerate(['A','B','C'],1):
 originalName,newName=sourceNames[k]
 original=Image.open(HERE/'originals'/originalName).convert('RGB')
 generated=Image.open(HERE/'originals'/newName).convert('RGB')
 assert original.size==generated.size==SIZE
 if k=='C':
  # Measured using three independent stationary equipment ROIs. This is one
  # whole-image integer translation undoing a32px framing shift, not anatomy
  # alignment, limb fitting, scaling or an inverse-preview-zoom claim.
  aligned=Image.new('RGB',SIZE,'black');aligned.paste(generated,(0,32))
 else:aligned=generated
 aligned.save(OUT/f'{k}-generated-whole-frame-registered.png')
 mask=Image.new('L',SIZE);ImageDraw.Draw(mask).polygon(polygons[k],fill=255)
 mask=mask.filter(ImageFilter.GaussianBlur(1.5))
 # Existing rails/grips are foreground contacts and remain donor-exact.
 keep=Image.new('L',SIZE);kd=ImageDraw.Draw(keep)
 kd.ellipse((775,354,805,384),fill=255);kd.rectangle((790,356,1010,383),fill=255)
 kd.ellipse((521,354,549,384),fill=255);kd.rectangle((535,356,700,383),fill=255)
 kd.rectangle((841,330,895,395),fill=255)
 mask=np.array(mask);mask[np.array(keep)>0]=0;mask=Image.fromarray(mask)
 mask.save(OUT/f'layers/{k}-native-occlusion-authoring-mask.png')
 patch=aligned.convert('RGBA');patch.putalpha(mask);patch.save(OUT/f'layers/{k}-native-occlusion-authoring-layer.png')
 native=Image.alpha_composite(original.convert('RGBA'),patch).convert('RGB')
 native.save(OUT/f'{k}-native-geometry.png')
 a=np.asarray(native).astype(float)
 tint=(a[:,:,2]-a[:,:,0]>6)&(a[:,:,2]-a[:,:,1]>10)
 grey=np.max(a,axis=2)
 neutral=a.copy();neutral[tint]=np.repeat(grey[:,:,None],3,axis=2)[tint]
 neutralRgba=np.zeros((1024,1536,4),dtype='uint8');neutralRgba[:,:,:3]=np.round(neutral).clip(0,255).astype('uint8');neutralRgba[:,:,3]=np.where(tint,255,0)
 def closed_region(m):
  mi=Image.fromarray(np.where(m,255,0).astype('uint8')).filter(ImageFilter.MaxFilter(3)).filter(ImageFilter.MinFilter(3))
  bb=mi.getbbox()
  if not bb:return mi
  bb=(max(0,bb[0]-2),max(0,bb[1]-2),min(1536,bb[2]+2),min(1024,bb[3]+2))
  crop=mi.crop(bb);ImageDraw.floodfill(crop,(0,0),128)
  filled=Image.fromarray(np.where(np.asarray(crop)!=128,255,0).astype('uint8'))
  out=Image.new('L',SIZE);out.paste(filled,(bb[0],bb[1]));return out
 primaryMask=(a[:,:,2]-a[:,:,1]>70)&(a[:,:,0]-a[:,:,1]>30)&rect(pecBoxes[k])
 if k=='A':primaryMask|=tint&rect((696,153,731,175))
 pm=closed_region(primaryMask).filter(ImageFilter.GaussianBlur(.55))
 pw=np.asarray(pm).astype(float)/255
 allmask=closed_region(tint).filter(ImageFilter.GaussianBlur(.55))
 tw=np.asarray(allmask).astype(float)/255
 # Primary and secondary derive from the actual source-painted muscle regions;
 # the pectoral ROI prevents a dark delt contour acquiring primary colour.
 target=grey[:,:,None]*(SECONDARY[None,None,:]*(1-pw[:,:,None])+PRIMARY[None,None,:]*pw[:,:,None])/255
 rgb=np.round(neutral*(1-tw[:,:,None])+target*tw[:,:,None]).clip(0,255).astype('uint8')
 colourRgba=np.zeros((1024,1536,4),dtype='uint8');colourRgba[:,:,:3]=rgb;colourRgba[:,:,3]=np.where(np.any(rgb!=neutralRgba[:,:,:3],axis=2),255,0)
 Image.fromarray(neutralRgba,'RGBA').save(OUT/f'layers/{k}-neutralize-original-tint.png')
 Image.fromarray(colourRgba,'RGBA').save(OUT/f'layers/{k}-canonical-muscle-colours.png')
 final=Image.fromarray(rgb,'RGB');final.save(OUT/f'{k}-finished.png')
 framed=Image.new('RGB',FRAMED_SIZE,'black');framed.paste(final.crop(CROP),(32,32));framed.save(OUT/f'{k}-framed.png');finished[k]=framed
 layers=[('approved weighted donor',original.convert('RGBA')),('native reauthored belt-chain-plate occlusion window',patch),('neutral original non-target tint',Image.fromarray(neutralRgba,'RGBA')),('canonical pectoral primary and triceps-anterior-delt secondary',Image.fromarray(colourRgba,'RGBA'))]
 root=ET.Element('image',{'w':'1536','h':'1024','name':f'bodyweight-chest-dip-{k}'});stack=ET.SubElement(root,'stack')
 with zipfile.ZipFile(OUT/f'{k}-authoring.ora','w',zipfile.ZIP_DEFLATED) as z:
  z.writestr('mimetype','image/openraster',compress_type=zipfile.ZIP_STORED)
  for j,(name,im) in reversed(list(enumerate(layers))):
   rel=f'data/layer{j}.png';z.writestr(rel,png(im));ET.SubElement(stack,'layer',{'name':name,'src':rel,'opacity':'1.0','visibility':'visible','composite-op':'svg:src-over','x':'0','y':'0'})
  z.writestr('stack.xml',ET.tostring(root));z.writestr('mergedimage.png',png(final))
 framedLayers=[('black whole-canvas padding',Image.new('RGBA',FRAMED_SIZE,(0,0,0,255)))]
 for name,layer in layers:
  fl=Image.new('RGBA',FRAMED_SIZE);fl.alpha_composite(layer.crop(CROP),(32,32));framedLayers.append((name,fl))
 froot=ET.Element('image',{'w':'880','h':'1088','name':f'bodyweight-chest-dip-{k}-framed'});fs=ET.SubElement(froot,'stack')
 with zipfile.ZipFile(OUT/f'{k}-framed.ora','w',zipfile.ZIP_DEFLATED) as z:
  z.writestr('mimetype','image/openraster',compress_type=zipfile.ZIP_STORED)
  for j,(name,layer) in reversed(list(enumerate(framedLayers))):
   rel=f'data/layer{j}.png';z.writestr(rel,png(layer));ET.SubElement(fs,'layer',{'name':name,'src':rel,'opacity':'1.0','visibility':'visible','composite-op':'svg:src-over','x':'0','y':'0'})
  z.writestr('stack.xml',ET.tostring(froot));z.writestr('mergedimage.png',png(framed))
 na=np.asarray(native);oa=np.asarray(original);outside=np.asarray(mask)==0
 headEnd={'A':145,'B':220,'C':270}[k]
 proof[k]={'nativeSize':list(SIZE),'approvedDonor':originalName,'approvedDonorSha256':sha(HERE/'originals'/originalName),'generatedSource':newName,'generatedSourceSha256':sha(HERE/'originals'/newName),'wholeImageIntegerTranslation':[0,32 if k=='C' else 0],'nativeSelectedPixelTransform':'identity after documented whole-image translation; no resampling','occlusionWindowPolygon':polygons[k],'outsideWindowRgbExact':bool(np.array_equal(na[outside],oa[outside])),'headRgbExact':bool(np.array_equal(na[:headEnd,580:730],oa[:headEnd,580:730])),'headDiagnosticRoi':[580,0,730,headEnd],'nearGripRgbExact':bool(np.array_equal(na[335:395,841:895],oa[335:395,841:895])),'nearGripDiagnosticRoi':[841,335,895,395],'farGripRgbExact':bool(np.array_equal(na[335:395,606:667],oa[335:395,606:667])),'fixedStationBaseRgbExact':bool(np.array_equal(na[780:],oa[780:])),'finishedSha256':sha(OUT/f'{k}-finished.png')}
ORDER=['A','B','B','C','B','A']
for i,k in enumerate(ORDER,1):
 finished[k].save(OUT/f'frames/{i}.webp',format='WEBP',lossless=True,method=6)
 finished[k].save(OUT/f'{i}.png')
sheet=Image.new('RGB',(1200,495),'black')
for j,k in enumerate(['A','B','C']):sheet.paste(finished[k].resize((400,495),Image.Resampling.LANCZOS),(400*j,0))
sheet.save(OUT/'review/three-native-pose-contact-sheet.png')
proof['sequence']={'order':ORDER,'t':[0,.5,.5,1,.5,0],'genuinePoses':3,'reused':{'3':'same mid descent as2','5':'same intermediate on ascent','6':'same genuine top as1'},'key':{'primary':['Pectoralis major'],'secondary':['Triceps','Anterior deltoids'],'secondaryFill':'solid'},'canonicalSha256':'fa56dd686d1e8ff88db91b9465255eefd9837f26174acebd18ddb2851d45a72b','palette':{'primary':'#7B72E9','secondary':'#9590E0'},'sourceReference':'approved weighted-chest-dip native1/2/3; those donor files and records remain untouched','framing':{'sameForAllSix':True,'nativeCrop':list(CROP),'padding':[32,32],'publicationSize':list(FRAMED_SIZE),'scale':1,'resampling':False}}
(OUT/'native-production-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
