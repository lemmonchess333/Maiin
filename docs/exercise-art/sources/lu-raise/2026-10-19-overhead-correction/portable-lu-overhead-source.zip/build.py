"""Reproduce the corrected Lu Raise from native sources; no anatomical transforms."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from io import BytesIO
from xml.etree.ElementTree import Element,SubElement,tostring
import argparse,json,hashlib,zipfile,colorsys
import numpy as np
H=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def build(out):
 out.mkdir(parents=True,exist_ok=True)
 for folder in ['source','frames','layers','editables']:(out/folder).mkdir(exist_ok=True)
 facts=[]
 for i in range(1,7):
  src=H/'generated-overhead.png' if i==4 else H/f'inputs/{i}-native-1254.png';base=Image.open(src).convert('RGBA');assert base.size==(1254,1254)
  a=np.array(base);rgb=a[:,:,:3].astype(float);r,g,b=rgb[:,:,0],rgb[:,:,1],rgb[:,:,2]
  support=(b-r>3)&(b-g>5)&(r>=g-2)
  # Canonical H/S with ORIGINAL per-pixel HSL lightness keeps fine deltoid
  # contours/shading, including old saturated pixels; no saturation clipping.
  hue,_,sat=colorsys.rgb_to_hls(123/255,114/255,233/255)
  light=(rgb.max(2)+rgb.min(2))/510
  chroma=(1-np.abs(2*light-1))*sat;x=chroma*(1-abs((hue*6)%2-1));m=light-chroma/2
  mapped=np.stack([m+x,m,m+chroma],2)*255;edited=a.copy();edited[support,:3]=np.rint(mapped[support]).clip(0,255).astype(np.uint8)
  final=Image.fromarray(edited);final.convert('RGB').save(out/f'source/{i}.png');final.convert('RGB').save(out/f'frames/{i}.webp',lossless=True,quality=100,method=6,exact=True)
  assert Image.open(out/f'frames/{i}.webp').convert('RGB').tobytes()==final.convert('RGB').tobytes()
  layer=np.zeros_like(a);layer[support]=edited[support];layer[support,3]=255;colour=Image.fromarray(layer);colour.save(out/f'layers/{i}-palette.png')
  assert Image.alpha_composite(base,colour).tobytes()==final.tobytes()
  root=Element('image',w='1254',h='1254',name=f'Lu Raise {i}');stack=SubElement(root,'stack')
  for name in ['palette','native-source']:SubElement(stack,'layer',name=name,src=f'data/{name}.png',opacity='1.0',visibility='visible',**{'composite-op':'svg:src-over'})
  def png(im):
   stream=BytesIO();im.save(stream,format='PNG');return stream.getvalue()
  with zipfile.ZipFile(out/f'editables/{i}.ora','w') as z:
   for name,data in [('mimetype',b'image/openraster'),('stack.xml',tostring(root)),('data/native-source.png',png(base)),('data/palette.png',png(colour)),('mergedimage.png',png(final))]:
    info=zipfile.ZipInfo(name,(2026,10,19,0,0,0));info.compress_type=zipfile.ZIP_STORED if name=='mimetype' else zipfile.ZIP_DEFLATED;z.writestr(info,data)
  assert not np.any(np.any(edited!=a,2)&~support)
  facts.append({'frame':i,'nativeInput':str(src.relative_to(H)),'nativeSha256':sha(src),'pngSha256':sha(out/f'source/{i}.png'),'webpSha256':sha(out/f'frames/{i}.webp'),'existingColourPixels':int(support.sum()),'outsideColourPixelsUnchanged':True})
 sheet=Image.new('RGB',(1800,600),'#18181c');d=ImageDraw.Draw(sheet);font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',20)
 labels=['Start','Raise laterally','Shoulder height','Continue overhead','Lower laterally','Return']
 for i in range(1,7):
  im=Image.open(out/f'source/{i}.png').convert('RGB');im.thumbnail((296,540));sheet.paste(im,((i-1)*300+(300-im.width)//2,45+(540-im.height)//2));d.text(((i-1)*300+8,10),labels[i-1],font=font,fill='white')
 sheet.save(out/'six-frame-review.png')
 (out/'pixel-proof.json').write_text(json.dumps({'dimensions':[1254,1254],'nativeAnatomicalTransforms':[],'commonCanvas':'Original1536x1024 source padded512top, common integer crop141,256,1395,1510; no resampling. New overhead authored directly at1254 square.','palette':'Existing deltoid chroma only mapped to primary#7B72E9 hue/saturation, preserving original per-pixel HSL lightness and contours; no spatial gradient.','frames':facts},indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'output':str(out),'frames':6,'canvas':[1254,1254]}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=H/'candidate');build(p.parse_args().output)
