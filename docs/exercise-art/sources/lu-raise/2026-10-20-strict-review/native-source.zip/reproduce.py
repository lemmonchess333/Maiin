"""Reproduce native FA56 Lu Raise drawings from four frozen image-authored sources."""
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,colorsys,hashlib,argparse,io,zipfile,xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--output',type=Path,required=True);a=p.parse_args();H=a.root;O=a.output;O.mkdir(parents=True,exist_ok=True)
cfg=json.loads((H/'manifest.json').read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def png(im):b=io.BytesIO();im.save(b,format='PNG');return b.getvalue()
for d in ['source','frames','editables']:(O/d).mkdir(exist_ok=True)
poses={};facts=[]
for row in cfg['poses']:
 k=row['pose'];raw=H/row['original'];assert sha(raw)==row['originalSha256'];im=Image.open(raw).convert('RGB');s=row['combinedWholeSourceScale'];dx,dy=row['wholeSourceTranslation']
 cam=im.transform(tuple(cfg['masterCanvas']),Image.Transform.AFFINE,(1/s,0,-dx/s,0,1/s,-dy/s),Image.Resampling.BICUBIC)
 b=np.asarray(cam).astype(float)/255;out=np.asarray(cam).copy();ch=b.max(2)-b.min(2);mask=(b[:,:,2]>b[:,:,0]+.025)&(b[:,:,2]>b[:,:,1]+.02)&(ch>.035)
 neck=Image.new('1',cam.size);d=ImageDraw.Draw(neck)
 for polygon in cfg['secondaryPolygons']:d.polygon(polygon,fill=1)
 secondary=np.asarray(neck,dtype=bool)&mask;targets=[colorsys.rgb_to_hls(*[v/255 for v in rgb])for rgb in cfg['palette']]
 for y,x in zip(*np.nonzero(mask)):
  h,l,oldS=colorsys.rgb_to_hls(*b[y,x]);newH,_,newS=targets[bool(secondary[y,x])];out[y,x]=np.rint(np.array(colorsys.hls_to_rgb(newH,l,newS*min(1,oldS/.20)))*255).astype('uint8')
 assert np.array_equal(out[~mask],np.asarray(cam)[~mask]);final=Image.fromarray(out).crop(tuple(cfg['crop'])).convert('RGBA');base=cam.crop(tuple(cfg['crop'])).convert('RGBA');m=np.any(np.array(final)!=np.array(base),2);layer=np.zeros_like(np.asarray(final));layer[m]=np.asarray(final)[m];layer=Image.fromarray(layer)
 assert Image.alpha_composite(base,layer).tobytes()==final.tobytes();poses[k]=final
 doc=ET.Element('image',w=str(final.width),h=str(final.height));stack=ET.SubElement(doc,'stack')
 for name,src in [('Canonical source-pigment finishing','data/palette.png'),('Complete native pose, uniformly framed','data/pose.png')]:ET.SubElement(stack,'layer',name=name,src=src,opacity='1.0',visibility='visible',**{'composite-op':'svg:src-over'})
 with zipfile.ZipFile(O/f'editables/{k}.ora','w')as z:
  for name,data in [('mimetype',b'image/openraster'),('stack.xml',ET.tostring(doc)),('data/palette.png',png(layer)),('data/pose.png',png(base)),('mergedimage.png',png(final))]:
   zi=zipfile.ZipInfo(name,(2026,10,20,0,0,0));zi.compress_type=zipfile.ZIP_STORED if name=='mimetype'else zipfile.ZIP_DEFLATED;z.writestr(zi,data)
for n,k in enumerate(cfg['order'],1):
 final=poses[k];final.convert('RGB').save(O/f'source/{n}.png');final.convert('RGB').save(O/f'frames/{n}.webp',lossless=True,quality=100,method=3,exact=True)
 assert Image.open(O/f'frames/{n}.webp').convert('RGBA').tobytes()==final.tobytes();facts.append({'frame':n,'pose':k,'sha256':sha(O/f'frames/{n}.webp'),'nativeRGBA':hashlib.sha256(final.tobytes()).hexdigest()})
(O/'reproduction.json').write_text(json.dumps({'scope':'Four complete image-authored native poses, single uniform whole-source framing, original-pigment canonical colour finishing and common crop. No anatomical warps, individual part fitting or head/shoe grafts.','frames':facts},indent=2)+'\n')
print(json.dumps({'output':str(O),'frames':len(facts),'size':list(final.size)}))
