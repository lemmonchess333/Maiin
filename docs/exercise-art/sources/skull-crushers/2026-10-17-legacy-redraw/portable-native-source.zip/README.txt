Portable skull-crusher redraw source. Python3 with Pillow and NumPy. Run reproduce-full.py; it uses only included source files and makes full-candidate/. No service request or anatomical fitting. Native anatomy stays1x. Four full-native source poses, five-layer ORAs, same-size apparatus, prescribed palette and six lossless870x1072 exports.

Read sequence-plan.json findings before registration. Actual integrated mobile/card/player review and owner release remain separate; all strict certification remains unverified. Earlier exploratory crop sources are held outside this portable package.
