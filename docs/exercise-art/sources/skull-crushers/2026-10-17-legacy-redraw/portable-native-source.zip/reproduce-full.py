"""Full-native skull-crusher family; no donor fitting or anatomy transforms."""
from pathlib import Path
from io import BytesIO
import hashlib,json,zipfile,heapq,math,xml.etree.ElementTree as ET
import numpy as np
from PIL import Image,ImageDraw
P=Path(__file__).resolve().parent;O=P/'full-candidate';O.mkdir(exist_ok=True)
FILES={'A':'A-full-native-lockout-generated.png','B':'B-full-native-early-lower-generated.png','C':'C-full-native-mid-lower-generated.png','D':'D-full-native-scene-generated.png'}
BODY=(1536,1024);PAD=(0,48);SIZE=(1536,1072);CROP=(240,0,1110,1072)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
base=Image.open(P/FILES['D']).convert('RGBA');assert base.size==BODY
def png(im):b=BytesIO();im.save(b,format='PNG');return b.getvalue()
def ora(path,layers,merged):
    root=ET.Element('image',{'version':'0.0.3','w':str(SIZE[0]),'h':str(SIZE[1])});stack=ET.SubElement(root,'stack')
    with zipfile.ZipFile(path,'w') as z:
        def put(n,b,kind=zipfile.ZIP_DEFLATED):
            i=zipfile.ZipInfo(n,(2026,10,17,0,0,0));i.compress_type=kind;z.writestr(i,b)
        put('mimetype','image/openraster',zipfile.ZIP_STORED)
        for i,(name,im) in enumerate(reversed(layers)):
            f=f'data/layer{i}.png';put(f,png(im));ET.SubElement(stack,'layer',{'name':name,'src':f,'opacity':'1','visibility':'visible','composite-op':'svg:src-over','x':'0','y':'0'})
        put('stack.xml',ET.tostring(root));put('mergedimage.png',png(merged))
def pad(im,transparent=False):
    out=Image.new('RGBA',SIZE,(0,0,0,0) if transparent else (0,0,0,255));out.paste(im,PAD);return out
def source_regions(name,rgb,violet):
    seeds={1:[(541,295),(742,278)],2:[(550,389),(771,370),(636,366),(707,351)]}
    if name=='D':seeds[1]=[(568,303),(778,272)]
    h,w=violet.shape;grad=np.zeros((h,w),float)
    for dy,dx in [(1,0),(-1,0),(0,1),(0,-1)]:grad=np.maximum(grad,np.max(np.abs(rgb-np.roll(np.roll(rgb,dy,0),dx,1)),2))
    owner=np.full((h,w),-1,np.int8);best=np.full((h,w),np.inf);dist=np.full((h,w),np.inf);q=[];ys,xs=np.where(violet)
    for role,pts in seeds.items():
        for x,y in pts:
            j=np.argmin((xs-x)**2+(ys-y)**2);a,b=int(ys[j]),int(xs[j]);best[a,b]=0;dist[a,b]=0;owner[a,b]=role;heapq.heappush(q,(0,0,a,b,role))
    while q:
        cost,length,y,x,role=heapq.heappop(q)
        if cost!=best[y,x] or length!=dist[y,x]:continue
        for a,b in [(y-1,x),(y+1,x),(y,x-1),(y,x+1)]:
            if not(0<=a<h and 0<=b<w and violet[a,b]):continue
            c=max(cost,round(float(grad[a,b]),1));dd=length+1
            if (c,dd)<(best[a,b],dist[a,b]):best[a,b]=c;dist[a,b]=dd;owner[a,b]=role;heapq.heappush(q,(c,dd,a,b,role))
    for y,x in zip(*np.where(violet&(owner<0))):owner[y,x]=min(((x-a)**2+(y-b)**2,role) for role,pts in seeds.items() for a,b in pts)[1]
    return violet&(owner==1),violet&(owner==2)

GRIPS={'A':[(515,103),(665,87)],'B':[(515,132),(665,115)],'C':[(550,180),(687,162)],'D':[(520,195),(650,179)]}
OLD={'A':[(316,0,420,200),(758,0,877,151),(258,124,920,58)],'B':[(316,88,421,232),(758,13,879,181),(258,157,920,85)],'C':[(364,108,470,280),(772,69,885,226),(311,207,926,133)],'D':[(320,124,434,305),(764,72,881,242),(264,229,921,140)]}
def gear(name):
    # One custom illustrative bar, constant dimensions and plate silhouettes.
    # Equipment geometry is code-authored under the standing equipment approval.
    scale=4;im=Image.new('RGBA',(SIZE[0]*scale,SIZE[1]*scale));d=ImageDraw.Draw(im)
    grips=np.array(GRIPS[name],float);theta=math.atan2(grips[1,1]-grips[0,1],grips[1,0]-grips[0,0]);u=np.array([math.cos(theta),math.sin(theta)]);v=np.array([-u[1],u[0]]);center=grips.mean(0)+np.array([11,48])
    def line(a,b,fill,width):d.line([tuple(a*scale),tuple(b*scale)],fill=fill,width=round(width*scale))
    def oval(c,rx,ry,fill,outline=None,width=1):
        pts=[tuple((c+u*rx*math.cos(t)+v*ry*math.sin(t))*scale) for t in np.linspace(0,2*math.pi,129)];d.polygon(pts,fill=fill)
        if outline:d.line(pts,fill=outline,width=round(width*scale))
    start=center-u*327;end=center+u*327
    line(start,end,(70,70,72,255),9);line(start-v*1.2,end-v*1.2,(181,181,183,255),6);line(start-v*2.1,end-v*2.1,(226,226,228,255),1.5)
    plates=[]
    for side,offset,rx,ry in [('near',-225,48,83),('far',225,45,76)]:
        c=center+u*offset;oval(c+u*10,rx,ry,(38,38,40,255),(64,64,66,255));oval(c,rx,ry,(61,61,63,255),(103,103,105,255));oval(c,rx*.86,ry*.86,(48,48,50,255),(29,29,31,255),1.2);oval(c,rx*.61,ry*.61,(53,53,55,255),(72,72,74,255));oval(c,rx*.19,ry*.19,(35,35,37,255),(92,92,94,255));oval(c,rx*.09,ry*.09,(139,139,141,255),(43,43,45,255))
        # Outboard sleeve projects from each visible hub.
        if offset<0:line(c,start,(111,111,113,255),10);line(c-v*2,start-v*2,(207,207,209,255),2)
        else:line(c,end,(111,111,113,255),9);line(c-v*2,end-v*2,(207,207,209,255),2)
        plates.append({'side':side,'center':c.tolist(),'projectedRadii':[rx,ry]})
    oval(start,2.4,4.5,(41,41,43,255),(154,154,156,255),.8);oval(end,2.1,4,(84,84,86,255),(168,168,170,255),.8)
    return im.resize(SIZE,Image.Resampling.LANCZOS),{'center':center.tolist(),'shaftLength':654,'plateCentersDistance':450,'angleRadians':theta,'plates':plates,'sameDimensionsAllPoses':True}

facts=[]
for n,file in FILES.items():
    source=Image.open(P/file).convert('RGBA');assert source.size==BODY
    m=Image.new('L',BODY);d=ImageDraw.Draw(m);d.rectangle((0,0,1535,448),fill=255)
    # The complete new master, rather than donor JM joints, fixes the scene.
    # The complete generated upper scene includes its naturally occluded head;
    # no head pixel graft or individual-part fitting is performed.
    sel=np.array(m);a0=np.array(base);a1=np.array(source);yy,xx=np.indices(sel.shape)
    bench=(yy>300)&(xx<570)&(a0[:,:,:3].max(2)<170)&(np.ptp(a0[:,:,:3],2)<20)&(a1[:,:,:3].max(2)<170);sel[bench]=0
    moving=source.copy();moving.putalpha(Image.fromarray(sel));scene=Image.alpha_composite(base,moving)
    # Clear only old generated apparatus pixels; hands/arms are restored as
    # native source pixels over the new constant apparatus.
    clear=Image.new('L',BODY);dd=ImageDraw.Draw(clear)
    for x0,y0,x1,y1 in OLD[n][:2]:dd.rectangle((x0-8,y0-8,x1+8,y1+8),fill=255)
    x0,y0,x1,y1=OLD[n][2];dd.line((x0-8,y0,x1+8,y1),fill=255,width=36)
    raw=np.array(scene);domain=np.array(clear)>0
    rgb=raw[:,:,:3];white=(rgb.min(2)>165)&(rgb.max(2)>185);violet=(rgb[:,:,2]-np.minimum(rgb[:,:,0],rgb[:,:,1])>8)&(rgb.max(2)>70)
    bx0,by0,bx1,by1=OLD[n][2];bar_y=by0+(xx-bx0)*(by1-by0)/(bx1-bx0)
    human=domain&(white|violet)&(xx>475)&(xx<810)&(yy>bar_y+15)
    # Hands' source silhouettes include their dark contour pixels as well.
    hand_domain=np.zeros(BODY[::-1],bool)
    for x,y in GRIPS[n]:
        hand=Image.new('L',BODY);hd=ImageDraw.Draw(hand);hd.polygon([(x-25,y-10),(x-18,y-22),(x,y-24),(x+18,y-18),(x+25,y-5),(x+21,y+10),(x+17,y+28),(x,y+33),(x-20,y+24),(x-27,y+8)],fill=255)
        hand_domain|=np.array(hand)>0;human|=domain&(np.array(hand)>0)&(rgb.max(2)>70)
    # Reflected old plate rims can be bright like skin. Retain contiguous
    # body/hand components, and remove only isolated apparatus remnants.
    seen=np.zeros(human.shape,bool)
    for sy,sx in zip(*np.where(human)):
        if seen[sy,sx]:continue
        component=[];q=[(int(sy),int(sx))];seen[sy,sx]=True
        while q:
            y,x=q.pop();component.append((y,x))
            for a,b in [(y-1,x),(y+1,x),(y,x-1),(y,x+1)]:
                if 0<=a<BODY[1] and 0<=b<BODY[0] and human[a,b] and not seen[a,b]:seen[a,b]=True;q.append((a,b))
        if len(component)<80 and not any(hand_domain[y,x] for y,x in component):
            for y,x in component:human[y,x]=False
    cleaned=raw.copy();cleaned[domain]=[0,0,0,255]
    newgear,gearproof=gear(n);finished=Image.alpha_composite(pad(Image.fromarray(cleaned)),newgear)
    restore=np.zeros_like(raw);restore[human]=raw[human];finished=Image.alpha_composite(finished,pad(Image.fromarray(restore),True))
    aa=np.array(finished);rgb=aa[:,:,:3].astype(float);mx=rgb.max(2);mn=rgb.min(2);sat=(mx-mn)/np.maximum(mx,1);violet=(rgb[:,:,2]-np.minimum(rgb[:,:,0],rgb[:,:,1])>8)&(mx>70)&(np.indices(mx.shape)[0]<497)
    # Convert seeds to common padded native coordinates.
    pri,sec=source_regions(n,np.roll(rgb,-48,axis=0),np.roll(violet,-48,axis=0));pri=np.roll(pri,48,axis=0);sec=np.roll(sec,48,axis=0)
    out=aa.copy()
    for role,mask,target,ref in [('primary',pri,(123,114,233),.65),('secondary',sec,(149,144,224),.35)]:
        amount=np.clip(sat/ref,0,1);tint=mx[:,:,None]*(1-amount[:,:,None]*(1-np.array(target)/255));out[mask,:3]=np.rint(tint[mask]).clip(0,255).astype('uint8');Image.fromarray(mask.astype('uint8')*255).save(O/f'{n}-{role}-mask.png')
    palette=np.zeros_like(out);changed=np.any(aa!=out,2);palette[changed]=out[changed];final=Image.fromarray(out)
    final.save(O/f'{n}-native.png');pad(moving,True).save(O/f'{n}-moving-source-layer.png');newgear.save(O/f'{n}-constant-equipment-layer.png');Image.fromarray(palette).save(O/f'{n}-palette-layer.png')
    originalp=pad(base);sourcep=pad(scene);cleanp=pad(Image.fromarray(cleaned));clean_delta=np.zeros_like(np.array(cleanp));dc=np.any(np.array(originalp)!=np.array(cleanp),2);clean_delta[dc]=np.array(cleanp)[dc]
    restoredp=pad(Image.fromarray(restore),True)
    ora(O/f'{n}-editable.ora',[('Complete new native supported master',originalp),('Connected generated upper scene and generated-equipment cleanup at unchanged coordinates',Image.fromarray(clean_delta)),('Constant-size custom grey apparatus',newgear),('Native generated closed hands and arm overlap',restoredp),('Approved source-tone primary and secondary palette',Image.fromarray(palette))],final)
    assert np.array_equal(out[48+449:,:,:],np.array(pad(base))[48+449:,:,:])
    facts.append({'pose':n,'source':file,'sourceSha256':sha(P/file),'anatomyScale':1,'anatomicalTransforms':0,'fixedCompleteNewMaster':FILES['D'],'fixedSceneExactFromNativeY':449,'nativePadding':PAD,'bodyPartFitting':False,'equipment':gearproof,'primaryPixels':int(pri.sum()),'secondaryPixels':int(sec.sum())})
(O/'frames').mkdir(exist_ok=True);order=['A','B','C','D','C','A']
for i,n in enumerate(order,1):
    im=Image.open(O/f'{n}-native.png').crop(CROP).convert('RGB');im.save(O/f'frames/{i}.webp',lossless=True,quality=100,method=4);assert Image.open(O/f'frames/{i}.webp').convert('RGB').tobytes()==im.tobytes()
sheet=Image.new('RGB',(870*3,1072*2))
for i,n in enumerate(order):sheet.paste(Image.open(O/f'{n}-native.png').crop(CROP).convert('RGB'),((i%3)*870,(i//3)*1072))
sheet.save(O/'six-native-contact-sheet.png')
(O/'reproduction-proof.json').write_text(json.dumps({'dimensions':[870,1072],'nativeCanvas':SIZE,'crop':CROP,'sourcePoseOrder':order,'physicalPoses':4,'states':facts,'primary':['Triceps'],'secondary':['Chest','Front deltoids'],'strictCertified':False,'registered':False},indent=2)+'\n',encoding='utf8')
print(json.dumps({'exported':6,'physicalPoses':4,'dimensions':[870,1072],'fixedNewScene':True,'strictCertified':False,'registered':False}))
