Skull Crushers equipment correction - 2026-10-18

The accepted 2026-10-17 artwork had oversized flat discs, excess bare sleeve length,
and an isolated remnant of the original generated plate above the left weight in B.
This revision only substitutes the native grey equipment layer and removes that
isolated background remnant. It generates no athlete or pose and edits no anatomy.

The original four five-layer OpenRaster sources and native renders are immutable
inputs in original-native. The original six public frames are retained separately.
reproduce-equipment.py requires Python, Pillow and numpy. Run it from any directory.
It produces candidate native scenes, six lossless PNG/WebP outputs, revised editable
OpenRaster files, old/new equipment-alpha masks and a proof. No repo checkout needed.

All non-equipment input layers are passed through byte-exact. Existing closed hand,
arm overlap and muscle-palette foreground pixels remain exact. Changes must stay in
the union of old/new equipment alpha and the explicitly separate B remnant mask.
The compact rigid bar is 490 native px long with 390 px plate-centre spacing, against
the former 654/450; discs are 110/104 px high against the former 166/152. One camera
depth convention, neutral grey cast-disc shading, compact sleeves and collars are
used throughout. Plate spacing clears the unaltered elbow silhouette in every pose.

All four native poses have been inspected. A/B/C/D/C/A order, 0/.3/.8/1/.8/0 movement
coordinates, crop, canvas, palette, white trainers, no shorts, cues and card frame 3
remain unchanged. The dimensions are illustrative and not a calibrated load model.
The original source pose limitations remain; no new strict certification is claimed.
Project/integrated playback/card checks are the parent publication task's work.
