"""Equipment-only correction; recompose retained native layers without any anatomy edit."""
from pathlib import Path
from io import BytesIO
import json, hashlib, zipfile, xml.etree.ElementTree as ET, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont

P=Path(__file__).resolve().parent
ROOT=P.parents[1]
SRC=P/'original-native' if (P/'original-native').exists() else ROOT/'legacy-six-redraw-20261017/skull-crushers/portable-full-source/full-candidate'
REPO=ROOT/'Maiin-burpees'
ORIGINAL_FRAMES=P/'original-public-frames' if (P/'original-public-frames').exists() else REPO/'public/form-frames/skull-crushers'
OUT=P/'candidate';OUT.mkdir(exist_ok=True)
SIZE=(1536,1072);CROP=(240,0,1110,1072)
GRIPS={'A':[(515,103),(665,87)],'B':[(515,132),(665,115)],'C':[(550,180),(687,162)],'D':[(520,195),(650,179)]}
ORDER=['A','B','C','D','C','A']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def native_layers(pose):
    with zipfile.ZipFile(SRC/f'{pose}-editable.ora') as z:
        layers=[]
        for item in reversed(list(ET.fromstring(z.read('stack.xml')).find('stack'))):
            layers.append((item.attrib['name'],Image.open(BytesIO(z.read(item.attrib['src']))).convert('RGBA')))
        return layers

def merge(layers):
    result=Image.new('RGBA',SIZE)
    for name,im in layers:result=Image.alpha_composite(result,im)
    return result

def png(im):
    out=BytesIO();im.save(out,format='PNG');return out.getvalue()

def ora(path,layers,merged):
    root=ET.Element('image',{'version':'0.0.3','w':str(SIZE[0]),'h':str(SIZE[1])});stack=ET.SubElement(root,'stack')
    with zipfile.ZipFile(path,'w') as z:
        def put(name,data,kind=zipfile.ZIP_DEFLATED):
            info=zipfile.ZipInfo(name,(2026,10,18,0,0,0));info.compress_type=kind;z.writestr(info,data)
        put('mimetype','image/openraster',zipfile.ZIP_STORED)
        for i,(name,im) in enumerate(reversed(layers)):
            f=f'data/layer{i}.png';put(f,png(im));ET.SubElement(stack,'layer',{'name':name,'src':f,'opacity':'1','visibility':'visible','composite-op':'svg:src-over','x':'0','y':'0'})
        put('stack.xml',ET.tostring(root));put('mergedimage.png',png(merged))

def gear(pose):
    # One rigid compact straight bar; only its in-plane orientation/translation follows existing grips.
    # Camera depth stays coherent across both plates; sleeves/collars project outboard on their own ends.
    s=4
    g=np.array(GRIPS[pose],float)
    theta=math.atan2(*(g[1]-g[0])[::-1]);u=np.array([math.cos(theta),math.sin(theta)]);v=np.array([-u[1],u[0]])
    center=g.mean(0)+[11,48]
    # Work in a small absolute-coordinate window to keep supersampling deterministic and cheap.
    origin=np.floor(center-[270,115]).astype(int);wh=(540,230)
    im=Image.new('RGBA',(wh[0]*s,wh[1]*s));d=ImageDraw.Draw(im)
    def pt(p):return tuple((np.array(p)-origin)*s)
    def line(a,b,color,width):d.line([pt(a),pt(b)],fill=(*[int(color)]*3,255),width=round(width*s))
    def ellipse(c,rx,ry,base=70,rim=False,metal=False):
        # Continuous neutral-grey material and a restrained top-left light, not concentric flat discs.
        minxy=np.floor(c-[rx+ry*.2+3,ry+rx*.2+3]).astype(int)
        maxxy=np.ceil(c+[rx+ry*.2+3,ry+rx*.2+3]).astype(int)
        yy,xx=np.mgrid[minxy[1]*s:maxxy[1]*s,minxy[0]*s:maxxy[0]*s]
        delta=np.stack([xx/s-c[0],yy/s-c[1]],axis=-1)
        x=delta@u/rx;y=delta@v/ry;r=np.sqrt(x*x+y*y)
        alpha=(r<=1).astype('uint8')*255
        val=base+8*(-.5*x-.85*y)+4*(1-r*r)
        if rim:
            band=np.clip((r-.87)/.13,0,1)
            edge_light=69+59*np.clip(-.65*x-.75*y,0,1)-17*np.clip(.65*x+.75*y,0,1)
            val=val*(1-band)+edge_light*band
        if metal:
            val=base+55*np.exp(-((y+.3)/.2)**2)-45*np.clip(y,0,1)
        a=np.empty((*r.shape,4),np.uint8);a[:,:,:3]=np.rint(np.clip(val,0,255))[:,:,None];a[:,:,3]=alpha
        layer=Image.fromarray(a)
        im.alpha_composite(layer,((minxy[0]-origin[0])*s,(minxy[1]-origin[1])*s))
    def cylinder(a,b,radius):
        # A cylindrical highlight across the same physical shaft width.
        line(a,b,55,radius*2)
        for f,col,w in [(.05,104,1.6),(-.2,167,1.1),(-.45,214,.65),(.48,68,.7)]:
            line(a+v*radius*f,b+v*radius*f,col,radius*w)
    start=center-u*245;end=center+u*245
    cylinder(start,end,3.8)
    plate_data=[]
    for offset,rx,ry in [(-195,29,55),(195,27.5,52)]:
        c=center+u*offset
        # Cast-disc depth in a single consistent projected axis; front faces sit at c.
        ellipse(c+u*10,rx,ry,49,True)
        ellipse(c+u*5,rx,ry,55,True)
        ellipse(c,rx,ry,67,True)
        # One recessed inner face, one central steel hub. No decorative plate rings.
        ellipse(c,rx*.84,ry*.84,62)
        # Very fine perimeter definition and central hole read at mobile scale.
        ellipse(c,rx*.2,ry*.2,125,False,True)
        ellipse(c,rx*.11,ry*.11,44)
        # Sleeve only beyond the centre of its plate, with a compact outboard collar.
        sign=-1 if offset<0 else 1
        endpt=start if sign<0 else end
        cylinder(c,endpt,4.5)
        collar=c+u*sign*(rx*.85+7)
        ellipse(collar,3,8.5,126,False,True)
        ellipse(endpt,2.2,4.5,101,False,True)
        plate_data.append({'center':c.tolist(),'radii':[rx,ry],'depth':10,'outboardSleeveEnd':endpt.tolist()})
    full=Image.new('RGBA',SIZE);full.alpha_composite(im.resize(wh,Image.Resampling.LANCZOS),tuple(origin))
    return full,{'shaftLength':490,'plateCentresDistance':390,'gripSpacing':float(np.linalg.norm(g[1]-g[0])),'center':center.tolist(),'theta':theta,'plateData':plate_data,'rigidSameDimensions':True}

facts=[];natives={}
for pose in 'ABCD':
    layers=native_layers(pose)
    old=merge(layers)
    expected=Image.open(SRC/f'{pose}-native.png').convert('RGBA')
    assert np.array_equal(np.array(old),np.array(expected)),pose+' native layer mismatch'
    oldeq=next(im for n,im in layers if n=='Constant-size custom grey apparatus')
    neweq,geo=gear(pose)
    # One isolated old generated plate cap escaped the former B cleanup above y128.
    # It is wholly in background, native x335..395/y111..127, with no athlete nearby.
    cleanup=Image.new('RGBA',SIZE)
    if pose=='B':
        cd=ImageDraw.Draw(cleanup);cd.rectangle((330,105,405,127),fill=(0,0,0,255))
    revised=[]
    for n,im in layers:
        if n=='Constant-size custom grey apparatus':
            revised.extend([('Remove isolated old generated plate cap in background',cleanup),('Compact rigid neutral-grey barbell',neweq)])
        else:revised.append((n,im))
    candidate=merge(revised)
    a=np.array(old);b=np.array(candidate)
    replacement=(np.array(oldeq)[:,:,3]>0)|(np.array(neweq)[:,:,3]>0)
    extra=np.array(cleanup)[:,:,3]>0
    union=replacement|extra
    diff=np.any(a!=b,2)
    assert not np.any(diff&~union),'change outside old/new equipment support'
    # Foreground hand/arm and final muscle palette layers are passed through byte-exact.
    for an,ai in layers:
        if an!='Constant-size custom grey apparatus':
            bi=next(im for name,im in revised if name==an);assert ai.tobytes()==bi.tobytes()
    hands=next(im for n,im in layers if n=='Native generated closed hands and arm overlap')
    palette=next(im for n,im in layers if n=='Approved source-tone primary and secondary palette')
    foreground=(np.array(hands)[:,:,3]==255)|(np.array(palette)[:,:,3]==255)
    assert not np.any(diff&foreground),'native hand/arm or palette foreground changed'
    # Audit visible neutral anatomy away from old apparatus. Its source silhouettes and shadows
    # have no equipment overlap here; any change would expose an unintended new body occlusion.
    visible_white=(a[:,:,:3].max(2)>170)&(np.ptp(a[:,:,:3],2)<30)&(np.array(oldeq)[:,:,3]==0)
    assert not np.any(diff&visible_white),'new equipment overwrites visible neutral athlete'
    Image.fromarray(union.astype('uint8')*255).save(OUT/f'{pose}-old-new-equipment-union.png')
    Image.fromarray(replacement.astype('uint8')*255).save(OUT/f'{pose}-replacement-alpha-support.png')
    cleanup.save(OUT/f'{pose}-isolated-remnant-cleanup.png')
    oldeq.save(OUT/f'{pose}-old-equipment.png');neweq.save(OUT/f'{pose}-equipment.png')
    candidate.save(OUT/f'{pose}-native.png');ora(OUT/f'{pose}-editable.ora',revised,candidate)
    natives[pose]=candidate
    facts.append({'pose':pose,'inputOraSha256':sha(SRC/f'{pose}-editable.ora'),'inputNativeSha256':sha(SRC/f'{pose}-native.png'),'outputNativeSha256':sha(OUT/f'{pose}-native.png'),'changedPixels':int(diff.sum()),'outsideEquipmentUnionChangedPixels':int((diff&~union).sum()),'outsideReplacementAlphaChangedPixels':int((diff&~replacement).sum()),'withinIsolatedRemnantMaskChangedPixels':int((diff&extra).sum()),'allNonEquipmentLayersByteExact':True,'nativeHandArmAndPaletteForegroundChangedPixels':int((diff&foreground).sum()),'visibleNeutralAthleteChangedPixels':int((diff&visible_white).sum()),'isolatedRemnantCleanupNativeRectangle':[330,105,405,127] if pose=='B' else None,'geometry':geo})

(OUT/'frames').mkdir(exist_ok=True);(OUT/'source').mkdir(exist_ok=True)
frames=[]
for i,pose in enumerate(ORDER,1):
    im=natives[pose].crop(CROP).convert('RGB')
    im.save(OUT/f'source/{i}.png');im.save(OUT/f'frames/{i}.webp',lossless=True,quality=100,method=4)
    assert Image.open(OUT/f'frames/{i}.webp').convert('RGB').tobytes()==im.tobytes()
    current=ORIGINAL_FRAMES/f'{i}.webp'
    assert Image.open(current).convert('RGB').tobytes()==Image.open(SRC/f'frames/{i}.webp').convert('RGB').tobytes()
    frames.append({'frame':i,'pose':pose,'currentWebpSha256':sha(current),'candidateSourceSha256':sha(OUT/f'source/{i}.png'),'candidateWebpSha256':sha(OUT/f'frames/{i}.webp')})

before=Image.open(ORIGINAL_FRAMES/'4.webp').convert('RGB');after=Image.open(OUT/'frames/4.webp').convert('RGB')
comparison=Image.new('RGB',(1740,1112),(17,17,20));comparison.paste(before,(0,40));comparison.paste(after,(870,40));d=ImageDraw.Draw(comparison);d.text((18,12),'CURRENT - oversized flat plates / long sleeves',fill='white');d.text((888,12),'CORRECTED - compact grey bar / shaded plates',fill='white');comparison.save(P/'skull-before-after.png')
crop=Image.new('RGB',(1740,390),(17,17,20));crop.paste(before.crop((0,80,870,430)),(0,40));crop.paste(after.crop((0,80,870,430)),(870,40));d=ImageDraw.Draw(crop);d.text((18,12),'CURRENT',fill='white');d.text((888,12),'CORRECTED',fill='white');crop.save(P/'skull-equipment-before-after.png')
sheet=Image.new('RGB',(870*3,1072*2))
for i in range(6):sheet.paste(Image.open(OUT/f'frames/{i+1}.webp'),((i%3)*870,(i//3)*1072))
sheet.save(P/'skull-six-corrected.png')
(P/'proof.json').write_text(json.dumps({'exercise':'skull-crushers','method':'native equipment layer substitution only','dimensions':[870,1072],'order':ORDER,'sourceNativeCanvas':SIZE,'crop':CROP,'anatomyTransforms':0,'anatomyGeneration':False,'nonEquipmentLayersByteExact':True,'paletteChanges':False,'states':facts,'frames':frames},indent=2)+'\n',encoding='utf8')
print(json.dumps({'states':len(facts),'frames':len(frames),'nonEquipmentLayersByteExact':True,'out':str(OUT)}))
