"""Portable calf model correction: same-coordinate generated hip layer + palette.

All apparatus, head, torso, contacts, trainers and calf contours are original.
No geometry transforms are used. Requires Pillow and NumPy.
"""
from pathlib import Path
from io import BytesIO
from hashlib import sha256
from xml.etree.ElementTree import Element, SubElement, tostring
import argparse, json, zipfile
import numpy as np
from PIL import Image, ImageDraw

HERE=Path(__file__).resolve().parent
ORDER=[1,2,3,3,2,1]
ORIGINAL={1:'749ea229ad1ddc8aebf82ead0cec205218f92d5cebe089adbb3bdb557269de74',2:'23cbcf0e88e2efd7db9ba1e690fa9a20faf78f46dc19f56e6f5eba693f61dd27',3:'959e1493733e96683d754d28ee3597ccd9a24671130225fcdc354d1d0cfaa76f'}
GENERATED={1:'564996e14ca9b84d76dfe56886fa1283246b2a2fcbe20ea0cae174fb63e43e15',2:'9fcf0f8b4d231d1372dfc1cf17be56c33a2df0d35cdb821eb165028cc5fa4109',3:'efde9282b99fe610152bb897e6ceb5b0e40e984114a1b0b107bf6287ad5df6dc'}
P=np.array([123,114,233],float); S=np.array([149,144,224],float)
WINDOW={1:(552,524,846,901),2:(552,524,846,900),3:(552,494,846,861)}
PRIMARY={1:[
 [(671,901),(691,919),(711,945),(724,974),(729,1000),(728,1023),(719,1049),(704,1065),(689,1069),(677,1063),(664,1053),(655,1036),(650,1013),(649,991),(652,964),(661,931)],
 [(775,900),(790,916),(807,938),(821,965),(832,991),(838,1014),(837,1036),(831,1054),(818,1066),(802,1066),(789,1056),(778,1039),(771,1017),(767,991),(767,965),(769,938)]
]}
PRIMARY[2]=PRIMARY[1]
PRIMARY[3]=[
 [(667,863),(683,878),(703,906),(714,934),(724,962),(728,985),(723,1005),(714,1019),(702,1027),(688,1026),(675,1016),(662,1002),(651,983),(644,960),(643,938),(648,914),(656,888)],
 [(771,856),(787,871),(802,895),(815,921),(825,949),(831,975),(829,996),(823,1012),(812,1023),(798,1022),(785,1013),(775,996),(768,975),(763,950),(760,923),(763,890)]
]
ROI={1:(620,875,850,1170),2:(620,875,850,1170),3:(620,835,850,1135)}

def digest(p):return sha256(p.read_bytes()).hexdigest()
def rgb(p):return Image.open(p).convert('RGB')
def png(im):
 b=BytesIO();im.save(b,format='PNG');return b.getvalue()
def write_json(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')

def hip_layer(original,generated,pose):
 assert original.size==generated.size==(1024,1536)
 x1,y1,x2,y2=WINDOW[pose];mask=np.zeros((1536,1024),np.uint8)
 # Uniform12px source-over seam, changing opacity only, never coordinates.
 yy,xx=np.mgrid[y1:y2,x1:x2]
 edge=np.minimum.reduce([xx-x1,x2-1-xx,yy-y1,y2-1-yy])
 mask[y1:y2,x1:x2]=np.rint(np.clip(edge/12,0,1)*255).astype(np.uint8)
 layer=generated.convert('RGBA');layer.putalpha(Image.fromarray(mask))
 return Image.alpha_composite(original.convert('RGBA'),layer),layer,Image.fromarray(mask)

def palette(original,pose):
 a=np.array(original.convert('RGBA'));c=a[:,:,:3].astype(float)
 r,g,b=c[:,:,0],c[:,:,1],c[:,:,2]
 region=np.zeros(a.shape[:2],bool);x1,y1,x2,y2=ROI[pose];region[y1:y2,x1:x2]=True
 support=region&(b-r>=2)&(b-g>=3)&(r-g>=-2)
 role=Image.new('L',(4096,6144));d=ImageDraw.Draw(role)
 for poly in PRIMARY[pose]:d.polygon([(x*4,y*4) for x,y in poly],fill=255)
 role=role.resize(original.size,Image.Resampling.LANCZOS)
 weight=np.array(role,dtype=float)/255;weight[~support]=0
 maximum=c.max(2);strength=(maximum-g)/np.maximum(maximum,1)
 neutral=maximum[:,:,None]
 pc=neutral+(P*maximum[:,:,None]/255-neutral)*np.minimum(strength/.62,1)[:,:,None]
 sc=neutral+(S*maximum[:,:,None]/255-neutral)*np.minimum(strength/.42,1)[:,:,None]
 result=pc*weight[:,:,None]+sc*(1-weight[:,:,None])
 edited=a.copy();edited[support,:3]=np.rint(np.clip(result[support],0,255)).astype(np.uint8)
 layer=np.zeros_like(a);layer[support]=edited[support];layer[support,3]=255
 assert not np.any(np.any(edited!=a,2)&~support)
 return Image.fromarray(layer),Image.fromarray((support*255).astype(np.uint8)),role

def ora(path,layers,merged):
 doc=Element('image',w='1024',h='1536',name='Standing calf raise approved model correction')
 stack=SubElement(doc,'stack')
 for name,im in reversed(layers):SubElement(stack,'layer',name=name,src=f'data/{name}.png',opacity='1.0',visibility='visible',**{'composite-op':'svg:src-over'})
 with zipfile.ZipFile(path,'w') as z:
  items=[('mimetype',b'image/openraster',zipfile.ZIP_STORED),('stack.xml',tostring(doc,encoding='utf-8'),zipfile.ZIP_DEFLATED)]
  items += [(f'data/{name}.png',png(im),zipfile.ZIP_DEFLATED) for name,im in layers]
  items += [('mergedimage.png',png(merged),zipfile.ZIP_DEFLATED)]
  for name,data,comp in items:
   info=zipfile.ZipInfo(name,(2026,10,18,0,0,0));info.compress_type=comp;z.writestr(info,data)
 with zipfile.ZipFile(path) as z:
  reopened=Image.new('RGBA',merged.size)
  for name,_ in layers:reopened=Image.alpha_composite(reopened,Image.open(BytesIO(z.read(f'data/{name}.png'))).convert('RGBA'))
  assert reopened.tobytes()==merged.tobytes()

def verify_ora(path,layers,merged):
 with zipfile.ZipFile(path) as z:
  reopened=Image.new('RGBA',merged.size)
  for name,im in layers:
   layer=Image.open(BytesIO(z.read(f'data/{name}.png'))).convert('RGBA')
   assert layer.tobytes()==im.tobytes(),(path,name)
   reopened=Image.alpha_composite(reopened,layer)
  assert reopened.tobytes()==merged.tobytes()
  assert Image.open(BytesIO(z.read('mergedimage.png'))).convert('RGBA').tobytes()==merged.tobytes()

def run(args):
 root=args.output_dir.resolve();candidate=root/'candidate'
 if not args.verify:
  for name in ['frames','source','editables','layers','review']:(candidate/name).mkdir(parents=True,exist_ok=True)
 rows=[]
 for pose in args.poses:
  src=HERE/'inputs'/f'{pose}-original.png';gen=HERE/'generated'/f'{pose}-mannequin-edit.png'
  assert digest(src)==ORIGINAL[pose];assert digest(gen)==GENERATED[pose]
  original=rgb(src);generated=rgb(gen)
  merged,hip,mask=hip_layer(original,generated,pose)
  colour,support,role=palette(original,pose)
  merged=Image.alpha_composite(merged,colour)
  layers=[('original',original.convert('RGBA')),('generated-hip',hip),('existing-fields-palette',colour)]
  if not args.verify:
   original.save(candidate/'source'/f'{pose}-original.png')
   merged.convert('RGB').save(candidate/'source'/f'{pose}.png')
   for name,im in [('hip',hip),('hip-mask',mask),('colour',colour),('colour-support',support),('primary-role',role)]:im.save(candidate/'layers'/f'{pose}-{name}.png')
   ora(candidate/'editables'/f'{pose}.ora',layers,merged)
  else:
   assert rgb(candidate/'source'/f'{pose}.png').tobytes()==merged.convert('RGB').tobytes()
   for name,im in [('hip',hip),('hip-mask',mask),('colour',colour),('colour-support',support),('primary-role',role)]:assert Image.open(candidate/'layers'/f'{pose}-{name}.png').tobytes()==im.tobytes()
   verify_ora(candidate/'editables'/f'{pose}.ora',layers,merged)
  a=np.array(original);b=np.array(merged)[:,:,:3];changed=np.any(a!=b,2)
  union=(np.array(mask)>0)|(np.array(support)>0)
  assert not np.any(changed&~union)
  assert np.array_equal(a[:524],b[:524]) if pose==1 else True
  assert np.array_equal(a[:,0:530],b[:,0:530])
  assert np.array_equal(a[1170:],b[1170:])
  assert np.array_equal(a[:494],b[:494]);assert np.array_equal(a[:,846:],b[:,846:])
  old_cloth_roi=(570,545 if pose<3 else 515,830,810 if pose<3 else 780)
  x1,y1,x2,y2=old_cloth_roi;old_cloth=np.zeros(a.shape[:2],bool)
  cloth_source=a[y1:y2,x1:x2];dark=(cloth_source.max(2)>12)&(cloth_source.max(2)<155)&((cloth_source.max(2).astype(int)-cloth_source.min(2))<8)
  old_cloth[y1:y2,x1:x2]=dark
  assert np.array(mask)[old_cloth].min()==255
  rows.append({'pose':pose,'originalSha256':digest(src),'generatedSha256':digest(gen),'dimensions':[1024,1536],'generatedWindow':list(WINDOW[pose]),'seamOpacityPixels':12,'allCoordinatesUnchanged':True,'geometryTransforms':0,'outsideHipAndExistingColourFieldsExact':True,'apparatusOutsideX530AndRightX846Exact':True,'headUpperTorsoAndHandsAboveY494Exact':True,'shoesAndContactsBelowY1170Exact':True,'changedPixels':int(changed.sum()),'hipMaskPixels':int((np.array(mask)>0).sum()),'colourSupportPixels':int((np.array(support)>0).sum()),'originalClothFullyOpaqueGeneratedCoveragePixels':int(old_cloth.sum()),'originalMuscleFieldGeometryPreserved':True,'sourcePngSha256':digest(candidate/'source'/f'{pose}.png')})
 encoded={};frame_rows=[]
 for i,pose in enumerate(ORDER,1):
  if pose not in args.poses:continue
  im=rgb(candidate/'source'/f'{pose}.png')
  if not args.verify:
   (candidate/'source'/f'{i}.png').write_bytes((candidate/'source'/f'{pose}.png').read_bytes())
   (candidate/'frames'/f'{i}.png').write_bytes((candidate/'source'/f'{pose}.png').read_bytes())
   if pose not in encoded:
    stream=BytesIO();im.save(stream,format='WEBP',lossless=True,quality=100,method=6,exact=True);encoded[pose]=stream.getvalue()
   (candidate/'frames'/f'{i}.webp').write_bytes(encoded[pose])
  assert rgb(candidate/'source'/f'{i}.png').tobytes()==im.tobytes()
  assert rgb(candidate/'frames'/f'{i}.png').tobytes()==im.tobytes()
  assert rgb(candidate/'frames'/f'{i}.webp').tobytes()==im.tobytes()
  frame_rows.append({'frame':i,'sourcePose':pose,'pngSha256':digest(candidate/'source'/f'{i}.png'),'webpSha256':digest(candidate/'frames'/f'{i}.webp'),'decodedRGBExact':True})
 proof={'scope':'draft-pixel-integrity-not-release-acceptance','exerciseIds':['calf-raise','standing-calf-raise'],'physicalPoses':3,'sourcePoseOrder':ORDER,'poses':rows,'frames':frame_rows,'strictCertified':False,'colourMethod':'Existing chromatic source fields only; source maximum and tint strength drive palette remap with editable semantic role traces, no new anatomy or spatial gradient.','sourceTintStrengthDenominators':{'primary':.62,'secondary':.42},'palette':{'primary':'#7B72E9','secondary':'#9590E0'}}
 if not args.verify:write_json(root/'candidate-proof.json',proof)
 else:assert json.loads((root/'candidate-proof.json').read_bytes())==proof
 print(json.dumps({'poses':args.poses,'proof':str(root/'candidate-proof.json')},indent=2))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--poses',nargs='+',type=int,default=[1,2,3]);p.add_argument('--output-dir',type=Path,default=HERE);p.add_argument('--verify',action='store_true');run(p.parse_args())
