"""Display-only native comparisons and six-frame contacts. No asset edits."""
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np
R=Path(__file__).parent;C=R/'candidate';O=C/'review';O.mkdir(exist_ok=True)
def opened(p):return Image.open(p).convert('RGB')
for pose in [1,2,3]:
 src=opened(R/'inputs'/f'{pose}-original.png');im=opened(C/'source'/f'{pose}.png')
 box=(540,480,855,940);out=Image.new('RGB',(945,492),'#17171B');dr=ImageDraw.Draw(out)
 out.paste(src.crop(box),(0,30));out.paste(im.crop(box),(315,30))
 mask=Image.open(C/'layers'/f'{pose}-hip-mask.png').convert('RGB')
 out.paste(mask.crop(box),(630,30))
 for x,t in [(0,'Original'),(315,'Same-coordinate final'),(630,'Generated-pixel mask')]:dr.text((x+10,8),t,fill='white')
 out.save(O/f'{pose}-native-hip-boundary.png')
 box=(625,830,850,1170);out=Image.new('RGB',(900,372),'#17171B');dr=ImageDraw.Draw(out)
 role=Image.open(C/'layers'/f'{pose}-primary-role.png').convert('RGB');support=Image.open(C/'layers'/f'{pose}-colour-support.png').convert('RGB')
 for x,t,s in [(0,'Original tint',src),(225,'Approved palette',im),(450,'Primary role',role),(675,'Existing colour support',support)]:
  out.paste(s.crop(box),(x,30));dr.text((x+8,8),t,fill='white')
 out.save(O/f'{pose}-native-calf-palette.png')
out=Image.new('RGB',(1536,1602),'#17171B');d=ImageDraw.Draw(out)
for i,pose in enumerate([1,2,3,3,2,1]):
 x=(i%3)*512;y=(i//3)*801
 im=opened(C/'source'/f'{pose}.png').resize((512,768),Image.Resampling.LANCZOS)
 out.paste(im,(x,y+28));d.text((x+12,y+8),f'{i+1} / source pose{pose}',fill='white')
out.save(O/'six-frame-sequence.png')
out=Image.new('RGB',(1200,930),'#17171B');d=ImageDraw.Draw(out)
for i,pose in enumerate([1,2,3]):
 im=opened(C/'source'/f'{pose}.png');im=im.resize((600,900),Image.Resampling.LANCZOS)
 # This is a displaycropofunscaled source hip, not anassettransform.
 box=(560,490,845,920)
 hip=opened(C/'source'/f'{pose}.png').crop(box)
 out.paste(hip,(i*400+57,30));d.text((i*400+70,8),f'Pose{pose} native hip',fill='white')
 shoes=opened(C/'source'/f'{pose}.png').crop((570,1120,860,1335))
 out.paste(shoes,(i*400+55,500));d.text((i*400+70,474),f'Pose{pose} original shoes and support',fill='white')
out.save(O/'native-hips-feet.png')
print(O)
