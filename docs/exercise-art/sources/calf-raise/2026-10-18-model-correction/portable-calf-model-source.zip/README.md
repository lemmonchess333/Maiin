# Standing calf raise model correction

This shared source serves `calf-raise` and `standing-calf-raise`, both already
the same machine variation with identical frame/cue sequences. Their independent
catalogue instructions and advice are preserved by registration.

The original three native poses have charcoal shorts. Three successful built-in
imagegen local edits supplied neutral white-grey mannequin hips/upper thighs in
the approved FA56 contour style, without clothing. Only the documented local
window of each generated image is composited at its original coordinates.
The twelve-pixel source-over seam changes opacity, never geometry. The original
head, upper torso, hands, shoulder pads, trainers, ankle motion, forefoot support,
apparatus and weight-stack movement remain unchanged outside the mask.

Existing purple calf/soleus fields receive the approved palette bases
`#7B72E9` and `#9590E0`, using the original tint strength, luminance and
muscle contours. Editable role traces identify gastrocnemius versus soleus;
they never add anatomy. Neutral RGB outside the hip and old coloured fields is
exactly preserved. Original dark garment pixels are fully covered by the
opaque generated interior, with the seam on surrounding neutral context.

## Reproduce

Requires Python, Pillow and NumPy. All inputs are adjacent; no repository,
old work directory, API key or generation service is needed.

```text
python rebuild-calf-model.py --output-dir .
python rebuild-calf-model.py --output-dir . --verify
python render-review.py
```

The first command reconstructs three editable OpenRaster files (original,
generated hip, existing-field palette), all native layers, six RGB PNGs and
six lossless WebPs in the existing order `[1,2,3,3,2,1]`. Native dimensions stay
1024x1536 and the reference/card frame remains3. ORA layer recomposition and
lossless WebP decode must match every PNG exactly. `--verify` reads outputs
without writing them. Repeated states are byte-identical.

`candidate-proof.json` covers source hashes, insertion windows, opacity masks,
palette supports, unchanged regions, garment coverage and delivered frame
hashes. `SOURCE-FILES.sha256.json` binds the archive inputs and outputs.
The separate portable verification report binds the archive SHA and fresh
isolated reproduction results. Display-only contact sheets never author art.

This is an owner-review candidate, not strict anatomy or mechanics
certification. Inherited modest below-step heel stretch and small original
contour/contact differences remain disclosed; the task corrects the model and
colour standard without inventing new heel/ankle poses.
