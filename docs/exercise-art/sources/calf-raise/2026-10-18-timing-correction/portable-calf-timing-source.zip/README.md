# Standing calf raise timing correction

Both `calf-raise` and `standing-calf-raise` deliberately share the same artwork.
Only their middle/return physical pose (delivery paths2 and5) changes. Starting
and top poses, exact reference3, both normal cards, cues, duration and catalogue
setup remain unchanged. This corrects an existing guide and adds no conversion.

One successful built-in image edit used the current middle pose as target,
the accepted starting pose as exercise master, the top pose as movement
reference and FA56 as the canonical athlete. The exact saved prompt is
`middle-pose-prompt.txt`; the immutable result is `generated/middle-edit.png`.
No further image generation, failed generation or anatomical transforms.

`build-middle.py` retains generated moving-body/pad/lever/selected-stack pixels
at their original coordinates, restores the fixed apparatus outside documented
moving/revealed-background support, and maps existing calf chroma to the approved
primary#7B72E9/secondary#9590E0 palette while retaining source shading. It changes
neither image geometry nor endpoints. White trainers, grey apparatus and the
approved white/grey smooth anatomical mannequin without shorts are retained.

Reproduce offline with Pillow and NumPy:

```text
python build-middle.py --output reproduced
```

The three-layer OpenRaster file recomposes exactly. An isolated rebuild from
only the archived native inputs/generated image/script reproduced all22 outputs
byte-for-byte. All six lossless WebPs decode exactly to their corresponding
native source PNGs. The unchanged outer frames match the previous public files.

Native full-scene, head/hip, calf/heel, apparatus/stack and mobile staged reviews
passed. The source uses three honest discrete physical poses1/2/3/3/2/1. Head,
shoulder/lever, calf, heel and plate movement all begin in the middle beat;
`audit/co-movement-landmarks.json` records supporting native indicators. This
addresses the old heel-only early rise. Minor inherited contour/contact
variations remain, and no continuous trajectory or exact biomechanics is
certified. All11 strict release flags remain null. Actual registered mobile
playback and normal project/CI/merge checks are recorded separately.
