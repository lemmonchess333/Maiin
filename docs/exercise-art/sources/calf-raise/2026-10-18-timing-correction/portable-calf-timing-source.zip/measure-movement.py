"""Native diagnostic movement readout; not strict biomechanics certification."""
from pathlib import Path
from PIL import Image
import numpy as np, json
root=Path(__file__).resolve().parent
rows=[]
for label,path in [('start',root/'inputs/1.png'),('middle',root/'candidate/source/middle.png'),('top',root/'inputs/3.png')]:
 a=np.array(Image.open(path).convert('RGB'))
 head=int(np.where(a[:130,600:744].max(2)>160)[0].min())
 pad=int(np.where(a[135:230,584:595].max(2)>60)[0].min()+135)
 selected=int(np.where((a[730:880,300:475].max(2)>22).sum(1)>=125)[0].min()+730)
 mask=a[1130:1315,650:745].min(2)>175;seen=np.zeros(mask.shape,bool);groups=[]
 for y,x in zip(*np.where(mask)):
  if seen[y,x]:continue
  stack=[(int(y),int(x))];seen[y,x]=True;ys=[]
  while stack:
   yy,xx=stack.pop();ys.append(yy)
   for dy,dx in [(0,1),(0,-1),(1,0),(-1,0)]:
    ny,nx=yy+dy,xx+dx
    if 0<=ny<mask.shape[0] and 0<=nx<mask.shape[1] and mask[ny,nx] and not seen[ny,nx]:seen[ny,nx]=True;stack.append((ny,nx))
  groups.append((len(ys),int(max(ys)+1130)))
 heel=max(groups)[1]
 b=a[840:1172,618:855].astype(float);m=(b[:,:,2]-b[:,:,0]>4)&(b[:,:,2]-b[:,:,1]>6)
 centroid=round(float(np.where(m)[0].mean()+840),2)
 rows.append({'pose':label,'headTopY':head,'shoulderLeverEdgeY':pad,'selectedPlateTopY':selected,'leftRearHeelWhiteComponentY':heel,'calfChromaCentroidY':centroid})
monotonic={key:rows[0][key]>rows[1][key]>rows[2][key] for key in rows[0] if key!='pose'}
report={'scope':'Diagnostic native pixel indicators; supplements direct visual review, not strict biomechanics certification.','method':{'head':'First bright row in fixed head ROI','shoulder':'First apparatus edge row in fixed shoulder/lever ROI','selectedPlate':'First row with broad plate coverage, excluding guide collars','heel':'Lowest row of largest bright connected ankle/shoe component, excluding platform','calf':'Existing chromatic-field vertical centroid'},'rows':rows,'bothRiseTransitionsMoveUp':monotonic,'allIndicatorsMoveUpTogether':all(monotonic.values()),'sourcePoseOrder':[1,2,3,3,2,1],'discardedDiagnosticAttempts':['An initial simple heel threshold included the fixed platform, and a collar threshold did not measure plate faces; those ROIs were unsuitable as movement metrics.','The first connected-component readout failed JSON serialization of a NumPy integer; its initial saved script had an indentation error. No source assets changed in these diagnostic attempts.']}
(root/'audit/co-movement-landmarks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
assert report['allIndicatorsMoveUpTogether']
