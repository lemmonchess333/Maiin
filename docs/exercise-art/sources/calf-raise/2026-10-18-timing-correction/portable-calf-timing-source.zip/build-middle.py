"""Reproduce the native middle-pose edit; no image geometry transforms.

Generated pixels retain their exact1024x1536 coordinates. Fixed scene regions
are restored from the previously merged middle frame. Only existing calf
chroma is mapped to the approved palette, preserving source light/shade.
"""
from pathlib import Path
from io import BytesIO
import argparse, hashlib, json, zipfile
from xml.etree.ElementTree import Element, SubElement, tostring
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

HERE=Path(__file__).resolve().parent
SIZE=(1024,1536)
BODY=[(610,5),(748,5),(761,157),(847,180),(868,320),(846,505),(840,657),(858,890),(858,1130),(876,1250),(863,1323),(766,1324),(743,1307),(650,1330),(572,1305),(572,1238),(622,1172),(614,1060),(598,965),(575,860),(560,720),(559,590),(572,508),(562,418),(533,398),(470,405),(425,405),(372,391),(340,353),(309,236),(284,205),(290,154),(331,143),(379,139),(412,153),(435,218),(460,262),(528,255),(563,254),(573,170),(566,130),(579,40)]
LEVER=[(118,301),(299,163),(418,145),(591,132),(699,132),(714,163),(848,157),(874,180),(875,278),(807,292),(682,279),(668,314),(448,314),(413,282),(324,318),(120,359)]
PRIMARY=[[(667,882),(690,905),(712,941),(726,979),(729,1011),(719,1039),(701,1048),(682,1042),(666,1029),(651,1004),(646,972),(649,939),(657,910)],[(774,876),(797,902),(819,939),(834,978),(838,1010),(825,1040),(805,1048),(786,1033),(771,1008),(764,974),(762,935),(766,906)]]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def json_out(p,data):p.write_text(json.dumps(data,indent=2)+'\n')
def png(im):
 b=BytesIO();im.save(b,format='PNG');return b.getvalue()
def polygon_mask(polys):
 m=Image.new('L',(4096,6144));d=ImageDraw.Draw(m)
 for poly in polys:d.polygon([(x*4,y*4) for x,y in poly],fill=255)
 return m.resize(SIZE,Image.Resampling.LANCZOS)

def build(out):
 out.mkdir(parents=True,exist_ok=True)
 for name in ['source','frames','layers','review','editables']:(out/name).mkdir(exist_ok=True)
 base=Image.open(HERE/'inputs/2.png').convert('RGBA')
 generated=Image.open(HERE/'generated/middle-edit.png').convert('RGBA')
 assert base.size==generated.size==SIZE
 moving=polygon_mask([BODY,LEVER]);d=ImageDraw.Draw(moving)
 # This chamber contains only selected plates, guide rods and revealed gaps.
 d.rectangle((286,734,487,1004),fill=255)
 moving=moving.filter(ImageFilter.GaussianBlur(1.4))
 # Restore the stationary front frame and post, clear of the moving body.
 d=ImageDraw.Draw(moving)
 d.polygon([(235,406),(551,429),(551,1210),(487,1220),(485,472),(235,450)],fill=0)
 layer=generated.copy();layer.putalpha(moving)
 composed=Image.alpha_composite(base,layer)
 a=np.array(composed);rgb=a[:,:,:3].astype(float)
 r,g,b=rgb[:,:,0],rgb[:,:,1],rgb[:,:,2]
 region=np.zeros((1536,1024),bool);region[837:1172,618:855]=True
 support=region&(b-r>=2)&(b-g>=3)&(r-g>=-2)
 role=polygon_mask(PRIMARY);weight=np.array(role)/255.
 primary=np.array([123,114,233],float);secondary=np.array([149,144,224],float)
 hue=primary*weight[:,:,None]+secondary*(1-weight[:,:,None])
 hue=hue/hue.max(2)[:,:,None]
 maximum=rgb.max(2)
 amount=np.divide(maximum-g,maximum*(1-hue[:,:,1]),out=np.zeros_like(maximum),where=maximum>0)
 amount=np.clip(amount,0,1)
 mapped=maximum[:,:,None]*(1+amount[:,:,None]*(hue-1))
 edited=a.copy();edited[support,:3]=np.rint(mapped[support]).clip(0,255).astype(np.uint8)
 colour=np.zeros_like(a);colour[support]=edited[support];colour[support,3]=255
 colour_layer=Image.fromarray(colour)
 final=Image.alpha_composite(composed,colour_layer)
 assert final.tobytes()==Image.fromarray(edited).tobytes()
 mask=np.array(moving)>0
 original=np.array(base)
 changed=np.any(np.array(final)!=original,2)
 assert not np.any(changed&~mask&~support)
 layers=[('prior-middle',base),('generated-moving-scene',layer),('existing-chroma-palette',colour_layer)]
 for name,im in [('moving-mask',moving),('generated-moving-scene',layer),('colour-support',Image.fromarray((support*255).astype(np.uint8))),('primary-role',role),('existing-chroma-palette',colour_layer)]:im.save(out/'layers'/f'{name}.png')
 final.convert('RGB').save(out/'source/middle.png')
 doc=Element('image',w='1024',h='1536',name='Synchronized standing calf raise middle pose')
 stack=SubElement(doc,'stack')
 for name,_ in reversed(layers):SubElement(stack,'layer',name=name,src=f'data/{name}.png',opacity='1.0',visibility='visible',**{'composite-op':'svg:src-over'})
 with zipfile.ZipFile(out/'editables/middle.ora','w') as z:
  items=[('mimetype',b'image/openraster',zipfile.ZIP_STORED),('stack.xml',tostring(doc),zipfile.ZIP_DEFLATED)]
  items += [(f'data/{name}.png',png(im),zipfile.ZIP_DEFLATED) for name,im in layers]
  items += [('mergedimage.png',png(final),zipfile.ZIP_DEFLATED)]
  for name,data,kind in items:
   info=zipfile.ZipInfo(name,(2026,10,18,0,0,0));info.compress_type=kind;z.writestr(info,data)
 with zipfile.ZipFile(out/'editables/middle.ora') as z:
  reopened=Image.new('RGBA',SIZE)
  for name,_ in layers:reopened=Image.alpha_composite(reopened,Image.open(BytesIO(z.read(f'data/{name}.png'))).convert('RGBA'))
  assert reopened.tobytes()==final.tobytes()
 order=[1,2,3,3,2,1];rows=[];middle_encoded=None
 for n,pose in enumerate(order,1):
  image=final.convert('RGB') if pose==2 else Image.open(HERE/f'inputs/{pose}.png').convert('RGB')
  if pose==2:
   image.save(out/'source'/f'{n}.png')
   if middle_encoded is None:
    encoded=BytesIO();image.save(encoded,format='WEBP',lossless=True,quality=100,method=6,exact=True);middle_encoded=encoded.getvalue()
   (out/'frames'/f'{n}.webp').write_bytes(middle_encoded)
  else:
   (out/'source'/f'{n}.png').write_bytes((HERE/f'inputs/{pose}.png').read_bytes())
   (out/'frames'/f'{n}.webp').write_bytes((HERE/f'inputs/{pose}.webp').read_bytes())
  assert Image.open(out/'frames'/f'{n}.webp').convert('RGB').tobytes()==image.tobytes()
  rows.append({'frame':n,'pose':pose,'pngSha256':sha(out/'source'/f'{n}.png'),'webpSha256':sha(out/'frames'/f'{n}.webp')})
 # Review sheets only: these downscales never feed delivery assets.
 font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',22)
 panel=Image.new('RGB',(1536,820),(20,20,24));draw=ImageDraw.Draw(panel)
 for column,(label,image) in enumerate([('Start: unchanged',Image.open(HERE/'inputs/1.png')),('Middle: synchronized',final),('Top: unchanged',Image.open(HERE/'inputs/3.png'))]):
  draw.text((column*512+12,8),label,font=font,fill='white');copy=image.convert('RGB');copy.thumbnail((500,750));panel.paste(copy,(column*512+(512-copy.width)//2,50))
 panel.save(out/'review/three-pose-native-overview.png')
 zoom=Image.new('RGB',(1536,908),(20,20,24));d=ImageDraw.Draw(zoom)
 crops=[(540,0,880,725),(570,845,880,1325)]
 for row,box in enumerate(crops):
  for col,(label,image) in enumerate([('Start',Image.open(HERE/'inputs/1.png')),('Middle',final),('Top',Image.open(HERE/'inputs/3.png'))]):
   cut=image.convert('RGB').crop(box);cut.thumbnail((500,420));zoom.paste(cut,(col*512+(512-cut.width)//2,row*454+30));d.text((col*512+8,row*454+5),label,font=font,fill='white')
 zoom.save(out/'review/body-and-heels.png')
 proof={'scope':'native source/composite integrity, not strict certification','sourcePoseOrder':order,'dimensions':list(SIZE),'newGenerationCalls':1,'generationFailures':0,'anatomicalTransforms':[],'generatedCoordinatesUnchanged':True,'editTargetSha256':sha(HERE/'inputs/2.png'),'generatedSha256':sha(HERE/'generated/middle-edit.png'),'outsideMovingAndColourSupportPixelsExact':True,'changedPixels':int(changed.sum()),'movingSupportPixels':int(mask.sum()),'paletteSupportPixels':int(support.sum()),'palette':{'primary':'#7B72E9','secondary':'#9590E0','method':'Existing calf chroma hue only, preserving source maximum channel and green/blue shade difference; no spatial shading field.'},'oraRecompositionExact':True,'frames':rows,'strictCertified':False}
 json_out(out/'pixel-integrity.json',proof)
 print(json.dumps({'output':str(out),'changedPixels':proof['changedPixels'],'nativeRecompositionExact':True}))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'candidate');build(p.parse_args().output)
