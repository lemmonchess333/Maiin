from pathlib import Path
from io import BytesIO
import hashlib,json,zipfile,xml.etree.ElementTree as ET,shutil
from PIL import Image
P=Path(__file__).resolve().parent;W=P.parents[1];S=W/'smith-bench-press/contact-first-production';O=P/'originals';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();facts=[]
for n,label in [(1,'top'),(2,'early'),(3,'bottom')]:
    src=S/f'{n}-editable.ora';kept=[];skipped=[]
    with zipfile.ZipFile(src) as z:
        root=ET.fromstring(z.read('stack.xml'));size=(int(root.attrib['w']),int(root.attrib['h']));im=Image.new('RGBA',size)
        for layer in reversed(list(root.find('stack'))):
            name=layer.attrib['name']
            if name in ['Fixed Smith frame and guide rods','Moving guide carriages']:skipped.append(name);continue
            native=Image.open(BytesIO(z.read(layer.attrib['src']))).convert('RGBA');im=Image.alpha_composite(im,native);kept.append(name)
        im.save(O/f'{label}-native-canonical-body-bar.png')
        facts.append({'pose':label,'donorOra':str(src),'donorOraSha256':sha(src),'dimensions':size,'nativeLayersRetained':kept,'equipmentLayersRemoved':skipped,'sourceScale':1,'anatomicalTransforms':0,'scope':'Approved canonical athlete, bench and bar extracted as intact native layers. This is source reuse for a new free-barbell scene; no free-barbell release or full-cycle approval is implied.'})
    shutil.copyfile(src,O/f'{label}-donor.ora')
shutil.copyfile(W/'Maiin-burpees/docs/exercise-art/identity/athlete-anatomy-v3.png',O/'canonical-review-reference.png')
(P/'source-extraction.json').write_text(json.dumps({'sources':facts,'canonicalSha256':sha(O/'canonical-review-reference.png'),'strictCertified':False,'completionCredit':False},indent=2)+'\n',encoding='utf8')
print(json.dumps({'extractedNativeCanonicalPoses':3,'sourceScale':1,'equipmentOnlyLayerRemoval':True}))
