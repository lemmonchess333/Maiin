from pathlib import Path
from io import BytesIO
import hashlib,json,zipfile,xml.etree.ElementTree as ET
from PIL import Image,ImageDraw,ImageFilter
import numpy as np

P=Path(__file__).resolve().parent
O=P/'originals';F=P/'final-frames';E=P/'editables';R=P/'review'
for d in [F,E,R]:d.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
size=(1536,1024);crop=(264,0,1152,1024)
def png(im):
    b=BytesIO();im.save(b,format='PNG');return b.getvalue()
def ora(path,layers):
    root=ET.Element('image',w=str(size[0]),h=str(size[1]),name=path.stem);stack=ET.SubElement(root,'stack')
    composite=Image.new('RGBA',size)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('mimetype','image/openraster')
        for i,(name,im) in enumerate(layers):
            src=f'data/layer{i}.png';z.writestr(src,png(im));ET.SubElement(stack,'layer',name=name,src=src,x='0',y='0',opacity='1.0',visibility='visible',**{'composite-op':'svg:src-over'})
        for name,im in reversed(layers):composite=Image.alpha_composite(composite,im)
        z.writestr('stack.xml',ET.tostring(root));z.writestr('mergedimage.png',png(composite));z.writestr('Thumbnails/thumbnail.png',png(composite.copy().resize((384,256))))
    with zipfile.ZipFile(path) as z:
        q=ET.fromstring(z.read('stack.xml'));reopened=Image.new('RGBA',size)
        for layer in reversed(list(q.find('stack'))):reopened=Image.alpha_composite(reopened,Image.open(BytesIO(z.read(layer.attrib['src']))).convert('RGBA'))
    assert reopened.tobytes()==composite.tobytes()
    return composite

master=Image.open(O/'top-native-canonical-body-bar.png').convert('RGBA')
native={k:Image.open(O/f'{k}-native-canonical-body-bar.png').convert('RGBA') for k in ['top','early','bottom']}
raw=Image.open(O/'lower-middle-generated-native.png').convert('RGBA');a=np.array(raw);rgb=a[:,:,:3].astype(int)
# Palette-only native edit, confined to the source's already violet regions.
tint=np.clip((rgb[:,:,2]-np.minimum(rgb[:,:,0],rgb[:,:,1])-3)/16,0,1)*(rgb.max(2)>60)
yy,xx=np.mgrid[:1024,:1536]
chest=(xx>540)&(xx<748)&(yy>345)&(yy<443)
palette=np.zeros_like(a);palette[:,:,:3]=np.where(chest[:,:,None],np.array([123,114,233]),np.array([149,144,224]));palette[:,:,3]=np.uint8(tint*255)
pal=Image.fromarray(palette,'RGBA')
# Keep the WHOLE intact generated pose. The tested horizontal native composite
# produced an obvious thigh/bench join and is rejected, never shipped.
# No anatomical region is fitted, transformed, grafted or blended to hide that join.
gray=rgb.max(2).astype(float);med=np.asarray(Image.fromarray(gray.astype('uint8')).filter(ImageFilter.MedianFilter(5))).astype(float)
detail=np.clip((med-gray-4)/22,0,1)*tint
contours=Image.new('RGBA',size,(119,119,119,0));contours.putalpha(Image.fromarray(np.uint8(detail*255),'L'))
layers=[('Inherited neutral anatomical contour detail',contours),('Exact primary and secondary palette in existing source tint',pal),('Intact whole connected native lower-middle source',raw)]
native['lower-middle']=ora(E/'lower-middle-native.ora',layers)
facts=[]
for key in ['top','early','bottom']:
    ora(E/f'{key}-native.ora',[(f'Intact approved donor body bench and free bar without Smith apparatus ({key})',native[key])])
order=['top','early','lower-middle','bottom','lower-middle','top']
phases=[1,.88,.35,0,.35,1]
labels=['Set','Lower','Continue down','Chest touch','Drive','Lockout']
cues=['Shoulder blades set; feet stay planted.','Bend elbows; keep wrists over elbows.','Lower smoothly toward the mid-chest.','Touch lightly; keep the neck clear.','Press upward and back toward shoulders.','Straight arms; hips remain on bench.']
for i,key in enumerate(order,1):
    im=native[key].crop(crop).convert('RGB');im.save(F/f'{i}.png');im.save(F/f'{i}.webp',format='WEBP',lossless=True,method=6)
    decoded=Image.open(F/f'{i}.webp').convert('RGB');assert decoded.tobytes()==im.tobytes()
    facts.append({'frame':i,'sourcePose':key,'t':phases[i-1],'label':labels[i-1],'cue':cues[i-1],'pngSha256':sha(F/f'{i}.png'),'webpSha256':sha(F/f'{i}.webp')})
native['lower-middle'].crop((420,530,1050,680)).save(R/'native-lower-scene-continuous.png')
sheet=Image.new('RGB',(888*3,1024*2),(0,0,0))
for i in range(6):sheet.paste(Image.open(F/f'{i+1}.png'),((i%3)*888,(i//3)*1024))
sheet.resize((1332,1024)).save(R/'six-diagnostic.png')
report={'exerciseId':'bench-press','status':'native candidate; full-size loop and mobile review pending','canonicalSha256':sha(O/'canonical-review-reference.png'),'sourceDimensions':size,'commonCrop':crop,'outputDimensions':[888,1024],'sourceScale':1,'anatomicalWarps':0,'limbFitting':0,'headOrShoeGrafts':0,'distinctPhysicalPoses':4,'sourcePoseOrder':order,'frames':facts,'palette':{'primary':'#7B72E9','primaryMuscles':['Pectorals'],'secondary':'#9590E0','secondaryMuscles':['Triceps','Anterior deltoids']},'findings':['Low-middle is an intact whole generated source, with small supported head/chest/bench and planted trainer contour/position differences. Actual playback must establish whether these are nondistracting under the revised standard. No exact fixed-contact claim is made.','A horizontal y600 native composite was rejected because it created a visible thigh/bench seam. It is preserved only in the diagnostic native-lower-scene-join.png, not in any final frame.','Early is about12% descent, low-middle about65% descent; t is extension fraction, not frame number.','Generated drive source was not selected: it moved the whole supported body farther than the low-middle candidate.','No Smith frame/carriages remain. Free bar grips and path need actual loop review; donor approval is not inherited.'],'strictCertified':False,'completionCredit':False,'reproduction':'Run reproduce.py beside originals/. ORA layers reopen exactly; lossless WebP decoded RGB matches each PNG.'}
(P/'candidate.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps({'outputDimensions':[888,1024],'frames':6,'distinctPoses':4,'sourceScale':1,'strictCertified':False}))
