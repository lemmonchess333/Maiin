from pathlib import Path
from io import BytesIO
import hashlib,json,zipfile,xml.etree.ElementTree as ET
from PIL import Image,ImageDraw,ImageFilter
import numpy as np
from tone_palette import chroma_alpha,path_mask,source_tone_layer,inherited_neutral_detail

P=Path(__file__).resolve().parent
O=P/'originals';F=P/'final-frames';E=P/'editables';R=P/'review'
for d in [F,E,R]:d.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
size=(1536,1024);crop=(264,0,1152,1024)
def png(im):
    b=BytesIO();im.save(b,format='PNG');return b.getvalue()
def ora(path,layers):
    root=ET.Element('image',w=str(size[0]),h=str(size[1]),name=path.stem);stack=ET.SubElement(root,'stack')
    composite=Image.new('RGBA',size)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('mimetype','image/openraster')
        for i,(name,im) in enumerate(layers):
            src=f'data/layer{i}.png';z.writestr(src,png(im));ET.SubElement(stack,'layer',name=name,src=src,x='0',y='0',opacity='1.0',visibility='visible',**{'composite-op':'svg:src-over'})
        for name,im in reversed(layers):composite=Image.alpha_composite(composite,im)
        z.writestr('stack.xml',ET.tostring(root));z.writestr('mergedimage.png',png(composite));z.writestr('Thumbnails/thumbnail.png',png(composite.copy().resize((384,256))))
    with zipfile.ZipFile(path) as z:
        q=ET.fromstring(z.read('stack.xml'));reopened=Image.new('RGBA',size)
        for layer in reversed(list(q.find('stack'))):reopened=Image.alpha_composite(reopened,Image.open(BytesIO(z.read(layer.attrib['src']))).convert('RGBA'))
    assert reopened.tobytes()==composite.tobytes()
    return composite

palette_review=R/'palette-authoring';palette_review.mkdir(exist_ok=True)
native={};palette_facts={}
for key in ['top','early','bottom']:
    with zipfile.ZipFile(O/f'{key}-donor.ora') as z:
        stack=list(ET.fromstring(z.read('stack.xml')).find('stack'))
        donor=[Image.open(BytesIO(z.read(layer.attrib['src']))).convert('RGBA') for layer in stack[:5]]
    toned=[]
    for i,color,title in [(1,(149,144,224),'Secondary'),(2,(123,114,233),'Primary')]:
        coverage=np.asarray(donor[i])[:,:,3].astype(float)/255
        layer,fact=source_tone_layer(donor[4],coverage,color)
        # Exact approved source alpha, including its reviewed contour boundaries.
        layer.putalpha(donor[i].getchannel('A'));donor[i]=layer;toned.append(dict(region=title,**fact))
    layers=[('EXACT approved inherited neutral anatomical detail; unchanged bytes',donor[0]),('Secondary canonical base with retained original source tone',donor[1]),('Primary pectorals canonical base with retained original source tone',donor[2]),('EXACT approved neutralisation layer',donor[3]),('EXACT intact original athlete bench and free bar; no Smith apparatus',donor[4]),('Opaque black background, same compositing as prior reviewed donor export',Image.new('RGBA',size,(0,0,0,255)))]
    native[key]=ora(E/f'{key}-native.ora',layers);palette_facts[key]={'regions':toned,'approvedNeutralDetailLayerExact':True,'approvedNeutralisationAndSourceLayersExact':True}
raw=Image.open(O/'lower-middle-generated-native.png').convert('RGBA')
# Per-source visible pectoral boundaries, not the earlier rectangular colour split.
# These native-coordinate masks repair small white selection nicks/highlights only;
# they do not change any human silhouette, bar, hand, bench or pose pixel geometry.
near_path=[('M',(557,390)),('C',(572,375,598,364,617,366)),('C',(637,368,651,381,660,399)),('C',(666,414,642,419,618,427)),('C',(594,437,570,433,557,419)),('C',(548,408,550,399,557,390))]
far_path=[('M',(617,365)),('C',(639,354,662,355,682,361)),('C',(700,365,715,378,722,392)),('C',(729,403,724,410,714,412)),('C',(697,414,677,413,662,410)),('C',(659,393,639,371,617,365))]
primary=np.maximum(path_mask(size,near_path),path_mask(size,far_path))
chroma=chroma_alpha(raw);secondary=chroma*(1-primary)
prim,pf=source_tone_layer(raw,primary,(123,114,233));sec,sf=source_tone_layer(raw,secondary,(149,144,224))
contours=inherited_neutral_detail(raw,np.maximum(primary,secondary))
layers=[('Inherited native neutral anatomical contour detail; no redrawn lines',contours),('Primary pectorals native curved selection with source tone and repaired highlight nicks',prim),('Secondary source deltoid and posterior upper-arm fields with original source tone',sec),('Intact whole connected native lower-middle source; no geometry changes',raw)]
native['lower-middle']=ora(E/'lower-middle-native.ora',layers)
for name,mask in [('lower-middle-primary',primary),('lower-middle-secondary',secondary)]:Image.fromarray(np.uint8(mask*255),'L').save(palette_review/f'{name}-mask.png')
palette_facts['lower-middle']={'regions':[pf,sf],'nearPectoralPath':near_path,'farPectoralPath':far_path,'highlightRepair':'Smooth native pectoral selection includes small source highlight nicks; preserved as tonal variation rather than jagged white cutouts.','sourceGeometryEdits':0}
(P/'palette-source-tone-proof.json').write_text(json.dumps(palette_facts,indent=2),encoding='utf8')
facts=[]
order=['top','early','lower-middle','bottom','lower-middle','top']
phases=[1,.88,.35,0,.35,1]
labels=['Set','Lower','Continue down','Chest touch','Drive','Lockout']
cues=['Shoulder blades set; feet stay planted.','Bend elbows; keep wrists over elbows.','Lower smoothly toward the mid-chest.','Touch lightly; keep the neck clear.','Press upward and back toward shoulders.','Straight arms; hips remain on bench.']
for i,key in enumerate(order,1):
    im=native[key].crop(crop).convert('RGB');im.save(F/f'{i}.png');im.save(F/f'{i}.webp',format='WEBP',lossless=True,method=6)
    decoded=Image.open(F/f'{i}.webp').convert('RGB');assert decoded.tobytes()==im.tobytes()
    facts.append({'frame':i,'sourcePose':key,'t':phases[i-1],'label':labels[i-1],'cue':cues[i-1],'pngSha256':sha(F/f'{i}.png'),'webpSha256':sha(F/f'{i}.webp')})
native['lower-middle'].crop((420,530,1050,680)).save(R/'native-lower-scene-continuous.png')
sheet=Image.new('RGB',(888*3,1024*2),(0,0,0))
for i in range(6):sheet.paste(Image.open(F/f'{i+1}.png'),((i%3)*888,(i//3)*1024))
sheet.resize((1332,1024)).save(R/'six-diagnostic.png')
report={'exerciseId':'bench-press','status':'native candidate; full-size loop and mobile review pending','canonicalSha256':sha(O/'canonical-review-reference.png'),'sourceDimensions':size,'commonCrop':crop,'outputDimensions':[888,1024],'sourceScale':1,'anatomicalWarps':0,'limbFitting':0,'headOrShoeGrafts':0,'distinctPhysicalPoses':4,'sourcePoseOrder':order,'frames':facts,'palette':{'primary':'#7B72E9','primaryMuscles':['Pectorals'],'secondary':'#9590E0','secondaryMuscles':['Triceps','Anterior deltoids']},'findings':['Low-middle is an intact whole generated source, with small supported head/chest/bench and planted trainer contour/position differences. Actual playback must establish whether these are nondistracting under the revised standard. No exact fixed-contact claim is made.','A horizontal y600 native composite was rejected because it created a visible thigh/bench seam. It is preserved only in the diagnostic native-lower-scene-join.png, not in any final frame.','Early is about12% descent, low-middle about65% descent; t is extension fraction, not frame number.','Generated drive source was not selected: it moved the whole supported body farther than the low-middle candidate.','No Smith frame/carriages remain. Free bar grips and path need actual loop review; donor approval is not inherited.'],'strictCertified':False,'completionCredit':False,'paletteFinish':'Canonical base colours with original source luminance/shading. Three approved donor neutral-contour layers remain byte-exact; lower-middle pectoral ownership uses native curved masks and local highlight repair.','reproduction':'Run reproduce.py with tone_palette.py beside originals/. ORA layers reopen exactly; lossless WebP decoded RGB matches each PNG.'}
(P/'candidate.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps({'outputDimensions':[888,1024],'frames':6,'distinctPoses':4,'sourceScale':1,'strictCertified':False}))
