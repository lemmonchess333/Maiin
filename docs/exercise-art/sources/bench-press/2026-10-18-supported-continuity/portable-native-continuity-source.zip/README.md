# Bench press continuity correction

This package removes the independently generated lower-middle whole-scene image from frames 3 and 5. Its head was 19 pixels higher than the three supported source states in a fixed native head diagnostic region, and its bench and planted-trainer illustration also differed.

The corrected six-frame order is **top, early, bottom, bottom, early, top**. These are intact, previously approved native source composites. No image was generated, warped, mirrored, fitted, recoloured, or cut into anatomical parts. All three original editable ORAs and all their layers remain byte-exact. The original common crop `(264, 0, 1152, 1024)` remains at 1:1 scale, producing 888 × 1024 guides.

Public guide frames 1, 2, 4 and 6 remain byte-exact. New frame 3 is exactly old frame 4; new frame 5 is exactly old frame 2. The card/reference stays frame 4, so its source is unchanged. Existing labels and cues remain in their original six positions. Player timing remains 1,200 ms per frame, or 2,400 ms in slower mode. Phase metadata is corrected to `[1, 0.88, 0, 0, 0.88, 1]` to describe the selected physical states truthfully. Frames 3 and 4 intentionally dwell at chest touch.

Run `python reproduce.py` beside `inputs/` with Pillow and NumPy installed. The script verifies all input hashes, reopens every ORA layer, checks native composite equality, exports six PNG/WebP pairs, and verifies each export is byte-exact to its mapped prior public guide. It also makes diagnostic contact sheets and the movement/preservation proof. `input-manifest.json` binds the inputs; the old release and source-extraction record remain available under `inputs/reference/`.

The palette, neutral contours, supported torso, bench, bar, trainers and no-shorts athlete are unchanged from the three native sources. Minor inherited contour differences remain; this is not a claim of pixel-exact scene invariance or strict anatomical certification. The head-top diagnostic has a 0-pixel span across the corrected six frames, compared with 19 pixels before. The fixed region deliberately excludes hands and bar; it is a diagnostic and does not register or transform any image.

Native source/contact review passed. Actual registered normal/slower, mobile light/dark and controls review, project checks, publication and merge are separate integration gates owned by the parent task. This package does not claim they are complete.
