"""Restore the supported three-state bench cycle from unchanged native ORAs.

No model calls, resampling, anatomical edits, or pixel transplantation.
Dependencies: Pillow and NumPy. Run beside inputs/ to create candidate/.
"""
from pathlib import Path
from io import BytesIO
import hashlib, json, zipfile, xml.etree.ElementTree as ET
from PIL import Image, ImageDraw
import numpy as np

P = Path(__file__).resolve().parent
I = P/'inputs'
C = P/'candidate'
for name in ['frames', 'source', 'review']:
    (C/name).mkdir(parents=True, exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = json.loads((I/'input-manifest.json').read_text(encoding='utf-8'))
for rel, item in manifest.items():
    assert sha(I/rel) == item['sha256'], rel
assert sha(I/'reference/athlete-anatomy-v3.png') == 'fa56dd686d1e8ff88db91b9465255eefd9837f26174acebd18ddb2851d45a72b'
order = ['top','early','bottom','bottom','early','top']
phase = [1,.88,0,0,.88,1]
crop = (264,0,1152,1024)
native = {}
ora_facts = []
for key in ['top','early','bottom']:
    path = I/f'editables/{key}-native.ora'
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        root = ET.fromstring(z.read('stack.xml'))
        size = (int(root.attrib['w']),int(root.attrib['h']))
        assert size == (1536,1024)
        image = Image.new('RGBA',size)
        layers = []
        for layer in reversed(list(root.find('stack'))):
            assert layer.attrib['x'] == layer.attrib['y'] == '0'
            assert layer.attrib['opacity'] == '1.0'
            data = z.read(layer.attrib['src'])
            part = Image.open(BytesIO(data)).convert('RGBA')
            assert part.size == size
            image = Image.alpha_composite(image,part)
            layers.append({'name':layer.attrib['name'],'sha256':hashlib.sha256(data).hexdigest()})
        merged = Image.open(BytesIO(z.read('mergedimage.png'))).convert('RGBA')
        assert merged.tobytes() == image.tobytes()
    native[key] = image.crop(crop).convert('RGB')
    ora_facts.append({'pose':key,'path':str(path.relative_to(P)).replace('\\','/'),
                      'sha256':sha(path),'layers':layers,'allLayersUnchanged':True,
                      'reopenedCompositeMatchesMergedImage':True})

previous = json.loads((I/'reference/previous-native-candidate.json').read_text(encoding='utf-8'))
facts = []
for n,key in enumerate(order,1):
    image = native[key]
    png = C/f'source/{n}.png'
    webp = C/f'frames/{n}.webp'
    image.save(png)
    image.save(webp,format='WEBP',lossless=True,method=6)
    assert Image.open(webp).convert('RGB').tobytes() == image.tobytes()
    old_n = {'top':1,'early':2,'bottom':4}[key]
    assert webp.read_bytes() == (I/f'original-public/{old_n}.webp').read_bytes()
    facts.append({'frame':n,'sourcePose':key,'t':phase[n-1],
                  'label':previous['frames'][n-1]['label'],'cue':previous['frames'][n-1]['cue'],
                  'webp':str(webp.relative_to(P)).replace('\\','/'),'webpSha256':sha(webp),
                  'sourcePNG':str(png.relative_to(P)).replace('\\','/'),'pngSha256':sha(png),
                  'exactCopyOfPriorGuideFrame':old_n})

# Source-coordinate diagnostics only. They do not alter any delivered pixel.
def head_top(image):
    a = np.asarray(image)
    x0,y0,x1,y1 = (290,250,332,362)
    part = a[y0:y1,x0:x1]
    white = (part.min(2)>140)&((part.max(2).astype(int)-part.min(2))<25)
    ys,xs = np.where(white)
    assert len(ys)>1000
    return {'region':[x0,y0,x1,y1],'topY':int(ys.min()+y0)}
head_positions = {str(n):head_top(Image.open(I/f'original-public/{n}.webp').convert('RGB')) for n in [1,2,3,4]}
new_heads = {str(n):head_top(Image.open(C/f'frames/{n}.webp').convert('RGB')) for n in range(1,7)}
before_span = max(x['topY'] for x in head_positions.values())-min(x['topY'] for x in head_positions.values())
after_span = max(x['topY'] for x in new_heads.values())-min(x['topY'] for x in new_heads.values())
assert after_span < before_span
changed = [n for n in range(1,7) if sha(C/f'frames/{n}.webp') != sha(I/f'original-public/{n}.webp')]
assert changed == [3,5]

sheet = Image.new('RGB',(888*3,1060*2),(13,13,16))
draw = ImageDraw.Draw(sheet)
for n in range(1,7):
    x,y=((n-1)%3)*888,((n-1)//3)*1060
    draw.text((x+12,y+10),f"{n}: {order[n-1]}, t={phase[n-1]}",fill='white')
    sheet.paste(Image.open(C/f'source/{n}.png'),(x,y+36))
sheet.save(C/'review/six-native.png')
sheet.resize((1332,1060),Image.Resampling.LANCZOS).save(C/'review/six-contact.png')
pair = Image.new('RGB',(888*2,1060),(13,13,16))
draw = ImageDraw.Draw(pair)
draw.text((12,10),'Before: displaced whole-scene lower-middle, frame 3/5',fill='white')
draw.text((900,10),'After: intact supported bottom pose, frame 3',fill='white')
pair.paste(Image.open(I/'original-public/3.webp'),(0,36))
pair.paste(native['bottom'],(888,36))
pair.save(C/'review/continuity-before-after.png')

report = {
    'exerciseId':'bench-press','status':'native candidate; integrated player review pending',
    'canonicalSha256':sha(I/'reference/athlete-anatomy-v3.png'),
    'method':'Remove the independently generated whole-scene lower-middle state; reuse intact unchanged native top/early/bottom composites, never graft or transform anatomy.',
    'sourcePoseOrder':order,'distinctPhysicalPoses':3,'frames':facts,'nativeSources':ora_facts,
    'outputDimensions':[888,1024],'nativeSourceDimensions':[1536,1024],'commonCrop':list(crop),
    'sourceScale':1,'resampledPixels':0,'anatomicalWarps':0,'limbFitting':0,'headOrShoeGrafts':0,
    'imageGenerationCalls':0,'newAthletePixels':0,'nativeLayerEdits':0,
    'changedPublicGuideFrames':changed,'unchangedPublicGuideFrames':[1,2,4,6],
    'normalCardReferenceFrame':4,'normalCardSourceUnchanged':True,
    'labelsAndCuesUnchanged':True,'playerDurationUnchanged':True,
    'phaseMetadataChanges':{'3':{'before':.35,'after':0},'5':{'before':.35,'after':.88}},
    'headSupportDiagnostic':{'rule':'White neutral head top within fixed native region [290,250,332,362], avoiding the hands and shaft; diagnostic only, not anatomical registration.',
                             'before':head_positions,'after':new_heads,
                             'beforeTopSpanPx':before_span,'afterTopSpanPx':after_span},
    'palette':{'primary':'#7B72E9','secondary':'#9590E0','whiteTrainers':True,'shorts':False,
               'finish':'Unchanged approved native source layers, including inherited neutral contours and original source tone.'},
    'strictCertified':False,'completionCredit':False,
    'findings':['Three genuine physical poses reused across six guide paths. Frames 3 and 4 intentionally share the supported chest-touch pose; frame 5 returns through the existing early state.',
                'Native supported sources retain minor pre-existing illustration contour differences; no pixel-exact invariant-scene certification is asserted.',
                'Early state remains about 12% descent. No new anatomical interpolation or intermediate source is invented.']
}
(P/'preservation-and-movement-proof.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
(P/'integration-item.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'exercise':'bench-press','changedGuideFrames':changed,'headTopSpanBeforePx':before_span,'headTopSpanAfterPx':after_span,'threeNativeSourcesUnchanged':True}))
