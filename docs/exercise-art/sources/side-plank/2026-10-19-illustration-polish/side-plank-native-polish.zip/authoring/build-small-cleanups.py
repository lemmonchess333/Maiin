from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib,ast
H=Path(__file__).resolve().parent;R=H.parent/'Maiin-burpees';O=H/'candidate';O.mkdir(exist_ok=True)
# Reuse only the pure component function from our diagnostic, without its scans.
tree=ast.parse((H/'colour-components.py').read_text(encoding='utf-8'));pure=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='components'],type_ignores=[]);exec(compile(pure,'native-components','exec'))
facts=[]
spin=Image.open(R/'public/form-frames/spin-bike/4.webp').convert('RGBA');a=np.array(spin);mask=np.zeros(a.shape[:2],bool);mask[427:434,175:184]=True;mask&=np.max(a[:,:,:3],axis=2)>0;edited=a.copy();edited[mask,:3]=0
out=O/'spin-bike';out.mkdir(exist_ok=True);Image.fromarray(edited).convert('RGB').save(out/'standing-clean.png');Image.fromarray((mask*255).astype(np.uint8)).save(out/'old-equipment-remnant-mask.png');assert np.array_equal(a[~mask],edited[~mask]);facts.append({'id':'spin-bike','removedPixels':int(mask.sum()),'rectangle':[175,427,184,434],'scope':'Detached horizontal old-equipment stub to the left of calf only. Upper vertical light calf contour is preserved, as are all pixels x184andgreater.','outsideMaskExact':True,'sourceAnatomicalTransforms':[]})
side=Image.open(H/'card-source/side-plank-original-keyed.png').convert('RGBA');a=np.array(side);groups=components(a[:,:,3]>8);remove=np.zeros(a.shape[:2],bool);removed=[]
for runs in groups:
 ys=np.array([y for y,_,_ in runs]);n=sum(x1-x0 for _,x0,x1 in runs);bright=max(int(a[y,x0:x1,:3].max())for y,x0,x1 in runs)
 if n<2000 and bright<100:
  for y,x0,x1 in runs:remove[y,x0:x1]=True
  removed.append({'pixels':n,'maxRGB':bright,'bbox':[min(x0 for _,x0,_ in runs),int(ys.min()),max(x1 for _,_,x1 in runs),int(ys.max()+1)]})
edited=a.copy();edited[remove,3]=0;out=O/'card-sources';out.mkdir(exist_ok=True);Image.fromarray(edited).save(out/'side-plank.png');Image.fromarray((remove*255).astype(np.uint8)).save(out/'side-plank-shadow-mask.png');assert np.array_equal(a[:,:,:3],edited[:,:,:3])and np.array_equal(a[~remove],edited[~remove]);facts.append({'id':'side-plank','scope':'Native cutout alpha only: detached small dark components; connected hand/foot contact shadows and every source RGB retained.','removedComponents':removed,'outsideMaskExact':True})
swim=Image.open(R/'docs/exercise-art/cutout-sources/swimming.png').convert('RGBA');a=np.array(swim);mask=np.zeros(a.shape[:2],bool);mask[341:347,133:139]=True;mask&=a[:,:,3]>0;edited=a.copy();edited[mask,3]=0;Image.fromarray(edited).save(out/'swimming-clean-old-palette.png');Image.fromarray((mask*255).astype(np.uint8)).save(out/'swimming-waterline-stub-mask.png');assert np.array_equal(a[:,:,:3],edited[:,:,:3])and np.array_equal(a[~mask],edited[~mask]);facts.append({'id':'swimming','scope':'Native prepared cutout alpha only: horizontal water-line stub projecting right of the toe contour. Original toe/body RGB and all other alpha retained.','rectangle':[133,341,139,347],'removedPixels':int(mask.sum()),'outsideMaskExact':True})
(O/'small-cleanup-proof.json').write_text(json.dumps(facts,indent=2)+'\n',encoding='utf-8');print(json.dumps(facts))
