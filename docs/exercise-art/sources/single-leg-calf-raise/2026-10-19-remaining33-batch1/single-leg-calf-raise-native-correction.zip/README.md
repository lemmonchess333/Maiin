# Native illustration correction source

Same original athlete/trainers/hand and calf timing. Reference fixed support pixels, native2px visible-step registration and grey tread-only texture repair remove support drift and displaced contact-shadow double edge.

Original WebPs/decoded sources and sparse replacement layers are preserved. Reproduction does not call an image service, fit limbs, change any tests or certify anatomy. Historical recipe snapshots record authoring but may use old workspace paths; reproduce.py is the portable entry point. Human approval authorizes release and normal merge, not a strict visual certificate.
