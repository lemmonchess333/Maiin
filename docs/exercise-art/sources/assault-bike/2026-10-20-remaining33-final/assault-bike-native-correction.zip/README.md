# Native exercise illustration correction

Original rider and opposite arm/leg phases retained. Native grey fan, base, foot rests and two fixed lever pivots replace mirrored drifting apparatus; connected lever channels meet the same pivots in both phases. No anatomy transforms.

The old delivered sources, canonical identity, raw authoring inputs and editable replacement layers are retained. For the new rear-view stair set, the compositing base is an explicitly blank native canvas; each full historical baseline remains separately available. reproduce.py is the portable entry point. Recipe snapshots retain historical workspace paths for authoring context. Reproduction composes the same frozen layers and exports bytes; it does not call an image service or certify anatomy. No anatomical warp, individual limb fitting, mirrored camera, or head/shoe graft is applied. Owner release remains distinct from strict visual certification.
