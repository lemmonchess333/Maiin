"""Recompose editable native source layers and export; no pose/anatomy synthesis."""
from pathlib import Path
from PIL import Image
import argparse,json,hashlib,zipfile,io,xml.etree.ElementTree as ET,shutil
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=a.root.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
cfg=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def png(im):
 b=io.BytesIO();im.save(b,format='PNG');return b.getvalue()
def ora(path,base,layer,final):
 doc=ET.Element('image',w=str(final.width),h=str(final.height));stack=ET.SubElement(doc,'stack')
 for name,src in [('Native polish pixels','data/polish.png'),('Exact original drawing','data/original.png')]:ET.SubElement(stack,'layer',name=name,src=src,opacity='1.0',visibility='visible',**{'composite-op':'svg:src-over'})
 assert Image.alpha_composite(base,layer).tobytes()==final.tobytes()
 with zipfile.ZipFile(path,'w')as z:
  for name,data in [('mimetype',b'image/openraster'),('stack.xml',ET.tostring(doc)),('data/polish.png',png(layer)),('data/original.png',png(base)),('mergedimage.png',png(final))]:
   info=zipfile.ZipInfo(name,(2026,10,19,0,0,0));info.compress_type=zipfile.ZIP_STORED if name=='mimetype'else zipfile.ZIP_DEFLATED;z.writestr(info,data)
for d in ['source','frames','editables']:(out/d).mkdir(exist_ok=True)
facts=[];seen={}
for row in cfg['frames']:
 n=row['frame'];base=Image.open(root/row['originalPng']).convert('RGBA');layer=Image.open(root/row['layer']).convert('RGBA');final=Image.alpha_composite(base,layer);assert hashlib.sha256(final.tobytes()).hexdigest()==row['finalRgbaSha256'];final.convert('RGB').save(out/f'source/{n}.png')
 dest=out/f'frames/{n}.webp'
 if row['changedPixels']==0:shutil.copyfile(root/row['originalWebp'],dest)
 else:final.convert('RGB').save(dest,lossless=True,quality=100,method=3,exact=True)
 assert Image.open(dest).convert('RGBA').tobytes()==final.tobytes()
 identity=hashlib.sha256(base.tobytes()+layer.tobytes()).hexdigest()
 if identity not in seen:ora(out/f'editables/{n}.ora',base,layer,final);seen[identity]=n
 facts.append({'frame':n,'pngSha256':sha(out/f'source/{n}.png'),'webpSha256':sha(dest),'changedPixels':row['changedPixels'],'originalOutsidePolishLayerExact':True,'editablePhysicalFrame':seen[identity]})
if cfg.get('card'):
 c=cfg['card'];base=Image.open(root/c['original']).convert('RGBA');patch=Image.open(root/c['patch']).convert('RGBA');mask=Image.open(root/c['mask']).convert('L');card=Image.composite(patch,base,mask);assert hashlib.sha256(card.tobytes()).hexdigest()==c['finalRgbaSha256'];card.save(out/'prepared-card.png')
(out/'reproduction.json').write_text(json.dumps({'scope':'Byte-exact native editable-layer composition and normal lossless delivery export. Not independent anatomy/physics re-authoring or strict certification.','id':cfg['id'],'frames':facts,'anatomicalTransforms':[]},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'id':cfg['id'],'frames':len(facts),'uniqueEditableStates':len(seen),'output':str(out)}))
