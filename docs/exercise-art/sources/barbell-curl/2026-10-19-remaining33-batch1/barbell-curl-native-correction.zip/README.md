# Native illustration correction source

Same original athlete and grips. Reuse native reference equipment at integer offsets; rigid modest plate/collar/sleeve geometry no longer shrinks through the curl.

Original WebPs/decoded sources and sparse replacement layers are preserved. Reproduction does not call an image service, fit limbs, change any tests or certify anatomy. Historical recipe snapshots record authoring but may use old workspace paths; reproduce.py is the portable entry point. Human approval authorizes release and normal merge, not a strict visual certificate.
