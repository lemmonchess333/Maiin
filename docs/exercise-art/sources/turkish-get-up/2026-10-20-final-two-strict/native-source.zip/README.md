Native source package for turkish-get-up.

Run `python reproduce.py --root . --output OUTPUT` with Pillow and NumPy. Original complete athlete sources, canonical identity reference, manifest, layered native ORA editables and measured material evidence are included. No anatomical deformation, individual limb fitting or isolated head/shoe grafts. Swimming uses whole-athlete integer translation; get-up replaces old equipment with one complete rigid master behind the original grip. All original retained athlete RGB pixels are asserted exact. Scene corner measurements do not replace visual body/contact review.

Primary coaching comparison: https://www.strongfirst.com/the-get-up-change-your-perspective-to-build-strength/ — sequential elbow, hand, bridge, half-kneel and standing support with a locked loaded arm and neutral wrist. Individual base width and joint angles vary. This guide depicts the ascent and instructs the controlled reverse; it does not interpolate the omitted descent.
