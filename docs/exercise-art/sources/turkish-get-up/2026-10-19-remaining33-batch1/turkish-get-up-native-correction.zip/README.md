# Native illustration correction source

Retain original frames1-4 pixel-exact at common y+100 padding. New full connected half-kneel and standing sources keep front foot on right and far loaded arm consistent, correcting wrong facing and flat-profile camera change. Entire source5/6 uniformly normalized, no individual anatomical transforms or head/shoe grafts.

Original WebPs/decoded sources and sparse replacement layers are preserved. Reproduction does not call an image service, fit limbs, change any tests or certify anatomy. Historical recipe snapshots record authoring but may use old workspace paths; reproduce.py is the portable entry point. Human approval authorizes release and normal merge, not a strict visual certificate.
