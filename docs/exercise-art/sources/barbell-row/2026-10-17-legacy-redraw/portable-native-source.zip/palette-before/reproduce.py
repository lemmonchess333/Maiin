from pathlib import Path
from io import BytesIO
import hashlib,json,zipfile,xml.etree.ElementTree as ET
from PIL import Image,ImageDraw,ImageFilter
import numpy as np
P=Path(__file__).resolve().parent;O=P/'originals';F=P/'final-frames';E=P/'editables';R=P/'review'
for d in [F,E,R]:d.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
size=(1536,1024);crop=(180,0,1320,1024)
names={'hang':'hang-master-native.png','early':'early-native.png','middle':'middle-native.png','top':'top-native.png'}
lat={
 'hang':[(748,247),(769,260),(811,285),(846,312),(810,322),(753,325),(750,301),(747,280)],
 'early':[(771,276),(795,289),(850,307),(797,323),(758,330),(754,315)],
 'middle':[(753,275),(792,284),(850,270),(846,340),(787,342),(736,338),(735,302)],
 'top':[(735,250),(782,255),(825,245),(832,280),(831,327),(794,332),(738,332),(730,289)]}
def png(im):
    b=BytesIO();im.save(b,format='PNG');return b.getvalue()
def ora(path,layers):
    root=ET.Element('image',w='1536',h='1024',name=path.stem);stack=ET.SubElement(root,'stack');out=Image.new('RGBA',size)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('mimetype','image/openraster')
        for i,(name,im) in enumerate(layers):
            src=f'data/layer{i}.png';z.writestr(src,png(im));ET.SubElement(stack,'layer',name=name,src=src,x='0',y='0',opacity='1.0',visibility='visible',**{'composite-op':'svg:src-over'})
        for name,im in reversed(layers):out=Image.alpha_composite(out,im)
        z.writestr('stack.xml',ET.tostring(root));z.writestr('mergedimage.png',png(out))
        thumb=out.copy();thumb.thumbnail((384,384));z.writestr('Thumbnails/thumbnail.png',png(thumb))
    reopened=Image.new('RGBA',size)
    with zipfile.ZipFile(path) as z:
        rt=ET.fromstring(z.read('stack.xml'))
        for layer in reversed(list(rt.find('stack'))):reopened=Image.alpha_composite(reopened,Image.open(BytesIO(z.read(layer.attrib['src']))).convert('RGBA'))
    assert reopened.tobytes()==out.tobytes()
    return out
native={};sources=[]
for key,filename in names.items():
    raw=Image.open(O/filename).convert('RGBA');assert raw.size==size
    a=np.array(raw);c=a[:,:,:3].astype(int)
    chroma=np.clip((c[:,:,2]-np.minimum(c[:,:,0],c[:,:,1])-3)/16,0,1)*(c.max(2)>60)
    pm=Image.new('L',(size[0]*4,size[1]*4));ImageDraw.Draw(pm).polygon([(x*4,y*4) for x,y in lat[key]],fill=255)
    ownership=np.asarray(pm.resize(size,Image.Resampling.LANCZOS)).astype(float)/255
    primary=chroma*ownership;secondary=chroma*(1-ownership)
    layers=[]
    for title,mask,color in [('Primary visible latissimus dorsi #7B72E9',primary,(123,114,233)),('Secondary visible rear deltoids rhomboids biceps #9590E0',secondary,(149,144,224))]:
        layer=Image.new('RGBA',size,color+(0,));layer.putalpha(Image.fromarray(np.uint8(mask*255),'L'));layers.append((title,layer))
    # Same inherited-grey-detail extraction used by the approved Smith bench.
    # This retains native contour/shading detail above the exact palette fills.
    gray=c.max(2).astype(float);med=np.asarray(Image.fromarray(gray.astype('uint8')).filter(ImageFilter.MedianFilter(5))).astype(float)
    detail=np.clip((med-gray-4)/22,0,1)*np.maximum(primary,secondary)
    contours=Image.new('RGBA',size,(119,119,119,0));contours.putalpha(Image.fromarray(np.uint8(detail*255),'L'));layers.insert(0,('Inherited neutral anatomical contour detail',contours))
    layers.append(('Intact whole native generated athlete and connected bar; no transforms',raw))
    native[key]=ora(E/f'{key}-native.ora',layers)
    native[key].save(R/f'{key}-native-full.png')
    sources.append({'pose':key,'path':f'originals/{filename}','sha256':sha(O/filename),'dimensions':size,'anatomicalTransforms':0,'sourceScale':1,'primaryMaskPolygon':lat[key]})
order=['hang','early','middle','top','middle','hang'];phases=[0,.25,.72,1,.72,0]
labels=['Hang','Initiate pull','Continue pull','Top contraction','Lower','Full stretch']
cues=['Hinge steady; arms hang below shoulders.','Bend elbows; keep both wrists straight.','Drive elbows back beside the torso.','Bring the bar to lower ribs.','Lower smoothly; maintain the hip hinge.','Arms extend; plates stay off floor.']
facts=[]
for i,key in enumerate(order,1):
    im=native[key].crop(crop).convert('RGB');im.save(F/f'{i}.png');im.save(F/f'{i}.webp',format='WEBP',lossless=True,method=6)
    assert Image.open(F/f'{i}.webp').convert('RGB').tobytes()==im.tobytes()
    facts.append({'frame':i,'sourcePose':key,'t':phases[i-1],'label':labels[i-1],'cue':cues[i-1],'pngSha256':sha(F/f'{i}.png'),'webpSha256':sha(F/f'{i}.webp')})
sheet=Image.new('RGB',(1140*3,1024*2),(0,0,0))
for i in range(6):sheet.paste(Image.open(F/f'{i+1}.png'),((i%3)*1140,(i//3)*1024))
sheet.resize((1710,1024)).save(R/'six-diagnostic.png')
report={'exerciseId':'barbell-row','status':'native candidate; native loop and actual mobile review pending','sourceDimensions':size,'outputDimensions':[1140,1024],'commonCrop':crop,'sourceScale':1,'anatomicalWarps':0,'limbFitting':0,'headOrShoeGrafts':0,'distinctPhysicalPoses':4,'sources':sources,'sourcePoseOrder':order,'frames':facts,'palette':{'primary':'#7B72E9','primaryMuscles':['Lats'],'secondary':'#9590E0','secondaryMuscles':['Rhomboids','Rear deltoids','Biceps']},'findings':['Four genuine native continuous-hinge row poses, not a relabelled Pendlay floor reset.','Late middle is about72% projected shaft travel; early about25%; phase values describe the actual images, not equal spacing.','Small generated shoulder/chest/back/grip contour and width variations retained for native motion review. Whole head and trainers visually steady, not a calibrated3D or exact pixel identity claim.','Colour masks follow already tinted source fields; visible lat mask is traced per pose, remaining visible rear deltoid/rhomboid/biceps secondary. Anatomical ownership needs native inspection.'],'strictCertified':False,'completionCredit':False}
(P/'candidate.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps({'frames':6,'distinctPoses':4,'outputDimensions':[1140,1024],'strictCertified':False}))
