Portable native source — barbell-row,17October2026

Unzip into its own directory. Run Python reproduce.py with Pillow and NumPy installed. tone_palette.py must remain beside it, and originals/ must retain its contents. The recipe builds the final six separate PNG/lossless WebP frames and native ORAs without network or further image generation. Source pixels, physical phases, equipment and all coordinates are the frozen root candidate; only the separately documented palette finish was applied. This ZIP packaging did not edit any source or pixel.

candidate.json binds physical order/cues/current output hashes. Palette native/fresh proof records independent exact recreation of all PNG/WebP bytes and every decompressed ORA member. fresh-reproduction/ contains the exact recipe/helper and terminal log from that measured fresh build; duplicate fresh output/source folders are omitted because their bytes are already present here and the hash proof binds them. ZIP container timestamps themselves are not reproducibility claims.

originals/ includes all inputs needed by the recipe plus retained unused source history where present. Prompts, donor extraction/provenance records and palette/source proofs are included at their original relative paths. Canonical FA56 reference is under originals/ or identity/. review/ contains native crops, masks, coordinate-overlay diagnostics and source-layers; these are QA derivatives, not substituted delivery masters. palette-before/ retains old recipe/candidate/hash provenance, not old duplicate output banks.

Strict visual certification/completion credit remain false. Actual timed playback, mobile light/dark, cards, integrated checks and release/merge are root-owned. This archive is source preparation, not deployment approval.
