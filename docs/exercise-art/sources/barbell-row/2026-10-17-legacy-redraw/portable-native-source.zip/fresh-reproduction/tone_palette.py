from PIL import Image,ImageDraw,ImageFilter
import numpy as np

def chroma_alpha(raw):
    c=np.asarray(raw.convert("RGB")).astype(float)
    return np.clip((c[:,:,2]-np.maximum(c[:,:,0],c[:,:,1])-8)/14,0,1)*(c.max(2)>60)

def path_mask(size,commands):
    # Geometry is a colour selection boundary only. Source anatomy never moves.
    pts=[];at=None
    for op,values in commands:
        if op=="M":at=np.array(values,float);pts.append(at)
        elif op=="L":at=np.array(values,float);pts.append(at)
        elif op=="C":
            p0=at.copy();p1=np.array(values[:2],float);p2=np.array(values[2:4],float);p3=np.array(values[4:6],float)
            for t in np.linspace(0,1,25)[1:]:pts.append((1-t)**3*p0+3*(1-t)**2*t*p1+3*(1-t)*t*t*p2+t**3*p3)
            at=p3
    mask=Image.new("L",(size[0]*4,size[1]*4));ImageDraw.Draw(mask).polygon([(int(round(x*4)),int(round(y*4)))for x,y in pts],fill=255)
    return np.asarray(mask.resize(size,Image.Resampling.LANCZOS)).astype(float)/255

def polygon_mask(size,polygons):
    mask=Image.new("L",(size[0]*4,size[1]*4));d=ImageDraw.Draw(mask)
    for poly in polygons:d.polygon([(int(round(x*4)),int(round(y*4)))for x,y in poly],fill=255)
    return np.asarray(mask.resize(size,Image.Resampling.LANCZOS)).astype(float)/255

def source_tone_layer(raw,mask,target,strength=.65):
    c=np.asarray(raw.convert("RGB")).astype(float);luma=c@np.array([.2126,.7152,.0722]);chroma=chroma_alpha(raw)
    core=(mask>.75)&(chroma>.75)
    if not np.any(core):core=mask>.5
    center=float(np.median(luma[core])) if np.any(core) else 0.
    delta=np.clip((luma-center)*strength,-38,26)
    rgb=np.clip(np.array(target,float)[None,None,:]+delta[:,:,None],0,255)
    a=np.zeros((raw.height,raw.width,4),np.uint8);a[:,:,:3]=np.rint(rgb).astype(np.uint8);a[:,:,3]=np.rint(np.clip(mask,0,1)*255).astype(np.uint8)
    return Image.fromarray(a,"RGBA"),{"baseRGB":list(target),"sourceLuminanceMedian":center,"toneStrength":strength,"sourceDarkAndLightVariationClip":[-38,26],"paintedPixels":int(np.count_nonzero(mask))}

def inherited_neutral_detail(raw,mask):
    # Existing fine source strokes only, no newly drawn anatomical contour.
    c=np.asarray(raw.convert("RGB")).astype(float);gray=c.max(2);median=np.asarray(Image.fromarray(gray.astype("uint8")).filter(ImageFilter.MedianFilter(5))).astype(float)
    detail=np.clip((median-gray-4)/22,0,1)*mask
    a=np.zeros((raw.height,raw.width,4),np.uint8);a[:,:,:3]=119;a[:,:,3]=np.rint(detail*255).astype(np.uint8)
    return Image.fromarray(a,"RGBA")
