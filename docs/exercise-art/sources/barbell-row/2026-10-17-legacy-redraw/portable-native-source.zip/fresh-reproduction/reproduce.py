from pathlib import Path
from io import BytesIO
import hashlib,json,zipfile,xml.etree.ElementTree as ET
from PIL import Image,ImageDraw,ImageFilter
import numpy as np
from tone_palette import chroma_alpha,polygon_mask,source_tone_layer,inherited_neutral_detail
P=Path(__file__).resolve().parent;O=P/'originals';F=P/'final-frames';E=P/'editables';R=P/'review'
for d in [F,E,R]:d.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
size=(1536,1024);crop=(180,0,1320,1024)
names={'hang':'hang-master-native.png','early':'early-native.png','middle':'middle-native.png','top':'top-native.png'}
lat={
 'hang':[[(729,246),(749,243),(770,239),(791,262),(812,285),(847,313),(811,319),(778,325),(748,325),(748,301),(738,275)]],
 'early':[[(770,228),(784,239),(805,262),(827,284),(851,306),(792,316),(782,290),(773,262)],[(686,294),(698,281),(712,304),(714,315),(702,320),(686,313)]],
 'middle':[[(707,236),(724,249),(748,261),(779,269),(813,273),(850,260),(827,280),(839,310),(840,319),(791,328),(752,337),(740,310),(725,281)]],
 'top':[[(711,231),(731,245),(754,252),(785,255),(807,254),(830,244),(831,270),(839,299),(832,320),(790,326),(747,329),(741,303),(728,269)]]}
def png(im):
    b=BytesIO();im.save(b,format='PNG');return b.getvalue()
def ora(path,layers):
    root=ET.Element('image',w='1536',h='1024',name=path.stem);stack=ET.SubElement(root,'stack');out=Image.new('RGBA',size)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('mimetype','image/openraster')
        for i,(name,im) in enumerate(layers):
            src=f'data/layer{i}.png';z.writestr(src,png(im));ET.SubElement(stack,'layer',name=name,src=src,x='0',y='0',opacity='1.0',visibility='visible',**{'composite-op':'svg:src-over'})
        for name,im in reversed(layers):out=Image.alpha_composite(out,im)
        z.writestr('stack.xml',ET.tostring(root));z.writestr('mergedimage.png',png(out))
        thumb=out.copy();thumb.thumbnail((384,384));z.writestr('Thumbnails/thumbnail.png',png(thumb))
    reopened=Image.new('RGBA',size)
    with zipfile.ZipFile(path) as z:
        rt=ET.fromstring(z.read('stack.xml'))
        for layer in reversed(list(rt.find('stack'))):reopened=Image.alpha_composite(reopened,Image.open(BytesIO(z.read(layer.attrib['src']))).convert('RGBA'))
    assert reopened.tobytes()==out.tobytes()
    return out
native={};sources=[];palette_facts={}
for key,filename in names.items():
    raw=Image.open(O/filename).convert('RGBA');assert raw.size==size
    chroma=chroma_alpha(raw)
    ownership=polygon_mask(size,lat[key])
    primary=chroma*ownership;secondary=chroma*(1-ownership)
    prim,pf=source_tone_layer(raw,primary,(123,114,233))
    sec,sf=source_tone_layer(raw,secondary,(149,144,224))
    contours=inherited_neutral_detail(raw,np.maximum(primary,secondary))
    layers=[('Inherited neutral source anatomical contours; no redrawn lines',contours),('Primary latissimus dorsi: canonical base with smooth source tone and divisions',prim),('Secondary rear deltoid rhomboid biceps: canonical base with smooth source tone',sec),('Intact whole native generated athlete and connected bar; no transforms',raw)]
    pd=R/'palette-authoring';pd.mkdir(exist_ok=True)
    for name,mask in [('primary',primary),('secondary',secondary)]:Image.fromarray(np.uint8(mask*255),'L').save(pd/f'{key}-{name}-mask.png')
    palette_facts[key]={'primary':pf,'secondary':sf,'latSelectionPolygons':lat[key],'sourceGeometryEdits':0,'sourceMask':'soft existing chroma ramp; neutral source contours remain unpainted'}
    native[key]=ora(E/f'{key}-native.ora',layers)
    native[key].save(R/f'{key}-native-full.png')
    sources.append({'pose':key,'path':f'originals/{filename}','sha256':sha(O/filename),'dimensions':size,'anatomicalTransforms':0,'sourceScale':1,'primaryMaskPolygon':lat[key]})
order=['hang','early','middle','top','middle','hang'];phases=[0,.25,.72,1,.72,0]
labels=['Hang','Initiate pull','Continue pull','Top contraction','Lower','Full stretch']
cues=['Hinge steady; arms hang below shoulders.','Bend elbows; keep both wrists straight.','Drive elbows back beside the torso.','Bring the bar to lower ribs.','Lower smoothly; maintain the hip hinge.','Arms extend; plates stay off floor.']
facts=[]
for i,key in enumerate(order,1):
    im=native[key].crop(crop).convert('RGB');im.save(F/f'{i}.png');im.save(F/f'{i}.webp',format='WEBP',lossless=True,method=6)
    assert Image.open(F/f'{i}.webp').convert('RGB').tobytes()==im.tobytes()
    facts.append({'frame':i,'sourcePose':key,'t':phases[i-1],'label':labels[i-1],'cue':cues[i-1],'pngSha256':sha(F/f'{i}.png'),'webpSha256':sha(F/f'{i}.webp')})
sheet=Image.new('RGB',(1140*3,1024*2),(0,0,0))
for i in range(6):sheet.paste(Image.open(F/f'{i+1}.png'),((i%3)*1140,(i//3)*1024))
sheet.resize((1710,1024)).save(R/'six-diagnostic.png')
report={'exerciseId':'barbell-row','status':'native candidate; native loop and actual mobile review pending','sourceDimensions':size,'outputDimensions':[1140,1024],'commonCrop':crop,'sourceScale':1,'anatomicalWarps':0,'limbFitting':0,'headOrShoeGrafts':0,'distinctPhysicalPoses':4,'sources':sources,'sourcePoseOrder':order,'frames':facts,'palette':{'primary':'#7B72E9','primaryMuscles':['Lats'],'secondary':'#9590E0','secondaryMuscles':['Rhomboids','Rear deltoids','Biceps']},'findings':['Four genuine native continuous-hinge row poses, not a relabelled Pendlay floor reset.','Late middle is about72% projected shaft travel; early about25%; phase values describe the actual images, not equal spacing.','Small generated shoulder/chest/back/grip contour and width variations retained for native motion review. Whole head and trainers visually steady, not a calibrated3D or exact pixel identity claim.','Colour masks follow already tinted source fields; visible lat mask is traced per pose, remaining visible rear deltoid/rhomboid/biceps secondary. Anatomical ownership needs native inspection.'],'strictCertified':False,'completionCredit':False}
(P/'palette-source-tone-proof.json').write_text(json.dumps(palette_facts,indent=2),encoding='utf8')
report['paletteFinish']='Only existing source chromatic fields; canonical base+source luminance variation, exact native anatomy/equipment retained. Per-pose lat ownership follows underarm borders; rear deltoids/rhomboids/biceps secondary.'
(P/'candidate.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps({'frames':6,'distinctPoses':4,'outputDimensions':[1140,1024],'strictCertified':False}))
