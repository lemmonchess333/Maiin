from pathlib import Path
from io import BytesIO
import hashlib,json,zipfile,xml.etree.ElementTree as ET,subprocess,sys,shutil,tempfile
import numpy as np
from PIL import Image
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def opened(path):
 with zipfile.ZipFile(path)as z:
  root=ET.fromstring(z.read('stack.xml'));ls=[];im=Image.new('RGBA',(int(root.get('w')),int(root.get('h'))))
  for node in root.find('stack'):
   assert node.get('x')=='0'and node.get('y')=='0'and node.get('opacity')=='1.0'
   ls.append(Image.open(BytesIO(z.read(node.get('src')))).convert('RGBA'))
  for layer in reversed(ls):im=Image.alpha_composite(im,layer)
  assert im.tobytes()==Image.open(BytesIO(z.read('mergedimage.png'))).convert('RGBA').tobytes()
  hashes={name:hashlib.sha256(z.read(name)).hexdigest()for name in z.namelist()}
 return ls,im,hashes
before=json.loads((P/'palette-before/candidate.json').read_text());now=json.loads((P/'candidate.json').read_text());baseline=json.loads((P/'palette-before/preservation-inputs.json').read_text())
for rel,h in baseline['originals'].items():assert sha(P/rel)==h,rel
for rel,h in baseline['rejectedDiagnostics'].items():assert sha(P/rel)==h,rel
for field in ['exerciseId','sourceDimensions','outputDimensions','commonCrop','sourceScale','anatomicalWarps','limbFitting','headOrShoeGrafts','distinctPhysicalPoses','sourcePoseOrder']:
 assert now[field]==before[field],field
for a,b in zip(before['frames'],now['frames']):
 for k in ['frame','sourcePose','t','label','cue']:assert a[k]==b[k],(k,a,b)
assert now['strictCertified']is False and now['completionCredit']is False
poses={};donor=[]
for key in set(now['sourcePoseOrder']):
 file=P/'editables'/f'{key}-native.ora';layers,im,members=opened(file);oldlayers,oldim,_=opened(P/'palette-before/editables'/f'{key}-native.ora')
 # Change support is ONLY editable colour/contour layers. No human/equipment mask,
 # whole-source position, bar/grip coordinates or source image changes are allowed.
 allowed=np.zeros((1024,1536),bool)
 if now['exerciseId']=='bench-press'and key in ['top','early','bottom']:
  for i in [1,2]:allowed|=np.asarray(layers[i])[:,:,3]>0
  with zipfile.ZipFile(P/'originals'/f'{key}-donor.ora')as z:
   original=list(ET.fromstring(z.read('stack.xml')).find('stack'))
   for i in [0,3,4]:assert layers[i].tobytes()==Image.open(BytesIO(z.read(original[i].get('src')))).convert('RGBA').tobytes()
   for i in [1,2]:assert layers[i].getchannel('A').tobytes()==Image.open(BytesIO(z.read(original[i].get('src')))).convert('RGBA').getchannel('A').tobytes()
  donor.append({'pose':key,'unchangedDecodedDonorLayers':[0,3,4],'approvedColourAlphaBoundariesExact':True})
 else:
  for layer in layers[:-1]+oldlayers[:-1]:allowed|=np.asarray(layer)[:,:,3]>0
  assert layers[-1].tobytes()==oldlayers[-1].tobytes()
 diff=np.any(np.array(im)!=np.array(oldim),axis=2);assert np.count_nonzero(diff&~allowed)==0,(key,'out-of-palette pixel change')
 poses[key]={'oraLayerCount':len(layers),'oraRecompositionExact':True,'changedPixels':int(np.count_nonzero(diff)),'changedPixelsOutsidePaletteSupport':0,'decompressedOraMemberHashes':members,'nativeSourcePath':next((x['path']for x in now.get('sources',[])if x['pose']==key),None)}
rows=[]
for frame in now['frames']:
 i=frame['frame'];_,im,_=opened(P/'editables'/f"{frame['sourcePose']}-native.ora");im=im.crop(tuple(now['commonCrop'])).convert('RGB');png=Image.open(P/'final-frames'/f'{i}.png').convert('RGB');webp=Image.open(P/'final-frames'/f'{i}.webp').convert('RGB')
 assert im.tobytes()==png.tobytes()==webp.tobytes();assert sha(P/'final-frames'/f'{i}.png')==frame['pngSha256'];assert sha(P/'final-frames'/f'{i}.webp')==frame['webpSha256']
 rows.append({'frame':i,'pngSha256':frame['pngSha256'],'webpSha256':frame['webpSha256'],'nativeOraCropExact':True,'losslessRgbExact':True})
assert(P/'final-frames/3.png').read_bytes()==(P/'final-frames/5.png').read_bytes();assert(P/'final-frames/1.png').read_bytes()==(P/'final-frames/6.png').read_bytes()
fresh=Path(tempfile.mkdtemp(prefix='palette-fresh-',dir=P));assert fresh.resolve().parent==P.resolve();shutil.copytree(P/'originals',fresh/'originals')
for name in ['reproduce.py','tone_palette.py']:shutil.copy2(P/name,fresh/name)
cp=subprocess.run([sys.executable,str(fresh/'reproduce.py')],capture_output=True,text=True);(fresh/'run.log').write_text(cp.stdout+'\n'+cp.stderr,encoding='utf-8');assert cp.returncode==0,cp.stderr
for row in rows:
 i=row['frame']
 for ext in ['png','webp']:assert(P/'final-frames'/f'{i}.{ext}').read_bytes()==(fresh/'final-frames'/f'{i}.{ext}').read_bytes()
 row['freshPngAndWebpBytesExact']=True
for key in poses:
 _,_,a=opened(P/'editables'/f'{key}-native.ora');_,_,b=opened(fresh/'editables'/f'{key}-native.ora');assert a==b
 poses[key]['freshAllDecompressedOraMembersExact']=True
result={'exerciseId':now['exerciseId'],'status':'palette-only native proof passed; app/mobile/release still parent-owned','sourceAndRejectedDiagnosticsHashesPreserved':baseline,'recipeSha256':sha(P/'reproduce.py'),'helperSha256':sha(P/'tone_palette.py'),'poses':poses,'approvedBenchDonorLayersPreserved':donor,'frames':rows,'allPhaseCueCropEquipmentAndGeometryInputsUnchanged':True,'freshDirectory':fresh.name,'strictCertified':False,'completionCredit':False,'nativeFinalSixStillsInspected':True,'actualTimedPlaybackOrMobileByThisAgent':False,'paletteMethod':'Canonical base RGB plus original source luminance/shading; chroma-soft mask and existing grey detail retained. Selection boundaries change colour only.'}
(P/'palette-native-reproduction-proof.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'exerciseId':now['exerciseId'],'paletteOnlyProof':'passed','sourceFilesPreserved':len(baseline['originals']),'freshSixPngAndWebpExact':True,'freshOraMembersExact':True,'changedPixelsOutsidePaletteSupport':0,'strictCertified':False},indent=2))
