# Rope tricep pushdown equipment correction

This draft corrects the merged machine's thin, poorly articulated weight stack.
The replacement uses wider solid shaded plates, a consistent oblique top and side
face, guide bores around the two continuous rods, a visible moving selector stem
through the lift gap, a seated fourth-plate selector pin, and a supported pulley
bracket. The selector stem is correctly hidden by the resting plate fronts.

Only two existing native equipment layers are replaced. All existing athlete,
muscle palette, trainers, short rope grips, long rope branches, cable and background
layers are retained as exact decoded pixels. Every pixel left of x704, covering
the entire athlete and rope contacts, is identical to the actual merged public
frame. The source canvas stays 1024×1600. There is no anatomical transformation,
resampling, fitting, mirroring, or new image generation.

The existing five source poses, six-frame order, contact points, 320px rope
branches, finite24px-radius pulley path, constant cable length, selected4/resting8
plate counts and 0–227.988px stack rise are retained. This is an illustrative2D
machine drawing, not a calibrated engineering model. All grays are neutral shaded
apparatus finishes; no new athlete colour field is introduced.

Run `python rebuild-equipment.py` with Pillow and NumPy available. It reads the
hash-pinned deduplicated PNG layers in `inputs/`, verifies the original composite
pixel hashes and renders six PNGs, lossless WebPs, seven-layer editable OpenRaster
files, before/after reviews and preservation/mechanics evidence in `candidate/`.
Use `--output PATH` to place a clean reproduction elsewhere. The old source work
directory and repository checkout are not needed to reproduce the images.

The small source ZIP contains code, pinned source layers and the expected output
hash proof. Native output frames/editables remain alongside it for integration.
No repository registration, Git edit or project tests were performed by this
equipment-authoring task; integration and publication belong to the parent task.
