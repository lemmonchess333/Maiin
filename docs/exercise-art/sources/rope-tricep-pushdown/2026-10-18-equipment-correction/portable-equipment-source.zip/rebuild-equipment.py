from pathlib import Path
import io, json, hashlib, math, zipfile, argparse
import xml.etree.ElementTree as ET
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1] / 'Maiin-burpees'
INPUT = ROOT / 'inputs'
args=argparse.ArgumentParser();args.add_argument('--output',type=Path,default=ROOT/'candidate');opt=args.parse_args()
OUT = opt.output
for d in ['frames','editables','layers','review']:
    (OUT/d).mkdir(parents=True,exist_ok=True)
W,H=1024,1600
S=3
def sha(b): return hashlib.sha256(b).hexdigest()

class Canvas:
    def __init__(self):
        self.im=Image.new('RGBA',(W*S,H*S)); self.d=ImageDraw.Draw(self.im)
    def pts(self,p): return [(round(x*S),round(y*S)) for x,y in p]
    def poly(self,p,fill): self.d.polygon(self.pts(p),fill=fill)
    def line(self,p,fill,width=1): self.d.line(self.pts(p),fill=fill,width=round(width*S),joint='curve')
    def rect(self,b,fill): self.d.rectangle(tuple(round(v*S) for v in b),fill=fill)
    def ellipse(self,b,fill,outline=None,width=1): self.d.ellipse(tuple(round(v*S) for v in b),fill=fill,outline=outline,width=round(width*S))
    def finish(self): return self.im.resize((W,H),Image.Resampling.LANCZOS)
    def gradient_poly(self,p,top,bottom):
        mask=Image.new('L',self.im.size);ImageDraw.Draw(mask).polygon(self.pts(p),fill=255)
        bounds=mask.getbbox();x0,y0,x1,y1=bounds
        t=np.linspace(0,1,y1-y0)[:,None,None]
        a=np.array(top)[None,None,:]*(1-t)+np.array(bottom)[None,None,:]*t
        a=np.repeat(np.rint(a).astype(np.uint8),x1-x0,axis=1)
        tile=Image.fromarray(a,'RGBA'); self.im.paste(tile,(x0,y0),mask.crop(bounds))
        self.d=ImageDraw.Draw(self.im)

def plate(c,y,selected=False):
    # Shared solid plate dimensions, oblique top/side depth. No free disks.
    left,right,dx,dy=761.,920.,11.,-5.
    top=[(left,y),(right,y),(right+dx,y+dy),(left+dx,y+dy)]
    front=[(left,y),(right,y),(right,y+16),(left,y+16)]
    side=[(right,y),(right+dx,y+dy),(right+dx,y+11),(right,y+16)]
    c.gradient_poly(front,(94,96,99,255),(67,69,72,255))
    c.gradient_poly(side,(64,66,69,255),(42,44,47,255))
    c.gradient_poly(top,(135,137,140,255),(103,105,108,255))
    c.line([(left+.5,y+.5),(right,y+.5)],(155,157,160,255),.8)
    c.line([(left,y+16),(right,y+16),(right+dx,y+11)],(28,30,33,255),1.5)
    # Actual bores sit around both continuous guide rods on each top face.
    for x in [790,900]:
        c.ellipse((x-5,y-4,x+5,y+.5),(33,35,38,255))
        c.rect((x-1.7,y-5,x+1.7,y-1.2),(151,154,158,255))
        c.line([(x-1.5,y-5),(x-1.5,y-1)],(204,206,209,255),.7)
    # Shallow neutral selector bore, no decorative numbered marking.
    c.ellipse((841,y+5,847,y+11),(35,37,40,255))

def fixed():
    c=Canvas()
    # Existing tower envelope: wider readable solid uprights and top bracket.
    for x in [728,931]:
        c.gradient_poly([(x,22),(x+24,22),(x+24,1458),(x,1458)],(71,73,76,255),(48,50,53,255))
        c.rect((x+3,25,x+7,1458),(98,100,104,255))
        c.line([(x+23,25),(x+23,1458)],(30,32,35,255),2)
    c.poly([(728,22),(955,22),(955,46),(728,46)],(66,68,71,255))
    c.line([(731,25),(952,25)],(111,113,116,255),2)
    # A visible fork bracket carries the real sheave axle, not a detached coin.
    c.poly([(751,45),(835,45),(835,81),(807,81),(807,62),(751,62)],(79,81,84,255))
    c.line([(752,48),(830,48),(830,75)],(123,125,128,255),1.5)
    # Bed and feet are anchored to both uprights, all coordinates fixed.
    c.poly([(704,1455),(958,1455),(991,1482),(737,1482)],(62,64,67,255))
    c.poly([(737,1482),(991,1482),(991,1494),(737,1494)],(38,40,43,255))
    c.line([(738,1483),(989,1483)],(86,88,91,255),1)
    c.rect((752,1343,931,1366),(62,64,67,255))
    c.poly([(752,1343),(931,1343),(941,1337),(762,1337)],(106,108,111,255))
    c.rect((769,1366,917,1392),(39,41,44,255))
    # Two continuous guide rods physically locate every selected/unselected plate.
    for x in [790,900]:
        c.rect((x-3,119,x+3,1342),(118,121,125,255))
        c.line([(x-1.5,120),(x-1.5,1341)],(196,199,202,255),1)
        c.ellipse((x-7,113,x+7,124),(80,83,87,255))
    for k in range(8): plate(c,1172+k*21)
    cx,cy=820,78
    c.ellipse((cx-29,cy-29,cx+29,cy+29),(40,42,45,255),(102,104,107,255),2)
    c.ellipse((cx-24,cy-24,cx+24,cy+24),(77,79,82,255),(137,139,142,255),1)
    c.ellipse((cx-7,cy-7,cx+7,cy+7),(152,154,157,255),(44,46,49,255),2)
    return c.finish()

def moving(top):
    c=Canvas()
    # The lift/selector stem moves with the chosen four plates. It enters the
    # unused stack through its top; the front resting plates occlude its tail.
    # This must not be painted across the solid fronts of the resting plates.
    bottom=min(top+312,1167)
    c.rect((839,top-13,849,bottom),(88,91,95,255))
    c.line([(841,top-12),(841,bottom)],(174,177,181,255),1)
    for y in np.arange(top+89,bottom-5,21):
        c.ellipse((842,y,846,y+4),(31,33,36,255))
    for k in range(4): plate(c,top+k*21,True)
    # Cable already terminates at x844/top-10 in the preserved rope layer.
    c.gradient_poly([(833,top-14),(855,top-14),(855,top-2),(833,top-2)],(143,146,150,255),(83,86,90,255))
    c.ellipse((837,top-17,851,top-9),(79,82,86,255),(172,175,179,255),1)
    # Selector pin is seated in the fourth moving plate, not floating outside.
    y=top+3*21+8
    c.line([(844,y),(830,y)],(187,190,193,255),3)
    c.ellipse((824,y-4,833,y+4),(76,79,83,255),(155,158,162,255),1)
    return c.finish()

def read_frozen_layers(row):
    layers=[]
    for item in row['layers']:
        data=(INPUT/item['path']).read_bytes();assert sha(data)==item['sha256']
        layers.append((item['name'],Image.open(io.BytesIO(data)).convert('RGBA')))
    return layers

def comp(layers):
    result=Image.new('RGBA',(W,H))
    for name,im in reversed(layers): result=Image.alpha_composite(result,im)
    return result.convert('RGB')

def ora(path,layers,merged):
    root=ET.Element('image',w=str(W),h=str(H),name=path.stem,version='0.0.3');stack=ET.SubElement(root,'stack')
    with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('mimetype','image/openraster',compress_type=zipfile.ZIP_STORED)
        for n,(name,im) in enumerate(layers):
            src=f'data/layer-{n}.png';b=io.BytesIO();im.save(b,format='PNG');z.writestr(src,b.getvalue())
            ET.SubElement(stack,'layer',name=name,src=src,x='0',y='0',opacity='1.0',visibility='visible',**{'composite-op':'svg:src-over'})
        z.writestr('stack.xml',ET.tostring(root,encoding='utf-8'));b=io.BytesIO();merged.save(b,format='PNG');z.writestr('mergedimage.png',b.getvalue())

proof=json.loads((INPUT/'original-sequence-and-mechanics.json').read_text())
source_rows=json.loads((INPUT/'original-layer-manifest.json').read_text())['frames']
fixed_layer=fixed()
rows=[]
for n in range(1,7):
    source_row=source_rows[n-1]
    old_layers=read_frozen_layers(source_row)
    old_comp=comp(old_layers)
    assert sha(np.array(old_comp).tobytes())==source_row['decodedRgbSha256']
    public=old_comp
    public_path=REPO/'public/form-frames/rope-tricep-pushdown'/f'{n}.webp'
    if public_path.is_file():
        assert sha(public_path.read_bytes())==source_row['publicWebpSha256']
        assert np.array_equal(np.array(old_comp),np.array(Image.open(public_path).convert('RGB')))
    top=proof['physicalOrder'][n-1]['stack']['top']
    new_layers=list(old_layers)
    new_layers[4]=('Solid four selected plates and continuous moving selector stem',moving(top))
    new_layers[5]=('Fixed supported high sheave, solid tower, continuous guide rods and eight resting plates',fixed_layer)
    final=comp(new_layers)
    # No equipment work can reach the native athlete/rope-grip region x<704.
    assert np.array_equal(np.array(final)[:,:704],np.array(public)[:,:704])
    changed=np.any(np.array(final)!=np.array(public),axis=2)
    assert not changed[:,:704].any()
    # The original rope, cable, skin, muscle-colour and fixed body layers remain
    # byte-identical decoded images, not regenerated copies or fitted fragments.
    assert all(np.array_equal(np.array(new_layers[k][1]),np.array(old_layers[k][1])) for k in [0,1,2,3,6])
    final.save(OUT/'frames'/f'{n}.png')
    final.save(OUT/'frames'/f'{n}.webp',lossless=True,quality=100,method=6)
    ora(OUT/'editables'/f'{n}.ora',new_layers,final)
    beforeafter=Image.new('RGB',(2048,1600));beforeafter.paste(public,(0,0));beforeafter.paste(final,(1024,0));beforeafter.save(OUT/'review'/f'{n}-before-after.png')
    crop=Image.new('RGB',(640,700));crop.paste(public.crop((704,760,1024,1460)),(0,0));crop.paste(final.crop((704,760,1024,1460)),(320,0));crop.save(OUT/'review'/f'{n}-stack-before-after.png')
    decoded=Image.open(OUT/'frames'/f'{n}.webp').convert('RGB')
    assert np.array_equal(np.array(decoded),np.array(final))
    assert top+312 >= 1172
    rows.append({'frame':n,'originalPublicSha256':source_row['publicWebpSha256'],'athleteAndRopeGripPixelRegionExact':[0,0,704,1600],'allChangedPixelsWithin':[704,0,1024,1600],'changedPixelCount':int(changed.sum()),'unchangedOriginalLayerIndices':[0,1,2,3,6],'stackTop':top,'liftStemNativeLength':312,'liftStemBottomBeforeFixedPlateOcclusion':top+312,'fixedStemOcclusionY':1167,'unselectedStackTop':1172,'selectedPlates':4,'restingPlates':8,'platePitch':21,'guideRodCenters':[790,900],'guideBoreCenters':[790,900],'cableAttachmentCenterX':844,'losslessWebpRgbExact':True,'newPngSha256':sha((OUT/'frames'/f'{n}.png').read_bytes()),'newWebpSha256':sha((OUT/'frames'/f'{n}.webp').read_bytes())})
(OUT/'preservation-and-mechanics.json').write_text(json.dumps({'scope':'equipment-only native layers; original body, palette, trainers, rope-grips, branches and cable layer unchanged','originalMechanics':proof,'newFrameProofs':rows,'equipmentChanges':['solid broader 3D plates and guide bores','continuous moving312px selector stem correctly occluded by solid resting plate fronts','pin seated on selected fourth plate','solid neutral tower with fixed sheave bracket'],'noAnatomicalTransforms':True},indent=2))
sheet=Image.new('RGB',(1536,840),(20,20,22));d=ImageDraw.Draw(sheet)
for i in range(6):
    im=Image.open(OUT/'frames'/f'{i+1}.png');im.thumbnail((256,800))
    sheet.paste(im,(256*i,30));d.text((256*i+8,8),f'{i+1} corrected equipment',fill='white')
sheet.save(OUT/'review/six-frame-sequence.png')
print(json.dumps({'output':str(OUT),'frames':[r['frame'] for r in rows]},indent=2))
