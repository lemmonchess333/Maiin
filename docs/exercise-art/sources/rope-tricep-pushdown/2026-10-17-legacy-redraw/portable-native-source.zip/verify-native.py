from pathlib import Path
import json,hashlib,zipfile,io,xml.etree.ElementTree as ET,shutil,subprocess,sys
from PIL import Image
import numpy as np
ROOT=Path(__file__).resolve().parent
C=ROOT/'candidate'
def sha(b):return hashlib.sha256(b).hexdigest()
def ora_pixels(p):
 with zipfile.ZipFile(p)as z:
  root=ET.fromstring(z.read('stack.xml'));nodes=root.findall('.//layer');assert len(nodes)==7
  im=Image.new('RGBA',(int(root.get('w')),int(root.get('h'))))
  for node in reversed(nodes):
   assert node.get('x')=='0'and node.get('y')=='0'and node.get('opacity')=='1.0'
   im=Image.alpha_composite(im,Image.open(io.BytesIO(z.read(node.get('src')))).convert('RGBA'))
  stored=Image.open(io.BytesIO(z.read('mergedimage.png'))).convert('RGBA');assert np.array_equal(np.array(stored),np.array(im))
  members={n:sha(z.read(n))for n in z.namelist()}
 return im,members
rows=[]
for i in range(1,7):
 png=Image.open(C/'frames'/f'{i}.png').convert('RGB');webp=Image.open(C/'frames'/f'{i}.webp').convert('RGB');ora,members=ora_pixels(C/'editables'/f'{i}.ora');assert png.size==(1024,1600);assert np.array_equal(np.array(png),np.array(webp));assert np.array_equal(np.array(png),np.array(ora.convert('RGB')))
 rows.append({'frame':i,'size':list(png.size),'webpLosslessExact':True,'sevenLayerOraRecompositionExact':True,'oraMemberHashes':members,'pngSha256':sha((C/'frames'/f'{i}.png').read_bytes()),'webpSha256':sha((C/'frames'/f'{i}.webp').read_bytes())})
assert (C/'frames/1.png').read_bytes()==(C/'frames/6.png').read_bytes()
mechanics=json.loads((C/'native-sequence-and-mechanics.json').read_text());assert all(abs(x['cable']['error'])<1e-9 for x in mechanics['physicalOrder']);assert len(set(x['pngSha256']for x in mechanics['physicalOrder']))==5
# Delivered head/feet equality is source-pixel equality outside the moving window,
# independently checked on final composites where apparatus does not occlude.
ref=np.array(Image.open(C/'frames/1.png').convert('RGB'));native_master=Image.new('RGB',(1024,1600));native_master.paste(Image.open(ROOT/'originals/01-master.png').convert('RGB'),(0,64));master_body=np.array(native_master).max(axis=2)>18;regions={'head-ear-neck-upper':(350,100,535,310),'near-trainer':(200,1320,410,1500),'far-trainer':(405,1280,630,1410)}
for i in range(2,7):
 a=np.array(Image.open(C/'frames'/f'{i}.png').convert('RGB'))
 for name,(x1,y1,x2,y2)in regions.items():
  human_mask=master_body[y1:y2,x1:x2];assert np.array_equal(ref[y1:y2,x1:x2][human_mask],a[y1:y2,x1:x2][human_mask]),(i,name)
result={'status':'native-reconstruction-passed; visual/release checks remain pending','frames':rows,'distinctNativeHumanSources':5,'headAndTrainerSourceBodyPixelsExactAcrossSix':regions,'fixedRegionMask':'Actual original master body pixels maxRGB>18 within each specified ROI; excludes unrelated rope on black near head.','sourceNativePlacement':[0,64],'anatomicalTransforms':[],'maxCableConservationError':max(abs(x['cable']['error'])for x in mechanics['physicalOrder']),'fullAppMobileOrPlaybackReviewedByThisAgent':False}
(ROOT/'native-integrity-proof.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
if '--fresh' in sys.argv:
 fresh=ROOT/'portable-fresh-check';fresh.mkdir(exist_ok=False);shutil.copytree(ROOT/'originals',fresh/'originals');shutil.copy2(ROOT/'reproduce.py',fresh/'reproduce.py')
 cp=subprocess.run([sys.executable,str(fresh/'reproduce.py')],capture_output=True,text=True);(fresh/'run.log').write_text(cp.stdout+'\n'+cp.stderr,encoding='utf-8');assert cp.returncode==0,cp.stderr
 equivalent=[]
 for i in range(1,7):
  for ext in ['png','webp']:assert(C/'frames'/f'{i}.{ext}').read_bytes()==(fresh/'candidate/frames'/f'{i}.{ext}').read_bytes()
  _,old=ora_pixels(C/'editables'/f'{i}.ora');_,new=ora_pixels(fresh/'candidate/editables'/f'{i}.ora');assert old==new
  equivalent.append({'frame':i,'pngBytesExact':True,'webpBytesExact':True,'allDecompressedOraMembersExact':True})
 (ROOT/'portable-reproduction-proof.json').write_text(json.dumps({'status':'passed','freshDirectory':'portable-fresh-check','recipeSha256':sha((ROOT/'reproduce.py').read_bytes()),'freshInputHashes':{str(p.relative_to(fresh)):sha(p.read_bytes())for p in (fresh/'originals').glob('*')if p.is_file()},'outputs':equivalent,'normalPythonDependencies':['Pillow','NumPy']},indent=2),encoding='utf-8')
print(json.dumps({'nativeIntegrity':'passed','physicalSources':5,'guideFiles':6,'sevenLayerOras':6,'fullAppMobileOrPlaybackReviewedByThisAgent':False,'portableFresh':'passed'if'--fresh'in sys.argv else'not requested'},indent=2))
