from pathlib import Path
from collections import deque
import json, math, hashlib, io, zipfile
import xml.etree.ElementTree as ET
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'candidate'; OUT.mkdir(exist_ok=True)
for name in ['frames','editables','layers','review']:(OUT/name).mkdir(exist_ok=True)
W,H=1024,1600
YPAD=64 # Whole-source integer translation, no human resampling.
SOURCES=['01-master','02-early','03-middle','04-late','05-lockout']
# Source-native equipment contact samples. G is the top-of-closed-fist rope interface;
# S is the preserved short rope stub's tip. These are illustrative projected samples.
CONTACTS=[
 {'G':[(500,486),(590,486)],'S':[(501,431),(591,432)]},
 {'G':[(492,588),(594,589)],'S':[(500,534),(594,535)]},
 {'G':[(487,644),(593,639)],'S':[(500,595),(595,586)]},
 {'G':[(447,684),(587,682)],'S':[(464,641),(592,632)]},
 {'G':[(367,731),(574,730)],'S':[(389,685),(582,677)]},
]
for c in CONTACTS:
 for key in ['G','S']:c[key]=[(x,y+YPAD)for x,y in c[key]]
NAMES=['Start','Set elbows','Initiate push','Mid pushdown','Lockout','Controlled return']
CUES=['Elbows beside ribs; hold both rope ends.','Begin extending without swinging your upper arms.','Push the rope down through both hands.','Keep extending; hold your torso steady.','Straighten your arms; spread the rope ends.','Return slowly to the bent-arm start.']
TS=[0,.1,.4,.7,1,0]
WINDOW=(215,250+YPAD,655,850+YPAD)
def sha(data):return hashlib.sha256(data).hexdigest()
def save(im,p):im.save(p)
def circle_intersection(a,b,ra,rb):
 a=np.array(a,float);b=np.array(b,float);v=b-a;d=np.linalg.norm(v)
 x=(ra*ra-rb*rb+d*d)/(2*d);height=math.sqrt(max(0,ra*ra-x*x));base=a+x*v/d;perp=np.array([-v[1],v[0]])/d
 pts=[base+height*perp,base-height*perp];return min(pts,key=lambda p:p[1])
def rope_geometry(c):
 gs=[np.array(p,float) for p in c['G']];ss=[np.array(p,float)for p in c['S']]
 stub=[float(np.linalg.norm(s-g))for s,g in zip(ss,gs)]
 branch=320.;r=[branch-l for l in stub]
 j=circle_intersection(ss[0],ss[1],r[0],r[1])
 lengths=[stub[i]+float(np.linalg.norm(j-ss[i]))for i in range(2)]
 return j,dict(grips=c['G'],stubTips=c['S'],preservedStubLengths=stub,branchLengths=lengths,junction=j.tolist(),totalRopeBranchLength=sum(lengths))
CENTER=np.array([820.,78.]);RADIUS=24.
def cable_geometry(j):
 # Fixed high sheave: free tangent from actual rope-junction eye, upper arc to
 # right-most tangent, then vertical cable to selected plates, a 1:1 path.
 eye=np.array([j[0],j[1]-17]);v=eye-CENTER;d2=float(v@v);perp=np.array([-v[1],v[0]])
 q=RADIUS*math.sqrt(d2-RADIUS*RADIUS)/d2
 t1=CENTER+RADIUS*RADIUS/d2*v+q*perp;t2=CENTER+RADIUS*RADIUS/d2*v-q*perp
 t=min([t1,t2],key=lambda p:p[1]);theta=math.atan2(t[1]-CENTER[1],t[0]-CENTER[0]);theta=theta if theta<=0 else theta-2*math.pi
 tangent=float(np.linalg.norm(t-eye));arc=-theta*RADIUS
 return eye,t,theta,tangent,arc
class Surface:
 def __init__(self):self.ss=3;self.im=Image.new('RGBA',(W*3,H*3));self.d=ImageDraw.Draw(self.im)
 def xy(self,pts):return [(int(round(x*self.ss)),int(round(y*self.ss)))for x,y in pts]
 def line(self,pts,fill,width=1):self.d.line(self.xy(pts),fill=fill,width=int(round(width*self.ss)),joint='curve')
 def poly(self,pts,fill,outline=None):self.d.polygon(self.xy(pts),fill=fill)
 def rect(self,box,fill,outline=None,width=1):self.d.rectangle(tuple(int(round(v*self.ss))for v in box),fill=fill,outline=outline,width=int(width*self.ss))
 def ellipse(self,box,fill,outline=None,width=1):self.d.ellipse(tuple(int(round(v*self.ss))for v in box),fill=fill,outline=outline,width=int(width*self.ss))
 def finish(self):return self.im.resize((W,H),Image.Resampling.LANCZOS)
def fixed_equipment():
 s=Surface()
 # Ground frame and modest tower, all fixed across frames.
 s.poly([(704,1455),(958,1455),(991,1482),(737,1482)],(43,44,46,255));s.poly([(737,1482),(991,1482),(991,1494),(737,1494)],(28,29,31,255))
 for x in [728,935]:
  s.rect((x,22,x+20,1458),(51,53,56,255));s.rect((x,22,x+5,1458),(75,77,80,255));s.line([(x+19,24),(x+19,1458)],(28,29,31,255),2)
 s.rect((728,22,955,45),(53,55,58,255));s.line([(731,25),(952,25)],(86,88,91,255),3)
 s.poly([(749,42),(832,42),(832,78),(808,78),(808,62),(749,62)],(59,61,64,255))
 # Guide rods and stack bed.
 for x in [790,900]:s.line([(x,120),(x,1370)],(123,126,130,255),5);s.line([(x-1,121),(x-1,1370)],(173,176,179,255),1)
 s.rect((772,1343,917,1364),(54,56,59,255));s.rect((780,1364,909,1384),(33,34,36,255))
 # Eight unselected plates stay fixed, after the four selected plates of twelve.
 for k in range(8):
  y=1172+k*21;s.poly([(783,y),(900,y),(909,y+5),(909,y+18),(783,y+18),(774,y+13),(774,y+3)],(51,53,56,255));s.line([(785,y+3),(901,y+3)],(94,96,99,255),2);s.line([(784,y+17),(906,y+17)],(26,27,29,255),2)
 # Finite exposed sheave, no zero-radius cable corner.
 cx,cy=CENTER;s.ellipse((cx-29,cy-29,cx+29,cy+29),(36,37,39,255),(87,89,92,255),2);s.ellipse((cx-24,cy-24,cx+24,cy+24),(59,61,64,255),(112,114,117,255),1);s.ellipse((cx-7,cy-7,cx+7,cy+7),(121,123,126,255),(37,38,40,255),2)
 return s.finish()
def selected_stack(top):
 s=Surface()
 for k in range(4):
  y=top+k*21;s.poly([(783,y),(900,y),(909,y+5),(909,y+18),(783,y+18),(774,y+13),(774,y+3)],(65,67,70,255));s.line([(785,y+3),(901,y+3)],(119,121,124,255),2);s.line([(784,y+17),(906,y+17)],(29,30,32,255),2)
 s.rect((831,top-10,857,top+2),(82,85,89,255));s.line([(844,top-10),(844,top+30)],(153,155,158,255),3)
 # Small neutral selector pin, no extra colour or legend.
 s.line([(777,top+3*21+10),(762,top+3*21+10)],(159,161,164,255),4);s.ellipse((756,top+3*21+6,765,top+3*21+15),(102,104,107,255))
 return s.finish()
def braided(s,a,b):
 a=np.array(a,float);b=np.array(b,float);v=b-a;length=float(np.linalg.norm(v));u=v/length;n=np.array([-u[1],u[0]])
 s.line([a,b],(37,38,40,255),12);s.line([a,b],(66,67,69,255),8)
 for dist in np.arange(5,length-3,12):
  q=a+u*dist;s.line([q-n*3-u*2,q+n*3+u*2],(99,100,102,255),2)
def moving_equipment(c,j,top,cab):
 s=Surface();eye,t,theta,free,arc=cab
 for a in c['S']:braided(s,a,j)
 # Shared rope attachment and high cable connect at the same defined eye.
 s.ellipse((j[0]-7,j[1]-18,j[0]+7,j[1]+2),None,(149,151,154,255),3)
 s.line([eye,t],(125,128,132,255),4);s.line([eye,t],(181,184,187,255),1)
 angles=np.linspace(theta,0,60);pts=[CENTER+RADIUS*np.array([math.cos(x),math.sin(x)])for x in angles]
 s.line(pts, (129,132,136,255),4);s.line(pts,(182,185,188,255),1)
 s.line([(CENTER[0]+RADIUS,CENTER[1]),(CENTER[0]+RADIUS,top-10)],(129,132,136,255),4);s.line([(CENTER[0]+RADIUS,CENTER[1]),(CENTER[0]+RADIUS,top-10)],(182,185,188,255),1)
 return s.finish()
def palette(im,index):
 a=np.array(im.convert('RGB')).astype(float);h,w=a.shape[:2];yy,xx=np.indices((h,w));yy=yy-YPAD;blue=a[:,:,2]-np.maximum(a[:,:,0],a[:,:,1]);alpha=np.clip((blue-8)/14,0,1)
 # Existing chromatic fields only; no new anatomical region boundaries.
 # Near triceps above native elbow, far triceps before forearm colour begins.
 near_limits=[290,300,315,322,320]
 primary=((xx<near_limits[index])&(yy<510))|((xx>490)&(yy<500))
 m=(alpha>0)&(yy>330)&(yy<720)&(xx>220)&(xx<640)
 arr=np.zeros((H,W,4),np.uint8)
 for isprimary,target in [(True,np.array([123.,114.,233.])),(False,np.array([149.,144.,224.]))]:
  sel=m&(primary==isprimary)
  if not np.any(sel):continue
  luma=a[sel]@np.array([.2126,.7152,.0722]);center=float(np.median(luma));offset=np.clip((luma-center)*.6,-50,35)
  arr[sel,:3]=np.clip(target+offset[:,None],0,255).astype(np.uint8);arr[sel,3]=(alpha[sel]*255).astype(np.uint8)
 return Image.fromarray(arr,'RGBA')
def ora(path,layers,merged):
 # layers in visual top-to-bottom order; native sizes, no anatomical resampling.
 root=ET.Element('image',w=str(W),h=str(H),name=path.stem,version='0.0.3');stack=ET.SubElement(root,'stack')
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED)as z:
  z.writestr('mimetype','image/openraster',compress_type=zipfile.ZIP_STORED)
  for i,(name,im)in enumerate(layers):
   src=f'data/layer-{i}.png';b=io.BytesIO();im.save(b,format='PNG');z.writestr(src,b.getvalue());ET.SubElement(stack,'layer',name=name,src=src,x='0',y='0',opacity='1.0',visibility='visible',**{'composite-op':'svg:src-over'})
  z.writestr('stack.xml',ET.tostring(root,encoding='utf-8'));b=io.BytesIO();merged.save(b,format='PNG');z.writestr('mergedimage.png',b.getvalue())
  for member in z.namelist():z.read(member)
def composite(layers):
 a=Image.new('RGBA',(W,H))
 for _,im in reversed(layers):a=Image.alpha_composite(a,im)
 return a
native_sources=[Image.open(ROOT/'originals'/f'{n}.png').convert('RGB')for n in SOURCES]
assert all(im.size==(1024,1536)for im in native_sources)
sources=[]
for im in native_sources:
 padded=Image.new('RGB',(W,H));padded.paste(im,(0,YPAD));sources.append(padded)
base=sources[0];base_arr=np.array(base);mask=Image.new('L',(W,H));ImageDraw.Draw(mask).rectangle(WINDOW,fill=255)
# 4px edge feather affects alpha placement only, not source coordinate geometry.
mask=mask.filter(ImageFilter.GaussianBlur(2));ma=np.array(mask);ma[:248+YPAD]=0;ma[853+YPAD:]=0;ma[:,:213]=0;ma[:,658:]=0;mask=Image.fromarray(ma)
mask.save(OUT/'layers/native-moving-source-window.png')
fixed=fixed_equipment();fixed.save(OUT/'layers/fixed-tower-unselected-eight-of-twelve.png')
black=Image.new('RGBA',(W,H),(0,0,0,255));base_rgba=base.convert('RGBA')
# Source master background is black; the fixed apparatus never intersects this native source bounding box.
alpha=np.clip(np.array(base).max(axis=2).astype(float)/18,0,1)*255;base_rgba.putalpha(Image.fromarray(alpha.astype(np.uint8)))
rows=[];j0,rg0=rope_geometry(CONTACTS[0]);cg0=cable_geometry(j0);initial_top=1088.;total_cable=cg0[3]+cg0[4]+(initial_top-10-CENTER[1])
for index,(src,c)in enumerate(zip(sources,CONTACTS)):
 move=src.convert('RGBA');move.putalpha(mask if index else Image.new('L',(W,H),0))
 human=Image.alpha_composite(base.convert('RGBA'),move);pal=palette(human,index)
 j,rg=rope_geometry(c);cg=cable_geometry(j);stacktop=total_cable-cg[3]-cg[4]+CENTER[1]+10
 plates=selected_stack(stacktop);rope=moving_equipment(c,j,stacktop,cg)
 layers=[('Actual rope branches, attachment eye and conserved finite-sheave cable',rope),('Existing native muscle fields mapped to primary7B72E9 secondary9590E0',pal),('Generated connected moving arm region at unchanged native coordinates',move),('Accepted fixed master head torso legs trainers; black keyed only',base_rgba),('Four selected plates move together',plates),('Fixed grey tower24px-radius sheave guide rods and eight unselected plates',fixed),('Black background',black)]
 final=composite(layers).convert('RGB');num=index+1;final.save(OUT/'frames'/f'{num}.png');final.save(OUT/'frames'/f'{num}.webp',lossless=True,quality=100,method=6);ora(OUT/'editables'/f'{num}.ora',layers,final.convert('RGBA'))
 pal.save(OUT/'layers'/f'{num}-muscles.png');move.save(OUT/'layers'/f'{num}-native-moving-human.png');rope.save(OUT/'layers'/f'{num}-rope-cable.png');plates.save(OUT/'layers'/f'{num}-selected-stack.png')
 decoded=np.array(Image.open(OUT/'frames'/f'{num}.webp').convert('RGB'));assert np.array_equal(decoded,np.array(final))
 row={'frame':num,'source':f'originals/{SOURCES[index]}.png','sourceSha256':sha((ROOT/'originals'/f'{SOURCES[index]}.png').read_bytes()),'t':TS[index],'label':NAMES[index],'cue':CUES[index],**rg,'cable':{'sheaveCenter':CENTER.tolist(),'radius':RADIUS,'eye':cg[0].tolist(),'tangent':cg[1].tolist(),'tangentFreeLength':cg[3],'arcLength':cg[4],'verticalLength':stacktop-10-CENTER[1],'totalLength':cg[3]+cg[4]+stacktop-10-CENTER[1],'constantTotalLength':total_cable,'error':cg[3]+cg[4]+stacktop-10-CENTER[1]-total_cable},'stack':{'selected':4,'total':12,'top':stacktop,'rise':initial_top-stacktop,'platePitch':21,'selectedPlateHeight':18,'fixedUnselectedTop':1172},'pngSha256':sha((OUT/'frames'/f'{num}.png').read_bytes()),'webpSha256':sha((OUT/'frames'/f'{num}.webp').read_bytes()),'losslessRgbExact':True}
 rows.append(row)
 # Observe composite preservation before equipment/palette finishing.
 if index:
  h=np.array(human.convert('RGB'));outside=ma==0;assert np.array_equal(h[outside],base_arr[outside])
# Sixth file is actual controlled return, byte-identical start artwork with a distinct cue.
for ext in ['png','webp']:(OUT/'frames'/f'6.{ext}').write_bytes((OUT/'frames'/f'1.{ext}').read_bytes())
(OUT/'editables/6.ora').write_bytes((OUT/'editables/1.ora').read_bytes())
last=dict(rows[0]);last.update(frame=6,t=TS[5],label=NAMES[5],cue=CUES[5],reuseOfFrame=1);rows.append(last)
assert all(abs(v['cable']['error'])<1e-9 for v in rows)
assert all(abs(n-320)<1e-9 for v in rows for n in v['branchLengths'])
assert [v['stack']['rise'] for v in rows[:5]]==sorted(v['stack']['rise'] for v in rows[:5])
proof={'status':'native-candidate-requires-root-review-not-publication','canvas':[W,H],'physicalOrder':rows,'fixedSourceWindow':list(WINDOW),'wholeSourcePlacement':[0,YPAD],'sourceCanvas':[1024,1536],'nativeAnatomicalTransforms':[],'fixedMasterOutsideWindowExact':True,'equipmentRasterization':'3x antialias then native equipment-only raster; human pixels are not resized','sourceIdentity':'FA56 canonical, source-attached on every operation','limitations':['Native projected contact points are illustrative image samples, not calibrated3D anatomy.','Some generated upper-arm/elbow/forearm contour variation remains within native connected source window; no strict fixed-joint certification.','Generated short rope stubs and stoppers retain small illustrative differences; new upper branch lengths and cable path are explicitly conserved.','Native source muscles preserve only existing colour fields; exact anatomical ownership must be visually reviewed.','Root must review native full sequence and actual mobile light/dark/playback/cards before release.']}
(OUT/'native-sequence-and-mechanics.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
contact=Image.new('RGB',(1536,768),(20,20,22));d=ImageDraw.Draw(contact)
for i in range(6):
 im=Image.open(OUT/'frames'/f'{i+1}.png');im.thumbnail((256,730));contact.paste(im,(i*256,28));d.text((i*256+8,8),f'{i+1} {NAMES[i]}',fill='white')
contact.save(OUT/'review/native-sequence-diagnostic.png')
# Native upper-body crops for visual grip/rope and seam review, no delivery resizing.
for i in range(1,6):Image.open(OUT/'frames'/f'{i}.png').crop((210,240+YPAD,670,850+YPAD)).save(OUT/'review'/f'{i}-native-arms.png')
print(json.dumps({'output':str(OUT),'frames':6,'physicalSources':5,'stackRisePixels':[round(v['stack']['rise'],6)for v in rows],'maxCableConservationError':max(abs(v['cable']['error'])for v in rows),'fixedRopeBranchesPixels':[320,320]},indent=2))
