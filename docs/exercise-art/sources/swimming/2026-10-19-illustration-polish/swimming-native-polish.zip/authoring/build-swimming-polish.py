"""Editable colour-only draft from the current decoded drawings; no anatomy transforms."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np,json,hashlib,colorsys,io,zipfile,xml.etree.ElementTree as ET,argparse
H=Path(__file__).resolve().parent;R=H.parent/'Maiin-burpees';p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=H/'candidate-v3');O=p.parse_args().output;O.mkdir(exist_ok=True)
IDS=['swimming']
def analyse(im,min_y=0):
 a=np.asarray(im.convert('RGBA'));rgb=a[:,:,:3].astype(float)/255;r,g,b=rgb[:,:,0],rgb[:,:,1],rgb[:,:,2];mx=rgb.max(2);mn=rgb.min(2);ch=mx-mn;light=(mx+mn)/2;hue=np.zeros(ch.shape);m=(mx==b)&(ch>0);hue[m]=((r[m]-g[m])/ch[m]+4)*60;m=(mx==r)&(ch>0);hue[m]=((g[m]-b[m])/ch[m]%6)*60;sat=np.divide(ch,1-np.abs(2*light-1),out=np.zeros_like(ch),where=(light>0)&(light<1));support=(b-g>4/255)&(hue>235)&(hue<340)&(light>.38)&(sat>.14)&(a[:,:,3]>0);support[:min_y]=False;return a,light,ch,support
targets=[colorsys.rgb_to_hls(*[n/255 for n in c])for c in [(149,144,224),(123,114,233)]]
def recolour(im,anchor,min_y=0):
 a,light,ch,support=analyse(im,min_y)
 # One fixed chroma anchor for the entire exercise. Existing source pigment
 # strength moves within the two canonical targets; no anatomical field is
 # added, relabelled or fitted, and original per-pixel lightness is retained.
 w=np.clip((ch/anchor-.25)/.55,0,1);hue=targets[0][0]+w*(targets[1][0]-targets[0][0]);sat=targets[0][2]+w*(targets[1][2]-targets[0][2]);c=(1-np.abs(2*light-1))*sat;x=c*(1-np.abs((hue*6)%2-1));m=light-c/2;rgb=np.stack([m+x,m,m+c],2)*255;out=a.copy();out[support,:3]=np.rint(rgb[support]).clip(0,255).astype(np.uint8);return Image.fromarray(out),support,w
def png(im):
 b=io.BytesIO();im.save(b,format='PNG');return b.getvalue()
def ora(path,source,mask,final):
 layer=np.array(final);layer[:,:,3]=np.where(mask,255,0);layer=Image.fromarray(layer);doc=ET.Element('image',w=str(final.width),h=str(final.height));stack=ET.SubElement(doc,'stack');ET.SubElement(stack,'layer',name='Canonical chroma in existing source colour fields',src='data/colour.png',opacity='1.0',visibility='visible',**{'composite-op':'svg:src-over'});ET.SubElement(stack,'layer',name='Exact current native source',src='data/source.png',opacity='1.0',visibility='visible',**{'composite-op':'svg:src-over'})
 assert Image.alpha_composite(source,layer).tobytes()==final.tobytes()
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED)as z:
  for name,data in [('mimetype',b'image/openraster'),('stack.xml',ET.tostring(doc)),('data/colour.png',png(layer)),('data/source.png',png(source)),('mergedimage.png',png(final))]:z.writestr(name,data)
facts=[];font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',17)
for ident in IDS:
 ims=[Image.open(R/f'public/form-frames/{ident}/{n}.webp').convert('RGBA')for n in range(1,7)]
 strengths=[];seen=set()
 gates=[680,590,577,550,330,166]if ident=='turkish-get-up'else[0]*6
 for im,min_y in zip(ims,gates):
  digest=hashlib.sha256(im.tobytes()).hexdigest()
  if digest in seen:continue
  seen.add(digest);_,_,ch,support=analyse(im,min_y);strengths.append(ch[support])
 anchor=float(np.percentile(np.concatenate(strengths),98));out=O/ident
 for sub in ['source','originals','frames','layers','editables']:(out/sub).mkdir(parents=True,exist_ok=True)
 sheet=Image.new('RGB',(1800,660),'#18181b');d=ImageDraw.Draw(sheet);seen={};posefacts=[]
 for n,im in enumerate(ims,1):
  final,support,w=recolour(im,anchor,gates[n-1]);a=np.asarray(im);b=np.asarray(final);assert np.array_equal(a[~support],b[~support])and np.array_equal(a[:,:,3],b[:,:,3]);assert np.max(np.abs((a[:,:,:3].max(2).astype(float)+a[:,:,:3].min(2))/2-(b[:,:,:3].max(2).astype(float)+b[:,:,:3].min(2))/2))<=.5
  im.save(out/f'originals/{n}.png');final.convert('RGB').save(out/f'source/{n}.png');final.convert('RGB').save(out/f'frames/{n}.webp',lossless=True,quality=100,method=3,exact=True);Image.fromarray((support*255).astype(np.uint8)).save(out/f'layers/{n}-colour-support.png')
  digest=hashlib.sha256(im.tobytes()).hexdigest()
  if digest not in seen:ora(out/f'editables/{n}.ora',im,support,final);seen[digest]=n
  thumb=final.convert('RGB');thumb.thumbnail((296,600));sheet.paste(thumb,((n-1)*300+(300-thumb.width)//2,35+(600-thumb.height)//2));d.text(((n-1)*300+6,8),f'{ident} {n}',font=font,fill='white');posefacts.append({'frame':n,'pixels':int(support.sum()),'samePhysicalSourceAs':seen[digest],'outsideColourExact':True,'alphaExact':True,'maxLightnessRoundoff8bit':.5})
 sheet.save(out/'six-frame-review.png');facts.append({'id':ident,'chromaAnchor98':anchor,'sourceLightnessPreserved':True,'getUpBodySupportMinimumYs':gates,'lowSaturationAndDarkEquipmentExcluded':True,'outsideSelectedColourFieldsExact':True,'newAnatomicalFields':0,'anatomicalTransforms':[],'frames':posefacts})
(O/'colour-proof.json').write_text(json.dumps({'method':'Canonical primary/secondary HSL chroma ramp driven only by existing source pigment strength; fixed exercise anchor; original per-pixel HSL lightness and all nonselected RGBA exact. No new spatial shading gradient or anatomical resegmentation.','targets':{'primary':'#7B72E9','secondary':'#9590E0'},'exercises':facts},indent=2)+'\n',encoding='utf-8');print(json.dumps({'draftGuides':len(facts),'frames':42,'nativeAnatomicalTransforms':0}))

