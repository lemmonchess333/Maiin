"""Portable native scene/equipment composition; original complete athlete drawings are not deformed."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import numpy as np,json,hashlib,argparse,io,zipfile,xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--output',type=Path,required=True);a=p.parse_args();P=a.root;O=a.output;O.mkdir(parents=True,exist_ok=True);cfg=json.loads((P/'manifest.json').read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for d in ['source','frames','editables','layers']:(O/d).mkdir(exist_ok=True)
def png(im):b=io.BytesIO();im.save(b,format='PNG');return b.getvalue()
scene=Image.new('RGBA',tuple(cfg['canvas']),(0,0,0,255));d=ImageDraw.Draw(scene)
if cfg['id']=='turkish-get-up':
 mat=[tuple(x)for x in cfg['mat']];d.polygon(mat,fill=(22,22,25));d.line(mat+[mat[0]],fill=(77,77,84),width=2)
 gen=Image.open(P/'equipment-generated.png').convert('RGBA');assert sha(P/'equipment-generated.png')==cfg['equipmentGeneratedSha256'];master=gen.crop(gen.getbbox());master=master.resize((91,108),Image.Resampling.LANCZOS)
else:
 W,H=cfg['canvas'];d.rectangle((0,214,W-1,248),fill=(45,45,50));d.rectangle((0,249,W-1,279),fill=(26,26,30));d.line((0,214,W-1,214),fill=(101,101,108),width=2);d.line((0,248,W-1,248),fill=(73,73,80),width=2);d.line((0,279,W-1,279),fill=(67,67,73),width=2)
 for x in range(128,W,208):d.line((x,214,x,279),fill=(105,105,112),width=2)
scene.save(O/'layers/fixed-material-scene.png');facts=[]
for row in cfg['frames']:
 n=row['frame'];path=P/row['source'];assert sha(path)==row['sourceSha256'];im=Image.open(path).convert('RGB');b=np.asarray(im);q=b.max(2);keep=q>8;equipment=Image.new('RGBA',scene.size);offset=tuple(row.get('translation',[0,0]));removedLine=0;semanticRegion=None
 if cfg['id']=='swimming':
  cool=(b[:,:,1].astype(int)>b[:,:,0].astype(int)+3)&(b[:,:,2].astype(int)>b[:,:,1].astype(int)+2)&(q<100)&(q>8);bands=np.flatnonzero(cool.sum(1)>250);line=np.zeros_like(keep)
  for y in bands:line[max(0,y-1):y+2]|=cool[max(0,y-1):y+2]
  keep &=~line;removedLine=int(line.sum())
 else:
  cx,top=row['gripTop'];x0,y0,x1,y1=row['equipmentRegion'];region=b[y0:y1,x0:x1];core=(region.min(2)>=185)&(np.arange(region.shape[1])[None,:]+x0>=cx-20);body=np.zeros(core.shape,dtype=np.uint8)
  for yy in range(core.shape[0]):
   xx=np.flatnonzero(core[yy])
   if len(xx):body[yy,xx.min():xx.max()+1]=255
  handMask=np.asarray(Image.fromarray(body).filter(ImageFilter.MaxFilter(3)))>0;scope=np.zeros(core.shape,dtype=bool);scope[max(0,top+3-y0):min(core.shape[0],top+130-y0),max(0,cx-70-x0):min(core.shape[1],cx+55-x0)]=True;erase=scope&~handMask;keep[y0:y1,x0:x1]&=~erase;semanticRegion=[x0,y0,x1,y1];equipment.alpha_composite(master,tuple(row['equipmentTranslation']));Image.fromarray(np.uint8(erase)*255).save(O/f'layers/{n}-old-equipment-removal.png')
 original=im.convert('RGBA');original.putalpha(Image.fromarray(np.uint8(keep)*255));athlete=Image.new('RGBA',scene.size);athlete.alpha_composite(original,offset);card=Image.alpha_composite(equipment,athlete);final=Image.alpha_composite(scene,card)
 dx,dy=offset;actual=np.asarray(final.convert('RGB'))[dy:dy+im.height,dx:dx+im.width];assert np.array_equal(actual[keep],b[keep]);assert np.array_equal(actual[b.min(2)>=185],b[b.min(2)>=185])if cfg['id']=='swimming'else True
 final.convert('RGB').save(O/f'source/{n}.png');final.convert('RGB').save(O/f'frames/{n}.webp',lossless=True,quality=100,method=3,exact=True);assert Image.open(O/f'frames/{n}.webp').convert('RGBA').tobytes()==final.tobytes();athlete.save(O/f'layers/{n}-athlete.png');equipment.save(O/f'layers/{n}-equipment.png')
 if n==cfg['cardFrame']:card.save(O/'prepared-card.png')
 doc=ET.Element('image',w=str(final.width),h=str(final.height));stack=ET.SubElement(doc,'stack')
 for name,src in [('Original intact athlete and grip','data/athlete.png'),('One rigid equipment master','data/equipment.png'),('Fixed physical scene','data/scene.png')]:ET.SubElement(stack,'layer',name=name,src=src,opacity='1.0',visibility='visible',**{'composite-op':'svg:src-over'})
 with zipfile.ZipFile(O/f'editables/{n}.ora','w')as z:
  for name,data in [('mimetype',b'image/openraster'),('stack.xml',ET.tostring(doc)),('data/athlete.png',png(athlete)),('data/equipment.png',png(equipment)),('data/scene.png',png(scene)),('mergedimage.png',png(final))]:
   zi=zipfile.ZipInfo(name,(2026,10,20,0,0,0));zi.compress_type=zipfile.ZIP_STORED if name=='mimetype'else zipfile.ZIP_DEFLATED;z.writestr(zi,data)
 facts.append({'frame':n,'webpSha256':sha(O/f'frames/{n}.webp'),'nativeRgbaSha256':hashlib.sha256(final.tobytes()).hexdigest(),'integerTranslation':offset,'allRetainedNativeAthleteAndGripPixelsExact':True,'anatomicalTransforms':[],'removedOldWaterLinePixels':removedLine,'equipmentSemanticRegion':semanticRegion})
(O/'reproduction.json').write_text(json.dumps({'id':cfg['id'],'frames':facts,'scope':'Fixed physical scene, intact original athlete pixels, and one rigid TGU equipment master. No anatomical warps, per-limb fitting, isolated head/shoe grafts or new anatomy shading. Six independent native exports; not a contact-sheet enlargement.'},indent=2)+'\n',encoding='utf-8');print(json.dumps({'id':cfg['id'],'frames':len(facts),'canvas':cfg['canvas'],'output':str(O)}))
