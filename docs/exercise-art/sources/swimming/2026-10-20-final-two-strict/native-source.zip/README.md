Native source package for swimming.

Run `python reproduce.py --root . --output OUTPUT` with Pillow and NumPy. Original complete athlete sources, canonical identity reference, manifest, layered native ORA editables and measured material evidence are included. No anatomical deformation, individual limb fitting or isolated head/shoe grafts. Swimming uses whole-athlete integer translation; get-up replaces old equipment with one complete rigid master behind the original grip. All original retained athlete RGB pixels are asserted exact. Scene corner measurements do not replace visual body/contact review.

Primary coaching comparison: https://www.swimming.org/masters/improving-front-crawl-technique/ and https://www.swimming.org/justswim/improving-your-breathing-in-front-crawl/ — long body line, body roll and side breathing with small continuous kicks. This depicts six forward-moving stroke phases and stops before replay; it does not claim calibrated stroke distance or speed.
