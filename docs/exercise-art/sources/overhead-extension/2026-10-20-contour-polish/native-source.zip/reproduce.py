"""Recompose scoped native source corrections; never generates or fits anatomy."""
from pathlib import Path
from PIL import Image
from io import BytesIO
import argparse,hashlib,json,zipfile,xml.etree.ElementTree as ET,shutil
p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path);a=p.parse_args();root=Path(__file__).resolve().parent;out=a.output.resolve();out.mkdir(parents=True,exist_ok=True);cfg=json.loads((root/'manifest.json').read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def png(im):
    b=BytesIO();im.save(b,format='PNG');return b.getvalue()
for d in ['frames','source','editables']:(out/d).mkdir(exist_ok=True)
seen=set()
for f in cfg['frames']:
    base=root/f['original'];layer=root/f['layer'];assert sha(base)==f['originalSha256'] and sha(layer)==f['layerSha256'];original=Image.open(base).convert('RGBA');patch=Image.open(layer).convert('RGBA');final=Image.alpha_composite(original,patch)
    assert hashlib.sha256(final.tobytes()).hexdigest()==f['rgbaSha256'];n=f['frame'];final.convert('RGB').save(out/f'source/{n}.png')
    if f['changedPixels']:final.convert('RGB').save(out/f'frames/{n}.webp',lossless=True,quality=100,method=3,exact=True)
    else:shutil.copyfile(base,out/f'frames/{n}.webp')
    assert sha(out/f'frames/{n}.webp')==f['finalSha256']
    key=(f['original'],f['layer'])
    if key in seen:continue
    seen.add(key);doc=ET.Element('image',w=str(final.width),h=str(final.height));stack=ET.SubElement(doc,'stack')
    for name,path in [('Scoped correction','data/correction.png'),('Original approved complete drawing','data/source.png')]:ET.SubElement(stack,'layer',name=name,src=path,opacity='1',visibility='visible',**{'composite-op':'svg:src-over'})
    with zipfile.ZipFile(out/f'editables/{n}.ora','w')as z:
        for name,data in [('mimetype',b'image/openraster'),('stack.xml',ET.tostring(doc)),('data/correction.png',png(patch)),('data/source.png',png(original)),('mergedimage.png',png(final))]:
            info=zipfile.ZipInfo(name,(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_STORED if name=='mimetype'else zipfile.ZIP_DEFLATED;z.writestr(info,data)
    with zipfile.ZipFile(out/f'editables/{n}.ora')as z:
        b=Image.open(BytesIO(z.read('data/source.png'))).convert('RGBA');l=Image.open(BytesIO(z.read('data/correction.png'))).convert('RGBA');assert Image.alpha_composite(b,l).tobytes()==final.tobytes()
(out/'reproduction.json').write_text(json.dumps({'id':cfg['id'],'allSixEncodedHashesExact':True,'nativeOraCompositionsReopenedExact':True,'anatomicalTransforms':[]},indent=2)+'\n')
print({'id':cfg['id'],'allSixEncodedHashesExact':True})
