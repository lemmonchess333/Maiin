"""Portable native-coordinate OHP redraw. Pillow and NumPy only.

Three genuine generated poses -> six separate playback files. No anatomical
warping, scaling, reflection or individual limb fitting. Whole repaired native
sources are retained without source-region selection or head/shoe insertions.
One native equipment template moves by integer translation only.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import numpy as np
import hashlib,io,json,zipfile,xml.etree.ElementTree as ET,argparse

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
SIZE=(1024,1536)
PRIMARY=np.array([123,114,233],dtype=float)
SECONDARY=np.array([149,144,224],dtype=float)
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=HERE)
OUT=parser.parse_args().output.resolve();OUT.mkdir(parents=True,exist_ok=True)
for name in ['frames','layers','review']:(OUT/name).mkdir(exist_ok=True)
SOURCES={'A':'1-master-native.png','B':'3-mid-native-join-repair.png','C':'5-lockout-elbow-extension-native.png'}
BAR={'A':473,'B':285,'C':129}
base=Image.open(ROOT/'originals'/SOURCES['A']).convert('RGB')
assert base.size==SIZE
ba=np.array(base)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def png(im):
 b=io.BytesIO();im.save(b,format='PNG');return b.getvalue()
def poly(points):
 m=Image.new('L',SIZE,0);ImageDraw.Draw(m).polygon(points,fill=255);return np.array(m)>0
def rect(box):
 m=Image.new('L',SIZE,0);ImageDraw.Draw(m).rectangle(box,fill=255);return np.array(m)>0
def mirrorpoints(points):return [(1023-x,y) for x,y in points]

# The barbell is native source equipment, not anatomy. Replace hand-occluded
# portions of its shaft with repeated adjacent native shaft texture.
eq=np.zeros((SIZE[1],SIZE[0],4),dtype=np.uint8)
mask=rect((8,464,1013,481))|rect((58,357,146,594))|rect((877,357,966,594))|rect((8,460,61,487))|rect((961,460,1013,487))
eq[:,:,:3][mask]=ba[mask];eq[:,:,3][mask]=255
for x1,x2 in [(295,367),(648,724)]:
 for x in range(x1,x2):eq[464:482,x,:3]=ba[464:482,200+(x%28)]
template=Image.fromarray(eq,'RGBA');template.save(OUT/'layers/barbell-native-template.png')

upper_alpha=np.zeros((1536,1024),dtype=np.uint8)
upper_alpha[:590]=255
upper_alpha[270:430,449:575]=0
Image.fromarray(upper_alpha).save(OUT/'layers/native-moving-upper-region-mask.png')

chest={
 'A':[(399,516),(409,505),(429,497),(460,499),(488,504),(508,514),(510,541),(490,534),(465,529),(438,525),(416,524),(402,525)],
 'B':[(400,497),(415,484),(437,479),(465,482),(489,489),(509,502),(510,531),(489,525),(465,518),(441,514),(420,512),(403,512)],
 'C':[(406,484),(427,474),(452,474),(479,487),(509,505),(510,532),(489,525),(466,517),(444,509),(426,506),(409,506)],
}
triceps={
 'A':[(366,582),(392,595),(395,615),(375,637),(352,651),(339,637),(350,607)],
 'B':[(305,483),(329,493),(376,499),(388,519),(376,536),(348,535),(324,521),(307,505)],
 'C':[(333,329),(352,338),(369,376),(381,419),(376,453),(361,465),(346,435),(335,397)],
}
hand={
 'A':[(307,448),(356,449),(366,463),(364,485),(350,501),(317,502),(297,489),(298,475),(304,465)],
 'B':[(307,260),(356,260),(365,273),(365,291),(357,311),(344,321),(316,321),(298,309),(297,291),(304,279)],
 'C':[(307,104),(356,104),(366,118),(365,138),(356,155),(346,164),(316,164),(298,152),(297,136),(304,124)],
}
geometries={};finished={};proof={}
for pose,fn in SOURCES.items():
 raw=Image.open(ROOT/'originals'/fn).convert('RGB');assert raw.size==SIZE
 native=raw.copy()
 native.save(OUT/f'{pose}-native-geometry.png')
 a=np.array(native).astype(float)
 colour=(a[:,:,2]-a[:,:,0]>12)&(a[:,:,2]-a[:,:,1]>12)
 def cleanmask(m):
  mi=Image.fromarray(np.where(m,255,0).astype('uint8')).filter(ImageFilter.MaxFilter(5)).filter(ImageFilter.MinFilter(5))
  bb=mi.getbbox()
  if not bb:return np.zeros_like(m)
  bb=(max(0,bb[0]-2),max(0,bb[1]-2),min(1024,bb[2]+2),min(1536,bb[3]+2))
  flooded=mi.crop(bb);ImageDraw.floodfill(flooded,(0,0),128)
  out=np.zeros_like(m);out[bb[1]:bb[3],bb[0]:bb[2]]=np.array(flooded)!=128
  return out
 primary=cleanmask((a[:,:,2]-a[:,:,0]>65)&(a[:,:,2]-a[:,:,1]>65)&colour)
 grey=np.max(a,axis=2)
 neutral=a.copy();neutral[colour]=np.repeat(grey[:,:,None],3,axis=2)[colour]
 # Anatomical secondary masks follow curved upper-pec regions and retain
 # only existing tinted source pixels; neutral forward biceps stay neutral.
 all_tint=cleanmask(colour)
 arm_box={'A':(330,541,405,663),'B':(299,498,389,540),'C':(326,323,387,476)}[pose]
 x1,y1,x2,y2=arm_box
 secondary=(rect(arm_box)|rect((1023-x2,y1,1023-x1,y2))|rect((414,590,611,798)))&all_tint&~primary
 # Follow the curved clavicular pectoral portion; the only softened edge
 # is a1.3px antialias, not a new decorative or whole-muscle gradient.
 chest_mask=(poly(chest[pose])|poly(mirrorpoints(chest[pose])))&all_tint&~primary
 chest_weight=np.asarray(Image.fromarray(np.where(chest_mask,255,0).astype('uint8')).filter(ImageFilter.GaussianBlur(1.3))).astype(float)/255
 rgb=np.round(neutral).clip(0,255).astype(np.uint8)
 rgba_neutral=np.zeros((1536,1024,4),dtype=np.uint8)
 rgba_neutral[:,:,:3]=rgb;rgba_neutral[:,:,3]=np.where(colour,255,0)
 Image.fromarray(rgba_neutral,'RGBA').save(OUT/f'layers/{pose}-neutralize-source-tint.png')
 colour_layer=np.zeros((1536,1024,4),dtype=np.uint8)
 for m,c in [(primary,PRIMARY),(secondary,SECONDARY)]:
  coverage=np.asarray(Image.fromarray(np.where(m,255,0).astype('uint8')).filter(ImageFilter.GaussianBlur(.65))).astype(float)/255
  target=grey[:,:,None]*c[None,None,:]/255
  rgb=np.round(rgb*(1-coverage[:,:,None])+target*coverage[:,:,None]).clip(0,255).astype(np.uint8)
 weight=np.maximum(chest_weight,np.maximum(primary,secondary).astype(float))
 # Store a full finished colour layer only where an anatomical tint is active.
 tint=grey[:,:,None]*SECONDARY[None,None,:]/255
 rgb=np.round(rgb*(1-chest_weight[:,:,None])+tint*chest_weight[:,:,None]).clip(0,255).astype(np.uint8)
 active=np.any(rgb!=np.round(neutral).clip(0,255).astype(np.uint8),axis=2)
 colour_layer[:,:,:3][active]=rgb[active];colour_layer[:,:,3][active]=255
 Image.fromarray(colour_layer,'RGBA').save(OUT/f'layers/{pose}-canonical-muscle-colours.png')
 img=Image.fromarray(rgb,'RGB').convert('RGBA')
 # Shared equipment remains the same native template at every elevation.
 equipment=Image.new('RGBA',SIZE);equipment.alpha_composite(template,(0,BAR[pose]-473))
 equipment.save(OUT/f'layers/{pose}-rigid-barbell.png')
 img=Image.alpha_composite(img,equipment)
 # Original closed hands remain foreground at their unchanged native positions.
 # Source bar fragments hidden inside the grip are ordinary occluded equipment.
 hp=poly(hand[pose])|poly(mirrorpoints(hand[pose]))
 grips=np.zeros((1536,1024,4),dtype=np.uint8)
 grips[:,:,:3]=rgb;grips[:,:,3]=np.where(hp,255,0)
 grip_layer=Image.fromarray(grips,'RGBA');grip_layer.save(OUT/f'layers/{pose}-native-closed-grips.png')
 img=Image.alpha_composite(img,grip_layer).convert('RGB')
 img.save(OUT/f'{pose}-finished.png')
 # Native full source and each authoring layer are retained in OpenRaster.
 layers=[('whole generated native source',native.convert('RGBA')),('neutralized non-target source tint',Image.fromarray(rgba_neutral,'RGBA')),('canonical primary and secondary muscle mapping',Image.fromarray(colour_layer,'RGBA')),('shared rigid native barbell',equipment),('native closed grips',grip_layer)]
 root=ET.Element('image',{'w':'1024','h':'1536','name':f'overhead-press-{pose}'});stack=ET.SubElement(root,'stack')
 with zipfile.ZipFile(OUT/f'{pose}-authoring.ora','w',zipfile.ZIP_DEFLATED) as z:
  z.writestr('mimetype','image/openraster',compress_type=zipfile.ZIP_STORED)
  for i,(name,layer) in reversed(list(enumerate(layers))):
   rel=f'data/layer{i}.png';z.writestr(rel,png(layer));ET.SubElement(stack,'layer',{'name':name,'src':rel,'opacity':'1.0','visibility':'visible','composite-op':'svg:src-over','x':'0','y':'0'})
  z.writestr('stack.xml',ET.tostring(root));z.writestr('mergedimage.png',png(img))
 finished[pose]=img
 na=np.array(native)
 proof[pose]={'source':fn,'sourceSha256':sha(ROOT/'originals'/fn),'size':list(SIZE),'barCentreY':BAR[pose],'nativeSourceRegionTransform':'identity; no resampling','originalHeadRetainedOutsideEquipment':bool(np.array_equal(na[270:430,449:575],ba[270:430,449:575])),'originalCoreRetained':bool(np.array_equal(na[590:700,400:626],ba[590:700,400:626])),'originalLowerBodyRetained':bool(np.array_equal(na[700:],ba[700:])),'primaryPixelCount':int(primary.sum()),'secondaryPixelCount':int(secondary.sum()),'finishedSha256':sha(OUT/f'{pose}-finished.png')}

# Three genuine physical poses, explicit holds/return reuse; six distinct paths.
ORDER=['A','A','B','C','C','B']
for i,pose in enumerate(ORDER,1):
 finished[pose].save(OUT/f'frames/{i}.webp',format='WEBP',lossless=True,method=6)
 finished[pose].save(OUT/f'{i}.png')
 thumb=finished[pose].resize((384,576),Image.Resampling.LANCZOS)
 thumb.save(OUT/f'review/{i}-preview.png')
sheet=Image.new('RGB',(1536,768),'black')
for j,pose in enumerate(['A','B','C']):sheet.paste(finished[pose].resize((512,768),Image.Resampling.LANCZOS),(j*512,0))
sheet.save(OUT/'review/three-pose-contact-sheet.png')
proof['sequence']={'poses':ORDER,'t':[0,0,0.55,1,1,0.55],'genuinePoseCount':3,'reused':{'2':'same ready stance as1 for bracing hold','4':'same true overhead lockout as5 while clearing head','6':'same genuine intermediate as3 on descent; loop to1 completes the return'},'nativeCanvas':list(SIZE),'canonicalAthleteSha256':'fa56dd686d1e8ff88db91b9465255eefd9837f26174acebd18ddb2851d45a72b','canonicalPalette':{'primary':'#7B72E9','secondary':'#9590E0'},'framing':'unchanged full 1024x1536 source canvas; previews only are resized'}
(OUT/'native-production-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
