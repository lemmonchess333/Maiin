# Overhead press redraw source package

Source-only candidate for the six legacy redraws. Repository, browser, registration and Git state were not modified.

Use `candidate/frames/1.webp` through `6.webp`, each native1024×1536 and lossless. Order is **A,A,B,C,C,B**, three genuine low/intermediate/overhead source poses with honest bracing/overhead holds and intermediate descent reuse. Proposed physical progress values are **0,0,0.55,1,1,0.55**. Existing front-view labels and cues remain checkable; the final intermediate descends to the starting chest position at the loop boundary.

Canonical athlete authority is FA56. Built-in imagegen created the master and native connected-arm/shoulder sources with canonical and accepted master references. Final art uses the whole repaired generated sources at unchanged native coordinates, plus separate palette and shared rigid grey barbell layers. No source resampling, anatomical warps, limb fitting, reflection, or head/shoe insertions. Small generated contour/shading differences are retained honestly. Earlier fixed-head/core composite trials are rejected diagnostics and are not production inputs.

`candidate/reproduce.py` rebuilds native geometries, palette layers, five-layer OpenRaster files and the six frames from the three selected files in `originals/`. Optional `--output ABSOLUTE_PATH` writes a separate reproduction. `candidate/technical-validation.json` records exact OpenRaster recomposites and six lossless frame comparisons. `candidate/review/native-six-playback.webp` is a1200ms/frame preview for root playback review. `source-review.json` retains minor findings and leaves all11 strict checks null.

Root still owns independent source judgment, native and integrated mobile light/dark review, normal card export, project checks, registration, CI and merge. This package is not a completed or published conversion.

Exact prompts, all10 tool outputs and source dispositions are indexed in `provenance.json`. Only the three selected native geometries feed final production; the separate early head and high-press correction routes are closed.
