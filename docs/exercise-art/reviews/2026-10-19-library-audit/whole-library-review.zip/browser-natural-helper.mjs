export async function makeNatural(tab,review){
 const saved=JSON.parse(await review.fs.readFile(review.evidence+'/manual-progress.json','utf8')).rows;
 return async function natural(id,theme,slow=false){
  await tab.playwright.getByRole('combobox',{name:'Exercise',exact:true}).selectOption(id);
  const current=await review.read();
  if(current.dark!==(theme==='dark'))await tab.playwright.getByRole('button',{name:theme==='dark'?'Dark theme':'Light theme',exact:true}).press('Enter');
  await tab.playwright.getByRole('button',{name:/^1 /}).press('Enter');
  const slower=tab.playwright.getByRole('button',{name:'Slower playback',exact:true});const speed=await slower.innerText({});
  if((speed==='Slower')!==slow)await slower.press('Enter');
  const rows=[{elapsedMs:0,...await review.settled(1,theme)}];const start=Date.now();
  await tab.playwright.getByRole('button',{name:'Play',exact:true}).press('Enter');
  const steps=id==='turkish-get-up'?[2,3,4,5,6]:[2,3,4,5,6,1];
  for(const step of steps){
   const expected=saved.find(r=>r.id===id&&r.theme===theme&&r.step===step).images[0].alt;
   await tab.playwright.getByRole('img',{name:expected,exact:true}).waitFor({state:'visible',timeoutMs:slow?6000:4000});
   const row=await review.settled(step,theme,false);
   rows.push({elapsedMs:Date.now()-start,...row});
  }
  let stopped=null;
  if(id==='turkish-get-up'){
   await tab.playwright.getByRole('button',{name:'Replay',exact:true}).waitFor({state:'visible',timeoutMs:1000});
   const holdMs=slow?5000:3000;await new Promise(resolve=>setTimeout(resolve,holdMs));
   stopped={holdMs,replayButtons:await tab.playwright.getByRole('button',{name:'Replay',exact:true}).count(),elapsedMs:Date.now()-start,...await review.read()};
  }
  const result={id,theme,slow,rows,stopped};const name=id+'-'+theme+(slow?'-slower':'-normal');
  await review.fs.writeFile(review.evidence+'/'+name+'-natural.json',JSON.stringify(result,null,2));
  return {id,theme,slow,frames:rows.map(r=>r.images.find(im=>im.hidden==='false')?.src),stopped:stopped?{replay:stopped.replayButtons,frame:stopped.images[0]?.src,elapsedMs:stopped.elapsedMs}:null};
 };
}
