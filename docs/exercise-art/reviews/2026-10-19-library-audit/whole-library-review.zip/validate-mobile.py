from pathlib import Path
import json,hashlib,re,collections
H=Path(__file__).resolve().parent
inventory=json.loads((H/'candidate-runtime-inventory.json').read_text(encoding='utf-8'));lookup={r['id']:r for r in inventory}
data=json.loads((H/'mobile/manual-progress.json').read_text(encoding='utf-8'));rows=data['rows'];errors=[]
norm=lambda s:re.sub(r'\s+','',s or '')
for r in rows:
 id=r['id'];i=0 if r['step']=='wrap' else r['step']-1;expected=lookup[id];image=r['images'][0]if len(r['images'])==1 else {}
 if len(r['images'])!=1 or not image.get('complete') or image.get('width')!=expected['art']['width'] or image.get('height')!=expected['art']['height']:errors.append([id,r['theme'],r['step'],'image decode/canvas'])
 if image.get('src')!='/Maiin/'+expected['art']['frames'][i]:errors.append([id,r['theme'],r['step'],'frame URL'])
 if norm(r['active'])!=norm(str(i+1)+expected['beats'][i]['cue']):errors.append([id,r['theme'],r['step'],'active cue'])
 if r['dark']!=(r['theme']=='dark') or r['scrollWidth']>r['width']:errors.append([id,r['theme'],r['step'],'theme/overflow'])
 card=r['card'][0]if len(r['card'])==1 else {}
 if not card.get('complete')or card.get('width',0)==0 or card.get('src')!='/Maiin/'+expected['card']['src']:errors.append([id,r['theme'],r['step'],'card'])
coverage={id:{theme:[r['step']for r in rows if r['id']==id and r['theme']==theme]for theme in ['dark','light']}for id in sorted(lookup)}
complete=[id for id,modes in coverage.items()if all(steps==[1,2,3,4,5,6,'wrap']for steps in modes.values())]
report={'scope':'Actual registered player manual frame/cue/card/canvas/theme/overflow checks, not natural autoplay claims for every guide.','viewport':data['viewport'],'rowCount':len(rows),'completedGuides':len(complete),'totalGuides':len(lookup),'missingGuides':[id for id in lookup if id not in complete],'errors':errors,'rowsSha256':hashlib.sha256((H/'mobile/manual-progress.json').read_bytes()).hexdigest(),'coverage':coverage}
(H/'mobile/manual-validation.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items()if k!='coverage'}))
if errors:raise SystemExit(1)
