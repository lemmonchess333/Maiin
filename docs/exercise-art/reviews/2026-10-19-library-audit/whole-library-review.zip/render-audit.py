"""Read-only native image/cue inventory and display-only QA sheets."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import hashlib,json,subprocess
R=Path(__file__).resolve().parent.parent/'Maiin-burpees';O=Path(__file__).resolve().parent
rows=json.loads((O/'runtime-inventory.json').read_text(encoding='utf-8'));S=O/'sheets';S.mkdir(exist_ok=True)
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',16)
small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',13)
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results=[];findings=[]
for n,row in enumerate(rows):
 ident=row['id'];ims=[];files=[]
 for j,path in enumerate(row['art']['frames']):
  p=R/'public'/path
  with Image.open(p) as im:
   im.load();rgb=im.convert('RGB');ims.append(rgb.copy())
   files.append({'path':path,'sha256':digest(p),'size':list(im.size),'decodedSha256':hashlib.sha256(rgb.tobytes()).hexdigest()})
   if list(im.size)!=[row['art']['width'],row['art']['height']]:findings.append({'id':ident,'frame':j+1,'error':'registry canvas mismatch'})
 bs=[im.convert('L').point(lambda a:255 if a>58 else 0).getbbox() for im in ims];bs=[b for b in bs if b]
 bb=(min(b[0] for b in bs),min(b[1] for b in bs),max(b[2] for b in bs),max(b[3] for b in bs))
 record=json.loads((R/row['art']['reviewFile']).read_text(encoding='utf-8-sig')) if row['art'].get('reviewFile') else {}
 results.append({'id':ident,'files':files,'uniqueDecodedFrames':len(set(f['decodedSha256'] for f in files)),'displayBounds':bb,'status':row['art']['status'],'reviewFile':row['art'].get('reviewFile'),'retainedFindings':record.get('findings',[])})
 # Each set gets its own larger labelled six-frame sheet for cue agreement review.
 sheet=Image.new('RGB',(1920,650),'#18181c');d=ImageDraw.Draw(sheet)
 for j,im in enumerate(ims):
  thumb=im.crop(bb);thumb.thumbnail((314,540));x=j*320+(320-thumb.width)//2;sheet.paste(thumb,(x,28+(540-thumb.height)//2))
  d.text((j*320+5,5),f'{ident} | {j+1}',font=font,fill='white')
  beat=row['beats'][j];text=beat['label']+': '+beat['cue'];words=text.split();lines=['']
  for word in words:
   candidate=(lines[-1]+' '+word).strip()
   if d.textlength(candidate,font=small)>305:lines.append(word)
   else:lines[-1]=candidate
  d.multiline_text((j*320+5,578),'\n'.join(lines),font=small,fill='white',spacing=3)
 sheet.save(S/f'{n+1:03}-{ident}.jpg',quality=94)
 # Initial overview: six sets / page, all six frames, union crop fixed within each set.
 if n%6==0:overview=Image.new('RGB',(1920,2160),'#18181c');od=ImageDraw.Draw(overview)
 for j,im in enumerate(ims):
  thumb=im.crop(bb);thumb.thumbnail((314,320));x=j*320+(320-thumb.width)//2;y=(n%6)*360+30+(320-thumb.height)//2;overview.paste(thumb,(x,y));od.text((j*320+4,(n%6)*360+4),f'{n+1}: {ident} {j+1}',font=font,fill='white')
 if n%6==5 or n==len(rows)-1:overview.save(S/f'overview-{n//6+1:02}.jpg',quality=94)
cards=sorted((R/'public/form-art').glob('*.webp'));card_records=[]
for n,p in enumerate(cards):
 if n%24==0:sheet=Image.new('RGB',(1680,1440),'#18181c');d=ImageDraw.Draw(sheet)
 with Image.open(p) as im:
  im.load();card_records.append({'path':str(p.relative_to(R/'public')),'sha256':digest(p),'size':list(im.size),'mode':im.mode})
  im=im.convert('RGBA');im.thumbnail((270,310));bg=Image.new('RGBA',im.size,'#18181c');bg.alpha_composite(im);x=(n%6)*280+(280-im.width)//2;y=((n%24)//6)*360+36;sheet.paste(bg.convert('RGB'),(x,y));d.text(((n%6)*280+5,((n%24)//6)*360+7),p.stem,font=font,fill='white')
 if n%24==23 or n==len(cards)-1:sheet.save(S/f'cards-{n//24+1:02}.jpg',quality=94)
out={'head':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),'scope':'Decoded inventory and display-only fixed per-set union-crop sheets; visual verdicts recorded separately.','guideCount':len(rows),'frames':sum(len(r['files']) for r in results),'cardCount':len(cards),'integrityFindings':findings,'guides':results,'cards':card_records}
(O/'decoded-inventory.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'guides':len(rows),'frames':out['frames'],'cards':len(cards),'errors':findings}))
