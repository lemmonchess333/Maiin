import fs from 'node:fs/promises';
const evidence='C:/Users/myles/Documents/Codex/2026-10-04/lg/work/library-audit-20261019/mobile';
export async function restore(tab){
 let rows=JSON.parse(await fs.readFile(evidence+'/manual-progress.json','utf8')).rows;
 const ids=(await tab.playwright.getByRole('combobox',{name:'Exercise',exact:true}).locator('option').allTextContents({})).filter(x=>!x.includes('(draft)')).sort();
 const read=async()=>await tab.playwright.evaluate(()=>({id:document.querySelector('select').value,dark:document.documentElement.classList.contains('dark'),width:document.documentElement.clientWidth,scrollWidth:document.documentElement.scrollWidth,active:document.querySelector('button[aria-current="step"]')?.textContent,images:Array.from(document.querySelectorAll('section img')).map(im=>({src:im.getAttribute('src'),complete:im.complete,width:im.naturalWidth,height:im.naturalHeight,alt:im.getAttribute('alt'),hidden:im.getAttribute('aria-hidden')})),card:Array.from(document.querySelectorAll('[data-testid="card-artwork"] img')).map(im=>({src:im.getAttribute('src'),complete:im.complete,width:im.naturalWidth,height:im.naturalHeight}))}));
 const save=async()=>await fs.writeFile(evidence+'/manual-progress.json',JSON.stringify({viewport:{width:390,height:844},rows},null,2));
 const settled=async(step,theme,manual=true)=>{
  let row;
  for(let poll=0;poll<40;poll++){
   row=await read();const current=row.images.find(im=>im.hidden==='false');
   if(row.dark===(theme==='dark')&&String(row.active).startsWith(String(step))&&current?.src.endsWith('/'+step+'.webp')&&current.complete&&current.width>0&&(!manual||row.images.length===1))return {...row,settlingReads:poll+1};
  }
  return {...row,settlingReadLimitReached:true};
 };
 const batch=async(start,count,mode='cue',themes=['dark','light'])=>{
  const activate=async button=>mode==='keys'?await button.press('Enter'):await button.click();
  for(const id of ids.slice(start,start+count)){
   await tab.playwright.getByRole('combobox',{name:'Exercise',exact:true}).selectOption(id);
   for(const theme of themes){
    if(rows.filter(r=>r.id===id&&r.theme===theme).length===7)continue;
    rows=rows.filter(r=>r.id!==id||r.theme!==theme);
    const state=await read();
    if(state.dark!==(theme==='dark'))await activate(tab.playwright.getByRole('button',{name:theme==='dark'?'Dark theme':'Light theme',exact:true}));
    for(let step=1;step<=6;step++){
     if(mode!=='cue'&&step>1)await activate(tab.playwright.getByRole('button',{name:'Next frame',exact:true}));
     else await activate(tab.playwright.getByRole('button',{name:new RegExp('^'+step+' ')}));
     const row=await settled(step,theme);
     rows.push({theme,step,control:mode==='keys'?'keyboard':mode==='next'&&step>1?'next':'cue',...row});
    }
    await activate(tab.playwright.getByRole('button',{name:'Next frame',exact:true}));rows.push({theme,step:'wrap',...await settled(1,theme)});await save();
   }
  }
  return {completed:rows.filter(r=>r.step==='wrap').length/2,rows:rows.length,last:ids[start+count-1]};
 };
 return {ids,read,settled,save,batch,evidence,fs,progress:()=>({completed:rows.filter(r=>r.step==='wrap').length/2,rows:rows.length})};
}
