import {createRoot} from 'react-dom/client';
import {useState,useEffect,useRef} from 'react';
import '../../Maiin-burpees/src/index.css';
import ExerciseFormFrames from '../../Maiin-burpees/src/components/ExerciseFormFrames';
import ExerciseFormContent from '../../Maiin-burpees/src/components/ExerciseFormContent';
import MuscleKey from '../../Maiin-burpees/src/components/MuscleKey';
import {Button} from '../../Maiin-burpees/src/components/ui/Button';
import {EXERCISES} from '../../Maiin-burpees/src/lib/exercises';
import {getReleasedFormArtwork} from '../../Maiin-burpees/src/lib/formArtwork';
import {getFormBeats} from '../../Maiin-burpees/src/lib/formGuides';
import candidates from '../review-manifest.json';

function Evidence(){
 const [rows,setRows]=useState<object[]>([]);const last=useRef<Record<string,string>>({});
 useEffect(()=>{const capture=()=>{
  const fresh:object[]=[];
  for(const section of document.querySelectorAll('section[aria-label$="form guide"]')){
  const image=section?.querySelector<HTMLImageElement>('img[aria-hidden="false"]');
  if(!image?.complete||!image.naturalWidth||getComputedStyle(image).visibility!=='visible')continue;
  const region=section.getAttribute('aria-label')!;
  const data={observedAt:new Date().toISOString(),ms:Math.round(performance.now()),region,src:image.getAttribute('src'),alt:image.alt,viewport:[innerWidth,innerHeight],natural:[image.naturalWidth,image.naturalHeight],theme:document.documentElement.classList.contains('dark')?'dark':'light',playing:[...(section?.querySelectorAll('button')??[])].some(b=>b.textContent?.trim()==='Pause'),slower:section?.querySelector('[aria-label="Slower playback"]')?.getAttribute('aria-pressed'),scope:document.querySelector('main')?.getAttribute('data-review-scope'),text:section?.textContent};
  const key=JSON.stringify({...data,observedAt:null,ms:null});if(key===last.current[region])continue;last.current[region]=key;fresh.push(data);
  }if(fresh.length)setRows(previous=>[...previous,...fresh].slice(-2400));
 };const observer=new MutationObserver(capture);observer.observe(document.body,{subtree:true,childList:true,attributes:true,characterData:true,attributeFilter:['aria-hidden','aria-current','aria-pressed','src','style','class']});document.addEventListener('load',capture,true);window.addEventListener('resize',capture);capture();return()=>{observer.disconnect();document.removeEventListener('load',capture,true);window.removeEventListener('resize',capture);};},[]);
 return <details><summary>Observed playback evidence</summary><Button variant="outline" onClick={()=>{last.current={};setRows([]);}}>Reset evidence</Button><pre data-testid="observed-trace" style={{maxHeight:240,overflow:'auto'}}>{JSON.stringify(rows,null,2)}</pre></details>;
}
function Review(){
 const [selected,setSelected]=useState(candidates[0].id);const [dark,setDark]=useState(true);const [native,setNative]=useState(false);const [step,setStep]=useState(0);const [registered,setRegistered]=useState(false);const [all,setAll]=useState(false);
 useEffect(()=>{document.documentElement.classList.toggle('dark',dark)},[dark]);
 const item=candidates.find(value=>value.id===selected)!;const exercise=EXERCISES.find(value=>value.id===selected)!;const art=getReleasedFormArtwork(selected);const beats=getFormBeats(selected);
 const actualReady=art?.version.includes('2026-10-17-legacy-redraw')&&beats?.every((beat,i)=>beat.image===`form-frames/${selected}/${i+1}.webp`);
 const card=`/form-art/${selected}.webp`;
 if(all)return <main className="min-h-screen bg-background text-foreground p-4" data-review-scope="actual-registered-all-six"><div style={{maxWidth:390,margin:'0 auto'}} className="space-y-6"><h1 className="text-h2 font-bold">Six registered redraws</h1><div className="flex gap-2"><Button variant="outline" onClick={()=>setDark(value=>!value)}>{dark?'Light theme':'Dark theme'}</Button><Button variant="outline" onClick={()=>setAll(false)}>Single guide review</Button></div>{candidates.map(value=>{const live=getReleasedFormArtwork(value.id);const liveBeats=getFormBeats(value.id);const ex=EXERCISES.find(e=>e.id===value.id)!;const ready=live?.version.includes('2026-10-17-legacy-redraw')&&liveBeats?.every((beat,i)=>beat.image===`form-frames/${value.id}/${i+1}.webp`);return <article data-testid={`registered-${value.id}`} data-exercise-id={value.id} key={value.id} className="space-y-3"><h2 className="text-h3 font-bold">{value.name}</h2>{ready?<><p>Registered {live!.width}×{live!.height}; reference {live!.reference}.</p><ExerciseFormContent exerciseName={ex.name}/><details open><summary>Normal card sizes</summary>{[480,348,160,48].map(limit=><figure key={limit} style={{margin:0,overflowX:'auto'}}><img src={`/form-art/${value.id}.webp`} alt={`${value.name} card ${limit}px`} style={{width:'auto',height:'auto',maxWidth:limit,maxHeight:limit}}/><figcaption>{limit}px long-side limit</figcaption></figure>)}</details></>:<p role="alert">Matching registered replacement missing.</p>}</article>})}<Evidence/></div></main>;
 return <main className="min-h-screen bg-background text-foreground p-4" data-review-scope={registered?'actual-registered-lookup':'staged-real-player'}>
 <div className="space-y-3" style={{maxWidth:native?'none':390,margin:'0 auto'}}>
 <h1 className="text-h2 font-bold">Six exercise redraws</h1>
 <label>Exercise<select aria-label="Exercise" className="ds-input" value={selected} onChange={event=>{setSelected(event.target.value);setStep(0)}}>{candidates.map(value=><option key={value.id} value={value.id}>{value.name}</option>)}</select></label>
 <div className="flex flex-wrap gap-2"><Button variant="outline" onClick={()=>setDark(value=>!value)}>{dark?'Light theme':'Dark theme'}</Button><Button variant="outline" onClick={()=>setRegistered(value=>!value)}>{registered?'Show staged candidate':'Show registered guide'}</Button><Button variant="outline" onClick={()=>setNative(value=>!value)}>{native?'Fit review':'Native source view'}</Button><Button variant="outline" onClick={()=>setAll(true)}>Review all registered guides</Button></div>
 <h2 className="text-h3 font-bold">{item.name}</h2>
 {registered?<>{actualReady?<><p data-testid="registration">Actual registered {art!.width}×{art!.height}, {art!.version}</p><ExerciseFormContent key={selected} exerciseName={exercise.name}/><details><summary>Normal card sizes</summary>{[480,348,160,48].map(limit=><figure key={limit}><img src={card} alt={`${item.name} card ${limit}px`} style={{maxWidth:limit,maxHeight:limit,width:'auto',height:'auto'}}/><figcaption>{limit}px long-side limit</figcaption></figure>)}</details></>:<p role="alert">No matching registered replacement is shown.</p>}</>:<><p>Staged candidate; full app registration review follows.</p><ExerciseFormFrames key={selected} name={item.name} beats={item.beats} onStep={setStep}/><p data-testid="selected-cue">{item.beats[step].cue}</p><MuscleKey primary={item.primary} secondary={item.secondary} secondaryFill="solid"/></>}
 {native&&<figure style={{margin:0,overflowX:'auto'}}><img data-testid="native-image" src={'/'+item.beats[step].image} alt={`${item.name} native frame ${step+1}`} style={{width:item.width,height:item.height,maxWidth:'none'}}/><figcaption>Native {item.width}×{item.height}; frame {step+1}. No enlargement or anatomy interpolation.</figcaption></figure>}
 <Evidence key={`${selected}-${registered}`}/>
 </div></main>;
}
const root=createRoot(document.getElementById('root')!);root.render(<Review/>);if(import.meta.hot)import.meta.hot.dispose(()=>root.unmount());
